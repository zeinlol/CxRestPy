CREATE VIEW dbo.sysdatatypemappings AS SELECT * FROM sys.fn_helpdatatypemap('%', '%', '%', '%', '%', '%', 0)
go

