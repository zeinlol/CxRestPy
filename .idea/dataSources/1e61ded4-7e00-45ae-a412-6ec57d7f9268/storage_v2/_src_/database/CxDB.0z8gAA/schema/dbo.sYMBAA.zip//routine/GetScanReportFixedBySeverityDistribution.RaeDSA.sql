 

CREATE PROCEDURE [dbo].[GetScanReportFixedBySeverityDistribution]
	@ScanID AS BIGINT
AS
BEGIN

DECLARE @CurrentProjectID AS BIGINT;
DECLARE @CurrentScanResultID AS BIGINT;
DECLARE @PreviousScanResultID AS BIGINT;
DECLARE	@ScanVisibility AS BIT;
DECLARE	@Owner AS NVARCHAR(120);
DECLARE @NewStatus AS INT;
SET @NewStatus = 2;
DECLARE @Reccurent AS INT;
SET @Reccurent = 1;
DECLARE @Fixed AS INT;
SET @Fixed = 0;



SELECT @CurrentProjectID = MAX(TaskScans.ProjectId), @CurrentScanResultID = MAX(TaskScans.ResultId)  FROM TaskScans WHERE TaskScans.Id = @ScanID
SELECT @ScanVisibility =IsPublic, @Owner=Owner FROM TaskScans WHERE Id = @ScanID
--Get previous scan ------------------------------------------------------------------------------------
SELECT  @PreviousScanResultID = ISNULL(MAX(PreviousScan.ResultId) , -1) 
FROM TaskScans AS PreviousScan
WHERE PreviousScan.ProjectId = @CurrentProjectID
   AND PreviousScan.Id < @ScanID 
   AND PreviousScan.ScanType = 1  /*Regular scan*/
   AND PreviousScan.is_Incremental = 0  /* Not incremental*/
   AND PreviousScan.is_deprecated = 0
   AND (PreviousScan.IsPublic =1 OR (@ScanVisibility=0 AND @Owner = PreviousScan.Owner))
--------------------------------------------------------------------------------------------------------

SELECT  @Fixed AS ResultStatus,
        FixedByQuesry.ResultSeverity  AS ResultSeverity,
        SUM(FixedByQuesry.ResultsCount) AS ResultsCount
FROM (
	SELECT ResultQuery.Severity  AS ResultSeverity,
			COUNT(*) AS ResultsCount 
	FROM   PathResults AS PreviousScanPathResults 
	INNER JOIN QueryVersion AS ResultQuery 
	ON ResultQuery.QueryVersionCode = PreviousScanPathResults.QueryVersionCode
	LEFT OUTER JOIN (SELECT p.Similarity_Hash , p.QueryVersionCode 
					 FROM PathResults AS P 
					 WHERE p.ResultId = @CurrentScanResultID GROUP BY p.Similarity_Hash , p.QueryVersionCode
					 ) AS CurrentScanPathResults 
					   ON CurrentScanPathResults.Similarity_Hash = PreviousScanPathResults.Similarity_Hash 
					  AND CurrentScanPathResults.Similarity_Hash <> 0                    
					  AND CurrentScanPathResults.QueryVersionCode = PreviousScanPathResults.QueryVersionCode
	WHERE PreviousScanPathResults.ResultId = @PreviousScanResultID 
	  AND PreviousScanPathResults.Similarity_Hash <> 0                 
	  AND CurrentScanPathResults.Similarity_Hash IS NULL
	  GROUP BY ResultQuery.QueryId,  ResultQuery.Severity 
	  ) AS FixedByQuesry
GROUP BY FixedByQuesry.ResultSeverity 

END

go

