CREATE VIEW [CxEntities].[QueryCategoryType]
AS
	SELECT 
		[CategoriesTypes].[Id] AS [Id],
		[CategoriesTypes].[TypeName] AS [Name]
	FROM [dbo].[CategoriesTypes]
go

