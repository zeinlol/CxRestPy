   

CREATE FUNCTION [Split] 
( 
    @String NVARCHAR(MAX), 
    @Delimiter NVARCHAR(1) 
) 
RETURNS @output TABLE(splitdata NVARCHAR(MAX) 
) 
BEGIN 
    DECLARE @Start INT, @end INT ;
    SELECT @Start = 1, @end = CHARINDEX(@Delimiter, @String);
    
    WHILE @Start < LEN(@String) + 1 BEGIN 
        IF @end = 0  
            SET @end = LEN(@String) + 1
       
        INSERT INTO @output (splitdata)  
        VALUES(SUBSTRING(@String, @Start, @end - @Start)) 
        SET @Start = @end + 1 
        SET @end = CHARINDEX(@Delimiter, @String, @Start)
        
    END 
    RETURN 
END
go

