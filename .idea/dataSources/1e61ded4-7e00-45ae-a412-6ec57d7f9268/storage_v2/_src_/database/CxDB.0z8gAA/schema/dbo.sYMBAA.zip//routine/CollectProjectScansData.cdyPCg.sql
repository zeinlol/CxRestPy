


CREATE PROCEDURE [CollectProjectScansData]
AS
BEGIN

TRUNCATE TABLE [CxBi].[ProjectScans]
DECLARE @DataUpdatedOn datetime2 = DATEADD(MINUTE, DATEDIFF(MINUTE, 0, GETUTCDATE()), 0);
         
INSERT INTO [CxBi].[ProjectScans]
           ([ProjectID],
	    	[ProjectName],
		    [ScanID],
		    [ScanDate],
		    [ScanDurationMinutes],
		    [High],
		    [Medium],
		    [Low],
		    [Info],
		    [RiskScore],
		    [LOC],
		    [SuccessRate],
		    [Status],
		    [TeamId],
		    [DataUpdatedOn])

SELECT   ProjectID
        ,Projects.Name
		,TaskScans.Id
		,TaskScans.VersionDate
		,ISNULL(DATEDIFF(MINUTE,TaskScans.StartTime,TaskScans.finishtime),0)
		,High
		,Medium
		,Low
		,Information
		,TaskScans.RiskLevel
		,TaskScanEnvironment.LOC		
		,CASE 
			  WHEN TaskScanEnvironment.LOC IS NULL OR TaskScanEnvironment.FailedLOC IS NULL THEN 100
              WHEN TaskScanEnvironment.LOC <= 0 OR TaskScanEnvironment.FailedLOC <= 0 THEN 100
			  WHEN TaskScanEnvironment.FailedLOC > TaskScanEnvironment.LOC THEN 0
              ELSE (1 - CONVERT(float, TaskScanEnvironment.FailedLoc) / CONVERT( float, TaskScanEnvironment.LOC)) * 100
         END
		,1 --SuccessScan
		,TaskScans.Owning_Team 
		,@DataUpdatedOn
FROM [dbo].[TaskScans]
INNER JOIN [dbo].[Projects] ON Projects.Id = TaskScans.ProjectId AND Projects.is_deprecated = 0
INNER JOIN [dbo].[TaskScanEnvironment] ON TaskScanEnvironment.ScanId = TaskScans.Id

WHERE TaskScans.is_deprecated = 0 AND [TaskScans].[VersionDate] > DATEADD(YEAR, -1, GETDATE())

UNION

SELECT   ProjectID
        ,Projects.Name
		,TaskScanID
		,CreatedOn
		,ISNULL(DATEDIFF(MINUTE,EngineStartedOn,EngineFinishedOn),0)
		,0
		,0
		,0
		,0
		,0
		,LOC
		,0
		,2   --FailedScan
		,Projects.Owning_Team
		,@DataUpdatedOn
FROM [dbo].[FailedScans]
INNER JOIN [dbo].[Projects] ON Projects.Id = FailedScans.ProjectId AND Projects.is_deprecated = 0
WHERE [FailedScans].[CreatedOn] > DATEADD(YEAR, -1, GETDATE())

UPDATE STATISTICS [CxBi].[ProjectScans]

END
go

