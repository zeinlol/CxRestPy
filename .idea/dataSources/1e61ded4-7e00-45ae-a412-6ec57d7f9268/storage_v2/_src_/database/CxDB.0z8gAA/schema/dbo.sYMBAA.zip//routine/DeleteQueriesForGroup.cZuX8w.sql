

CREATE PROCEDURE [dbo].[DeleteQueriesForGroup] 
	@PackageID AS BIGINT
	AS

BEGIN
	BEGIN TRANSACTION

	BEGIN TRY

		Update QueryVersion 
		SET IsActive = 0
		WHERE PackageId = @PackageID AND IsActive = 1

		DELETE FROM Query
		WHERE PackageId = @PackageID

		UPDATE QueryGroup
		SET is_deprecated = 1
		WHERE PackageId = @PackageID AND is_deprecated = 0
	
		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH

		ROLLBACK TRANSACTION

	END CATCH
	              
END

go

