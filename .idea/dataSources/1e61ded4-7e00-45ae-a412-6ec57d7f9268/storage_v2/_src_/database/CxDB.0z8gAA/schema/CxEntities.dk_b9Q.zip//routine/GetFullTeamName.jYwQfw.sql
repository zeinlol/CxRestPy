CREATE FUNCTION [CxEntities].[GetFullTeamName] 
		(
			@TeamPath nvarchar(max),
			@TeamName nvarchar(100)
		)
		RETURNS nvarchar(max)
		AS
		BEGIN
			DECLARE @Result nvarchar(max);
	
			WITH [ParentTeamIds_CTE]([TeamId]) AS
			(
				SELECT DISTINCT
					[splitdata] AS [TeamId]
				FROM [dbo].Split(@TeamPath, '\')
			)
			SELECT @Result = COALESCE(@Result + '\', '') + [TeamName]
			FROM [Teams]
			INNER JOIN [ParentTeamIds_CTE] ON [ParentTeamIds_CTE].[TeamId] = [Teams].[TeamId]

			SELECT @Result = CASE WHEN @Result IS NULL THEN @TeamName ELSE @Result + '\' + @TeamName END

			RETURN @Result
		END
go

