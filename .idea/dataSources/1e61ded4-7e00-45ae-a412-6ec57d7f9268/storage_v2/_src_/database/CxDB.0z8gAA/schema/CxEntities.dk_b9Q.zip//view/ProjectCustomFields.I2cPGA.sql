CREATE VIEW [CxEntities].[ProjectCustomFields]
AS
	SELECT 
		[dbo].[ProjectCustomFields].[ProjectId] AS [ProjectId],
		[dbo].[CustomFields].[Name] AS [FieldName],
		[dbo].[ProjectCustomFields].[Value] AS [FieldValue]
	FROM [dbo].[CustomFields] 
	INNER JOIN [dbo].[ProjectCustomFields] ON [dbo].[CustomFields].[Id] = [dbo].[ProjectCustomFields].[CustomFieldId]
	INNER JOIN [dbo].[Projects] ON [ProjectCustomFields].[ProjectId] = [Projects].[Id]
	WHERE [dbo].[Projects].[is_deprecated] = 0
go

