 

CREATE PROCEDURE [dbo].[GetScanReportResults]
	@ScanID AS BIGINT,
    @QueriesFilter AS NVARCHAR(MAX),
	@SeveritiesFilter AS NVARCHAR(MAX),
	@StatesFilter AS NVARCHAR(MAX),
    @AssignedToFilter AS NVARCHAR(MAX),
	@CategoriesFilter AS NVARCHAR(MAX)
AS
BEGIN

DECLARE @CurrentScanResultID AS BIGINT;
DECLARE @ProjectID AS BIGINT;
DECLARE	@ScanVisibility AS BIT;
DECLARE	@Owner AS NVARCHAR(120);
DECLARE @PreviousScanResultID AS BIGINT;
DECLARE @StatePerTeams AS BIT;

DECLARE @NewStatus AS INT;
SET @NewStatus = 2;
DECLARE @Reccurent AS INT;
SET @Reccurent = 1;

--Get project id and result ID
SELECT @ProjectID = TaskScans.ProjectId, @CurrentScanResultID = TaskScans.ResultId, @ScanVisibility =IsPublic, @Owner=Owner  FROM TaskScans WHERE TaskScans.Id = @ScanID;

--Get previous scan ------------------------------------------------------------------------------------
SELECT  @PreviousScanResultID = ISNULL(MAX(PreviousScan.ResultId) , -1) 
FROM TaskScans AS PreviousScan
WHERE PreviousScan.ProjectId = @ProjectID
   AND PreviousScan.Id < @ScanID 
   AND PreviousScan.ScanType = 1  /*Regular scan*/
   AND PreviousScan.is_deprecated = 0
   AND (PreviousScan.IsPublic =1 OR (@ScanVisibility=0 AND @Owner = PreviousScan.Owner));
--------------------------------------------------------------------------------------------------------

---Set states per project or team
SELECT @StatePerTeams = (CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END)
FROM CxComponentConfiguration 
WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY';


---Retrieve latest result labels
WITH scanLabels AS
(
SELECT  ResultsLabels.SimilarityID 
       ,ResultsLabels.LabelType 
       ,ResultsLabels.NumericData
       ,ResultsLabels.StringData
	   ,row_number() over (partition by ResultsLabels.SimilarityID ,ResultsLabels.LabelType  order by ResultsLabels.[UpdateDate] desc) AS RowNumber
FROM ResultsLabels
WHERE  ResultsLabels.LabelType IN (2,3,4)
  AND  ((@StatePerTeams = 1 AND ResultsLabels.ProjectId IN (SELECT TeamProjects.Id FROM Projects AS TeamProjects WHERE TeamProjects.Owning_Team = ( SELECT Projects.Owning_Team FROM Projects WHERE  Projects.Id = @ProjectID)))
        OR 
       (@StatePerTeams = 0 AND  ResultsLabels.ProjectId = @ProjectID))
)
SELECT SimilarityID ,LabelType , StringData, NumericData INTO #ScanResultsLabels
FROM  scanLabels 
WHERE RowNumber = 1;

--------------------------------------

SELECT * INTO #TEMP_GetScanReportResults FROM (


	SELECT    CurrentScanPathResults.QueryVersionCode
			  ,ResultQuery.Severity AS  QuerySeverity
	          ,CurrentScanPathResults.Path_Id 
	          ,CurrentScanPathResults.Similarity_Hash
	          , CASE 
					WHEN PreviousScanPathResults.Similarity_Hash IS NULL THEN @NewStatus 
					ELSE @Reccurent
	            END 
	          AS ResultStatus
	          , CAST(ISNULL(ResultLabelsSeverity.NumericData,ResultQuery.Severity) AS INT) AS ResultSeverity 
	          , CAST(ISNULL(ResultLabelsState.NumericData,0) AS INT) AS ResultState
	          , ISNULL(ResultLabelsAssignedTo.StringData, N'') AS ResultAssignedTo
	FROM     PathResults AS CurrentScanPathResults 
		INNER JOIN QueryVersion AS ResultQuery ON ResultQuery.QueryVersionCode = CurrentScanPathResults.QueryVersionCode
		LEFT OUTER JOIN (SELECT p.Similarity_Hash , p.QueryVersionCode 
		                 FROM PathResults AS P 
		                 WHERE p.ResultId = @PreviousScanResultID GROUP BY p.Similarity_Hash , p.QueryVersionCode
		                 ) AS PreviousScanPathResults 
		                   ON PreviousScanPathResults.Similarity_Hash = CurrentScanPathResults.Similarity_Hash 
		                  AND PreviousScanPathResults.Similarity_Hash <> 0                    
		                  AND PreviousScanPathResults.QueryVersionCode = CurrentScanPathResults.QueryVersionCode
		LEFT OUTER JOIN #ScanResultsLabels AS ResultLabelsSeverity ON ResultLabelsSeverity.SimilarityID  =   CurrentScanPathResults.Similarity_Hash   AND ResultLabelsSeverity.LabelType = 2               
		LEFT OUTER JOIN #ScanResultsLabels AS ResultLabelsState ON ResultLabelsState.SimilarityID  =   CurrentScanPathResults.Similarity_Hash   AND ResultLabelsState.LabelType = 3               
		LEFT OUTER JOIN #ScanResultsLabels AS ResultLabelsAssignedTo ON ResultLabelsAssignedTo.SimilarityID  =   CurrentScanPathResults.Similarity_Hash   AND ResultLabelsAssignedTo.LabelType = 4             
	WHERE CurrentScanPathResults.ResultId = @CurrentScanResultID 
	  AND CurrentScanPathResults.Similarity_Hash <> 0 
	  AND (@QueriesFilter IS NULL OR ResultQuery.QueryId IN(SELECT * FROM Split(@QueriesFilter,',')))
	  AND (@CategoriesFilter IS NULL OR CurrentScanPathResults.QueryVersionCode IN(SELECT DISTINCT QueryVersion.QueryVersionCode 
																		   FROM QueryVersion 
																				LEFT JOIN CategoryForQuery ON QueryVersion.QueryId = CategoryForQuery.QueryId
																				INNER JOIN (SELECT CAST(splitdata AS INT) AS CategoryID 
																		                    FROM Split(@CategoriesFilter,',')) AS Categories 
																					ON Categories.CategoryID = ISNULL(CategoryForQuery.CategoryId,0)))
	  ) AS Data
WHERE (@SeveritiesFilter IS NULL OR ResultSeverity IN(SELECT * FROM Split(@SeveritiesFilter,',')))  
  AND (@StatesFilter IS NULL OR  ResultState IN (SELECT * FROM Split(@StatesFilter,',')))
  AND (@AssignedToFilter IS NULL OR ResultAssignedTo IN(SELECT * FROM Split(@AssignedToFilter,',')));

SELECT 
		  CurrentScanPathResults.*
          ,[NodeResults].[Node_id] 
	      ,[NodeResults].[Full_Name] 
		  ,[NodeResults].[Short_Name]
		  ,[NodeResults].[File_Name]
          ,[NodeResults].[Line]
          ,[NodeResults].[Col]
          ,[NodeResults].[Length]
          ,[NodeResults].[DOM_Id]
          ,[NodeResults].[Method_Line]
FROM     #TEMP_GetScanReportResults AS CurrentScanPathResults 
	INNER JOIN NodeResults ON NodeResults.ResultId = @CurrentScanResultID AND NodeResults.Path_Id = CurrentScanPathResults.Path_Id
ORDER BY QuerySeverity DESC, [NodeResults].Path_Id, [NodeResults].Node_Id;

END


go

