
	CREATE FUNCTION [dbo].[fnHashBytes] (@EncryptAlgorithm   NVARCHAR(4), @DataToEncrypt VARBINARY(MAX))
	RETURNS   VARBINARY(MAX)
	AS
	BEGIN
			DECLARE @Index INTEGER
			DECLARE @DataToEncryptLength INTEGER
			DECLARE @EncryptedResult VARBINARY(MAX)
 
			  IF @DataToEncrypt IS  NOT NULL
			  BEGIN
					   SET @Index = 1
					   SET @DataToEncryptLength =   DATALENGTH(@DataToEncrypt)
					   WHILE @Index <=   @DataToEncryptLength
					   BEGIN
								 IF(@EncryptedResult   IS NULL )
											  SET @EncryptedResult =   HASHBYTES(@EncryptAlgorithm, SUBSTRING(@DataToEncrypt,   @Index, 8000))
								 ELSE
											  SET @EncryptedResult =   @EncryptedResult + HASHBYTES(@EncryptAlgorithm,   SUBSTRING(@DataToEncrypt, @Index, 8000))
                       
								 SET @Index = @Index   + 8000
					   END 
					   SET @EncryptedResult =   HASHBYTES(@EncryptAlgorithm, @EncryptedResult)
			  END
			  RETURN @EncryptedResult
	END
  go

