

CREATE PROCEDURE [dbo].[UpdateCustomFieldsForProject]
(
@ProjectCustomFields AS [dbo].[ProjectCustomFieldsType] READONLY,
@ProjectId BIGINT
)
AS

BEGIN

DELETE ProjectCustomFields WHERE [ProjectId] = @ProjectId

INSERT INTO ProjectCustomFields([CustomFieldId], [ProjectId], [Value])
SELECT [CustomFieldId], [ProjectId], [Value] From @ProjectCustomFields

END

go

