   

CREATE PROCEDURE UpdateScanStatisticsForListOfScans 
	@TaskScanIds nvarchar(max)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ScansToRecalculate TABLE
	(
		[ScanId] bigint,
		[ProjectId] bigint,
		[OwningTeamId] nvarchar(50)
	)

	INSERT INTO @ScansToRecalculate
		SELECT 
			[TaskScans].[Id],
			[TaskScans].[ProjectId],
			[TaskScans].[Owning_Team]
		FROM [TaskScans]
		INNER JOIN
			(
				SELECT CAST([splitdata] AS bigint) AS [Id] FROM Split(@TaskScanIds, ',')
			) AS [ScanIds] ON [ScanIds].[Id] = [TaskScans].[Id]

	DECLARE @ScanID bigint;
	DECLARE @ProjectId bigint;
	DECLARE @OwningTeamId nvarchar(50);

	DECLARE [scan_cursor] CURSOR FORWARD_ONLY FAST_FORWARD READ_ONLY
		FOR SELECT 
			[ScanId],
			[ProjectId],
			[OwningTeamId] 
		FROM @ScansToRecalculate

	OPEN [scan_cursor]

	FETCH NEXT FROM [scan_cursor] INTO @ScanID, @ProjectId, @OwningTeamId

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXECUTE [UpdateScanStatistics] @ScanId, @ProjectId, @OwningTeamId

		FETCH NEXT FROM [scan_cursor] INTO @ScanID, @ProjectId, @OwningTeamId
	END

	CLOSE scan_cursor
	DEALLOCATE scan_cursor

	UPDATE [TaskScans]
	SET [StatisticsCalcDate] = GETDATE()
	WHERE [StatisticsCalcDate] IS NULL	
END
go

