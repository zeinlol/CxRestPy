 

CREATE FUNCTION [dbo].[CalculateQuantityLevel]
(
	@LowSeverityCount int = 0,
	@MediumSeverityCount int = 0,
	@HighSeverityCount int = 0
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @QuantityLevel int;

	SET @QuantityLevel = 0;

	IF @LowSeverityCount > 0 
		SET @QuantityLevel = @QuantityLevel + 10;

	IF @MediumSeverityCount > 0 
		SET @QuantityLevel = @QuantityLevel + 25;

	IF @HighSeverityCount > 50
		BEGIN
			SELECT @QuantityLevel  = CASE WHEN (@QuantityLevel + @HighSeverityCount) < 100 THEN (@QuantityLevel + @HighSeverityCount) ELSE 100 END;
		END
	ELSE IF @HighSeverityCount > 0
		BEGIN
			SET @QuantityLevel = @QuantityLevel + 50;
		END

	-- Return the result of the function
	RETURN @QuantityLevel;

END
go

