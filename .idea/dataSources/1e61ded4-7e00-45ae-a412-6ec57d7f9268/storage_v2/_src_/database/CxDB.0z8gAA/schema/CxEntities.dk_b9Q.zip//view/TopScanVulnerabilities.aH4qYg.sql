CREATE VIEW [CxEntities].[TopScanVulnerabilities]
AS
WITH [Vulnerabilities_CTE] AS 
(	
	SELECT
		[TaskScans].[Id] AS [ScanId],
		[TaskScans].[TopQuery1],
		[TaskScans].[TopQuery1Count],
		[TaskScans].[TopQuery1Severity],
		[TaskScans].[TopQuery2],
		[TaskScans].[TopQuery2Count],
		[TaskScans].[TopQuery2Severity],
		[TaskScans].[TopQuery3],
		[TaskScans].[TopQuery3Count],
		[TaskScans].[TopQuery3Severity],
		[TaskScans].[TopQuery4],
		[TaskScans].[TopQuery4Count],
		[TaskScans].[TopQuery4Severity],
		[TaskScans].[TopQuery5],
		[TaskScans].[TopQuery5Count],
		[TaskScans].[TopQuery5Severity],
		[TaskScans].[StatisticsCalcDate] AS [StatisticsUpdateDate],
		CASE WHEN [TaskScans].[StatisticsOutdated] = 0 THEN 1 ELSE 0 END AS [StatisticsUpToDate]
	FROM [dbo].[TaskScans]
	WHERE [TaskScans].[is_deprecated] = 0
)
SELECT 
	[Vulnerabilities_CTE].[ScanId] AS [ScanId],
	1 AS [Rank],
	[Vulnerabilities_CTE].[TopQuery5] AS [Query],
	[Vulnerabilities_CTE].[TopQuery5Count] AS [Count],
	[Vulnerabilities_CTE].[TopQuery5Severity] AS [Severity],
	[Vulnerabilities_CTE].[StatisticsUpdateDate] AS [StatisticsUpdateDate],
	[Vulnerabilities_CTE].[StatisticsUpToDate] AS [StatisticsUpToDate]
	FROM [Vulnerabilities_CTE]
	WHERE [Vulnerabilities_CTE].[TopQuery5] IS NOT NULL
UNION
SELECT 
	[Vulnerabilities_CTE].[ScanId] AS [ScanId],
	2 AS [Rank],
	[Vulnerabilities_CTE].[TopQuery4] AS [Query],
	[Vulnerabilities_CTE].[TopQuery4Count] AS [Count],
	[Vulnerabilities_CTE].[TopQuery4Severity] AS [Severity],
	[Vulnerabilities_CTE].[StatisticsUpdateDate] AS [StatisticsUpdateDate],
	[Vulnerabilities_CTE].[StatisticsUpToDate] AS [StatisticsUpToDate]
	FROM [Vulnerabilities_CTE]
	WHERE [Vulnerabilities_CTE].[TopQuery4] IS NOT NULL
UNION
SELECT 
	[Vulnerabilities_CTE].[ScanId] AS [ScanId],
	3 AS [Rank],
	[Vulnerabilities_CTE].[TopQuery3] AS [Query],
	[Vulnerabilities_CTE].[TopQuery3Count] AS [Count],
	[Vulnerabilities_CTE].[TopQuery3Severity] AS [Severity],
	[Vulnerabilities_CTE].[StatisticsUpdateDate] AS [StatisticsUpdateDate],
	[Vulnerabilities_CTE].[StatisticsUpToDate] AS [StatisticsUpToDate]
	FROM [Vulnerabilities_CTE]
	WHERE [Vulnerabilities_CTE].[TopQuery3] IS NOT NULL
UNION
SELECT 
	[Vulnerabilities_CTE].[ScanId] AS [ScanId],
	4 AS [Rank],
	[Vulnerabilities_CTE].[TopQuery2] AS [Query],
	[Vulnerabilities_CTE].[TopQuery2Count] AS [Count],
	[Vulnerabilities_CTE].[TopQuery2Severity] AS [Severity],
	[Vulnerabilities_CTE].[StatisticsUpdateDate] AS [StatisticsUpdateDate],
	[Vulnerabilities_CTE].[StatisticsUpToDate] AS [StatisticsUpToDate]
	FROM [Vulnerabilities_CTE]
	WHERE [Vulnerabilities_CTE].[TopQuery2] IS NOT NULL
UNION
SELECT 
	[Vulnerabilities_CTE].[ScanId] AS [ScanId],
	5 AS [Rank],
	[Vulnerabilities_CTE].[TopQuery1] AS [Query],
	[Vulnerabilities_CTE].[TopQuery1Count] AS [Count],
	[Vulnerabilities_CTE].[TopQuery1Severity] AS [Severity],
	[Vulnerabilities_CTE].[StatisticsUpdateDate] AS [StatisticsUpdateDate],
	[Vulnerabilities_CTE].[StatisticsUpToDate] AS [StatisticsUpToDate]
	FROM [Vulnerabilities_CTE]
	WHERE [Vulnerabilities_CTE].[TopQuery1] IS NOT NULL
go

