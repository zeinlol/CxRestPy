

CREATE PROCEDURE [dbo].[GetTaskScanForBranching]
	@ProjectId bigint
AS
BEGIN
		SELECT TOP 1
		[TaskScans].[Id],
		[TaskScans].[ProjectId],
		[TaskScans].[VersionDate],
		[TaskScans].[SourceId],
		[TaskScans].[TaskId],
		[TaskScans].[IsAudit],
		[TaskScans].[is_deprecated],
		[TaskScans].[Owner],
		[TaskScans].[Owning_Team],
		[TaskScans].[FinishTime],
		[TaskScans].[StartTime],
		[TaskScans].[Comment],
		[TaskScans].[High],
		[TaskScans].[Medium],
		[TaskScans].[Low],
		[TaskScans].[Information],
		[TaskScans].[RiskLevel],
		[TaskScans].[QuantityLevel],
		[TaskScans].[TopQuery1],
		[TaskScans].[TopQuery1Count],
		[TaskScans].[TopQuery1Severity],
		[TaskScans].[TopQuery2],
		[TaskScans].[TopQuery2Count],
		[TaskScans].[TopQuery2Severity],
		[TaskScans].[TopQuery3],
		[TaskScans].[TopQuery3Count],
		[TaskScans].[TopQuery3Severity],
		[TaskScans].[TopQuery4],
		[TaskScans].[TopQuery4Count],
		[TaskScans].[TopQuery4Severity],
		[TaskScans].[TopQuery5],
		[TaskScans].[TopQuery5Count],
		[TaskScans].[TopQuery5Severity],
		[TaskScans].[is_Incremental],
		[TaskScans].[ScanType],
		[TaskScans].[ServerID],
		[TaskScans].[QueuedOn],
		[TaskScans].[Origin],
		[TaskScans].[InitiatorName],
		[TaskScans].[ProjectType],
		[TaskScans].[QueryStateID],
		[TaskScans].[EngineStartedOn],
		[TaskScans].[EngineFinishedOn],
		[TaskScans].[ScanRequestCreatedOn],
		[TaskScans].[ScanRequestCompletedOn],
		[TaskScans].[StatisticsOutdated],
		[TaskScans].[StatisticsCalcDate],
		[TaskScans].[IsPublic],
		[TaskScans].[SourceOrigin],
		[TaskScans].[IsLocked],
		[TaskScans].[MethodMapFileExists]
	FROM [TaskScans]
	INNER JOIN [Projects]
		ON [TaskScans].[ProjectId] = [Projects].[Id]
	WHERE [ProjectId] = @ProjectId
		AND [TaskScans].[ScanType] = 1 -- Regular Scan
		AND [TaskScans].[is_deprecated] = 0
		AND [TaskScans].[IsPublic] = [Projects].[Is_Public]
	ORDER BY [VersionDate] DESC
END
go

