 

CREATE FUNCTION IsAuditUser 
(
	@UserId bigint
)
RETURNS bit
AS
BEGIN
	-- Return the result of the function
	RETURN (SELECT convert(bit,COUNT(auditPriv.[Id])) FROM [User_Privileges] auditPriv WHERE auditPriv.UserId = @UserId AND auditPriv.Item = 13 AND auditPriv.RunAction = 3 AND auditPriv.is_deprecated = 0)
                               
END
go

