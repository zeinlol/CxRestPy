CREATE VIEW [CxEntities].[QueryGroup]
AS
	SELECT 
		[QueryGroup].[PackageId] AS [Id],
		[QueryGroup].[Name] AS [Name],
		[QueryGroup].[Description] AS [Description],
		CASE WHEN [QueryGroup].[Project_Id] = 0 THEN NULL ELSE [QueryGroup].[Project_Id] END AS [ProjectId],
		CASE WHEN [QueryGroup].[Owning_Team] = '00000000-0000-0000-0000-000000000000' THEN NULL ELSE [QueryGroup].[Owning_Team] END AS [TeamId],
		[QueryGroup].[PackageType] AS [QueryGroupTypeId],
		[QueryGroup].[Language] AS [LanguageId],
		[QueryGroup].[LanguageName] AS [LanguageName]
	FROM [dbo].[QueryGroup]
go

