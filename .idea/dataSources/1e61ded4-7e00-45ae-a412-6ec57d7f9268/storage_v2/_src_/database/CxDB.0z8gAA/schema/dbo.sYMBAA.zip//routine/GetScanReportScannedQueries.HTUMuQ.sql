

CREATE PROCEDURE [dbo].[GetScanReportScannedQueries]
@ScanID AS BIGINT
AS
BEGIN

	DECLARE @Language AS BIGINT;
	DECLARE @PresetID AS BIGINT;
	DECLARE @ResultID AS BIGINT;


	SELECT @Language = TaskScans.ProjectType,
		   @PresetID = TaskScanEnvironment.PresetId,
		   @ResultID = TaskScans.ResultId 
	FROM TaskScans
	INNER JOIN TaskScanEnvironment ON TaskScans.Id = TaskScanEnvironment.ScanId
	WHERE TaskScans.Id = @ScanID

	SELECT  distinct QueryVersion.QueryId AS QueryId,
			REPLACE(QueryVersion.Name,'_',' ') As QueryName,
		    ISNULL(Data.NumOfResults,0) AS NumOfResults
	FROM Preset_Details 
	INNER JOIN QueryVersion ON QueryVersion.QueryId = Preset_Details.QueryId AND QueryVersion.IsActive = 1
	INNER JOIN QueryGroup ON QueryGroup.PackageId = QueryVersion.PackageId AND (QueryGroup.Language & @Language) = QueryGroup.Language
	LEFT JOIN ( SELECT  PathResults.QueryVersionCode , COUNT(*) AS NumOfResults 
				FROM PathResults 
				WHERE PathResults.ResultId = @ResultID AND Similarity_Hash <> 0 
				GROUP BY PathResults.QueryVersionCode) 
			AS Data 
			ON Data.QueryVersionCode = QueryVersion.QueryVersionCode		
	WHERE Preset_Details.PresetId = @PresetID 
	AND Preset_Details.is_deprecated = 0
END
go

