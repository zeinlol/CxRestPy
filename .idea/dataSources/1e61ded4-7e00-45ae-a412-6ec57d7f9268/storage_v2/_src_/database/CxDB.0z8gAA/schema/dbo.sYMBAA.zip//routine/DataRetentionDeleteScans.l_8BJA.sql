 



CREATE PROCEDURE [dbo].[DataRetentionDeleteScans]
(
	@ScansIds [dbo].[IntArray] READONLY,
	@SetAsDeprecated bit = 1
)
AS
	BEGIN
		DECLARE @Cinfo VARBINARY(128) = HASHBYTES('SHA1','DataRetentionDeleteScans');
        SET CONTEXT_INFO @Cinfo

		IF @SetAsDeprecated = 1
		BEGIN
			UPDATE [dbo].[TaskScans]
			SET [is_deprecated] = 1
			WHERE [Id] IN (SELECT [item] FROM @ScansIds)
		END

		BEGIN TRY
			DECLARE @ConfiguredBulkSize int = (SELECT TOP 1 [Value] FROM [dbo].[CxComponentConfiguration] WHERE [Key] = 'DataRetentionPhysicalBulkSize');
			IF @ConfiguredBulkSize IS NULL
				SET @ConfiguredBulkSize = 10000;

			DECLARE @BatchCount int;

			-- Delete NodeResults in bulks
			SET @BatchCount = @ConfiguredBulkSize;
			WHILE @BatchCount > 0
			BEGIN
				DELETE TOP(@BatchCount) 
				FROM [dbo].[NodeResults] 
				WHERE [NodeResults].[ResultId] IN 
				(
					SELECT [TaskScans].[ResultId] 
					FROM [dbo].[TaskScans] 
					WHERE [Id] IN (SELECT [item] FROM @ScansIds)
				)

				SET @BatchCount = @@ROWCOUNT
			END
			
			-- Delete PathResults in bulks
			SET @BatchCount = @ConfiguredBulkSize;
			WHILE @BatchCount > 0
			BEGIN
				DELETE TOP(@BatchCount) 
				FROM [dbo].[PathResults] 
				WHERE [PathResults].[ResultId] IN 
				(
					SELECT [TaskScans].[ResultId] 
					FROM [dbo].[TaskScans] 
					WHERE [Id] IN (SELECT [item] FROM @ScansIds)
				)

				SET @BatchCount = @@ROWCOUNT
			END

			DELETE FROM [dbo].[TaskScanEnvironment] WHERE [TaskScanEnvironment].[ScanId] IN (SELECT [item] FROM @ScansIds)
			DELETE FROM [dbo].[TaskScans] WHERE [TaskScans].[Id] IN (SELECT item FROM @ScansIds)
			DELETE FROM [dbo].[ScansReports] WHERE [ScansReports].[ScanID] IN (SELECT item FROM @ScansIds)
			
			SELECT NULL
		END TRY
		BEGIN CATCH
			IF @SetAsDeprecated = 1
			BEGIN
				UPDATE [dbo].[TaskScans]
				SET [is_deprecated] = 0
				WHERE [Id] IN (SELECT item FROM @ScansIds)
			END
			SELECT ERROR_MESSAGE() AS ErrorMessage;
		END CATCH

		SET CONTEXT_INFO 0x
	END
go

