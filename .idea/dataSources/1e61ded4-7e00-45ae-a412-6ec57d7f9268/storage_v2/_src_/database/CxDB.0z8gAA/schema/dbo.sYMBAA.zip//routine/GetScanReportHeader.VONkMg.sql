 

CREATE PROCEDURE [dbo].[GetScanReportHeader]
	 @ScanID AS BIGINT
AS
BEGIN

	DECLARE @SourcePath AS NVARCHAR(MAX);
	DECLARE @WebSever AS NVARCHAR(MAX);
	DECLARE @PreviousScanDate AS DATETIME;
	DECLARE	@ScanVisibility AS BIT;
	DECLARE	@Owner AS NVARCHAR(120);
	DECLARE	@DEFAULT_ENCODING AS NVARCHAR(50)
	DECLARE	@ENCODING_KEY_ID AS BIGINT

	SELECT @ScanVisibility =IsPublic, @Owner=Owner FROM TaskScans WHERE Id = @ScanID
	SELECT @SourcePath = CxComponentConfiguration.value FROM CxComponentConfiguration WHERE CxComponentConfiguration.[Key] = 'SOURCE_PATH' ;
	SELECT @WebSever = CxComponentConfiguration.value FROM CxComponentConfiguration WHERE CxComponentConfiguration.[Key] = 'WebServer' ;
	SELECT @ENCODING_KEY_ID = Id FROM [Config].[CxEngineConfigurationKeysMeta] WHERE KeyName = 'ENCODING' ;
	SELECT @DEFAULT_ENCODING =  DefaultValue FROM [CxDB].[Config].[CxEngineConfigurationKeysMeta] WHERE Id = @ENCODING_KEY_ID ;

	SELECT  @PreviousScanDate = PreviousScan.StartTime
	FROM TaskScans AS CurrentScan
	LEFT JOIN TaskScans AS PreviousScan  ON PreviousScan.ProjectId = CurrentScan.ProjectId 
										AND PreviousScan.Id < CurrentScan.Id 
										AND PreviousScan.ScanType = 1  /*Regular scan*/
										AND PreviousScan.is_deprecated = 0
										AND (PreviousScan.IsPublic =1 OR (@ScanVisibility=0 AND @Owner = PreviousScan.Owner))
									  WHERE CurrentScan.Id = @ScanID
									  GROUP BY CurrentScan.Id  , PreviousScan.StartTime;

	SELECT    ISNULL(TaskScanEnvironment.ProjectName , Projects.Name) AS ProjectName, 
			  ISNULL(TaskScanEnvironment.TeamName , N'N/A') AS TeamName, 
			  TaskScanEnvironment.PresetId AS PresetId,
			  ISNULL(TaskScanEnvironment.PresetName , N'N/A') AS PresetName, 
			  ISNULL(TaskScanEnvironment.LOC , 0) AS LOC, 
			  ISNULL(TaskScanEnvironment.FilesCount , 0) AS FilesCount, 
			  ISNULL(@SourcePath + N'\' + CAST(TaskScans.TaskId AS NVARCHAR)  + N'_' + TaskScans.SourceId,'') AS ScanSourcesFolder, 
			  TaskScans.Id AS ScanId, 
			  TaskScans.ProjectId, 
			  ISNULL(TaskScans.SourceOrigin ,Projects.Origin) AS ProjectOrigin, 
			  Projects.Owning_Team AS ProjectTeam,
			  TaskScans.StartTime AS ScanStartTime, 
			  TaskScans.FinishTime AS ScanFinishTime, 
			  TaskScans.Comment AS ScanComment, 
			  TaskScans.ScanType, 
			  TaskScans.is_Incremental AS IncrementalScan, 
			  ISNULL([Config].[CxEngineConfigurationValues].[Value], @DEFAULT_ENCODING) AS ProjectEncoding,
			  @WebSever AS WebServerURL, 
			   TaskScanEnvironment.ProductVersion AS ProductVersion,
			  @PreviousScanDate  AS PreviousScanDate,
			  Projects.Owner,
			  TaskScans.InitiatorName,
			  TaskScans.IsPublic
	FROM      TaskScans 
	INNER JOIN Projects ON Projects.Id = TaskScans.ProjectId 
	LEFT OUTER JOIN [Config].[CxEngineConfigurationValues] ON [Config].[CxEngineConfigurationValues].Id = [Projects].[ConfigurationId] AND [Config].[CxEngineConfigurationValues].[ConfigurationKeyId] = @ENCODING_KEY_ID    
	LEFT OUTER JOIN TaskScanEnvironment ON TaskScanEnvironment.ScanId = TaskScans.Id
	WHERE TaskScans.Id = @ScanID  
END
go

