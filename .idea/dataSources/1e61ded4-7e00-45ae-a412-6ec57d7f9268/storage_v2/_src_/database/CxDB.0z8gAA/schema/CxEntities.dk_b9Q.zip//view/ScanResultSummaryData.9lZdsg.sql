CREATE VIEW [CxEntities].[ScanResultSummaryData]
AS
	SELECT 
		[CurrentScan].[Id] AS [ScanId],
		[PreviousScan].[Id] AS [PreviousScanId],
		ISNULL([Res].[New], 0) [New],
		ISNULL([Res].[Recurrent], 0) [Recurrent],
		ISNULL([Res].[Resolved], 0) [Resolved]
	FROM [dbo].[TaskScans] [CurrentScan]
	OUTER APPLY 
	(
		SELECT 
			[TaskScans].[Id],
			[TaskScans].[ResultId]
		FROM [dbo].[TaskScans]
		INNER JOIN
		(
			SELECT MAX([TaskScans].[Id]) AS [Id]
			FROM [dbo].[TaskScans]
			WHERE [CurrentScan].[ProjectId] = [TaskScans].[ProjectId]
				AND [TaskScans].[Id] < [CurrentScan].[Id]
				AND [TaskScans].[ScanType] = 1 --Regular scan
				AND [TaskScans].[is_Incremental] = 0 --Not incremental
				AND [TaskScans].[is_deprecated] = 0
		) AS [PreviousScan] ON [PreviousScan].[Id] = [TaskScans].[Id]
	) AS [PreviousScan]
	OUTER APPLY
	(
		SELECT 
			SUM(CASE WHEN [r1].[Similarity_Hash] IS NULL THEN [r2].[Count] ELSE CASE WHEN [r1].[Count] < ISNULL([r2].[Count], 0) THEN [r2].[Count] - [r1].[Count] ELSE 0 END END) AS [Resolved],
			SUM(CASE WHEN [r1].[Similarity_Hash] IS NOT NULL AND [r2].[Similarity_Hash] IS NOT NULL THEN CASE WHEN [r1].[Count] < [r2].[Count] THEN [r1].[Count] ELSE [r2].[Count] END ELSE 0 END) AS [Recurrent],
			SUM(CASE WHEN [r2].[Similarity_Hash] IS NULL THEN [r1].[Count] ELSE CASE WHEN [r2].[Count] < ISNULL([r1].[Count], 0) THEN [r1].[Count] - [r2].[Count] ELSE 0 END END) AS [New]
		FROM 
			(
				SELECT
					[PathResults].[Similarity_Hash],
					COUNT(*) AS [Count]
				FROM [dbo].[PathResults]
				WHERE [PathResults].[ResultId] = [CurrentScan].[ResultId]
					AND [PathResults].[Similarity_Hash] <> 0
				GROUP BY [PathResults].[Similarity_Hash]
			) [r1]
		FULL OUTER JOIN 
			(
				SELECT
					[PathResults].[Similarity_Hash],
					COUNT(*) AS [Count]
				FROM [dbo].[PathResults]
				WHERE [PathResults].[ResultId] = [PreviousScan].[ResultId]
					AND [PathResults].[Similarity_Hash] <> 0
				GROUP BY [PathResults].[Similarity_Hash]
			) [r2]  ON [r1].[Similarity_Hash] = [r2].[Similarity_Hash]
	) [Res]
go

