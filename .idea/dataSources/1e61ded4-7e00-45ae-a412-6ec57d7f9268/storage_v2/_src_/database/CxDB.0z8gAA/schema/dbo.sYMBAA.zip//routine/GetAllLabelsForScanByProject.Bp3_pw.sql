 


CREATE PROCEDURE [dbo].[GetAllLabelsForScanByProject]
	@ScanId bigint,
	@ProjectId nvarchar(50)
AS
BEGIN
	SELECT labels.[LabelType] ,labels.[ProjectId] ,labels.[ResultId] ,labels.[PathID] ,labels.[SimilarityId], 
			labels.[NumericData], labels.[StringData] ,labels.[UpdateDate] ,labels.[UpdatingUser], 
			(users.[FirstName] + ' ' + users.[LastName]) AS UserFullName, projects.[Name] AS ProjectName
	FROM [ResultsLabels] labels
	LEFT OUTER JOIN [Users] users ON users.[UserName] = labels.[UpdatingUser] 
	INNER JOIN [Projects] projects ON labels.[ProjectId] = projects.[Id]
	INNER JOIN [PathResults] scanPaths ON scanPaths.[Similarity_Hash] = labels.[SimilarityId]
    INNER JOIN QueryVersion ON scanPaths.QueryVersionCode = QueryVersion.QueryVersionCode
    LEFT JOIN (
		SELECT QueryVersion.QueryVersionCode 
			FROM QueryVersion 
			INNER JOIN QueryGroup ON QueryVersion.PackageId  = QueryGroup.PackageId) QueryIDs2 ON  QueryIDs2.QueryVersionCode = scanPaths.QueryVersionCode
			INNER JOIN [TaskScans] scans ON scanPaths.[ResultId] = scans.[ResultId]
		WHERE scans.[Id] = @ScanId
			AND projects.[Id] = @ProjectId
	ORDER BY labels.[UpdateDate] DESC

END
go

