CREATE VIEW [CxEntities].[QuerySource]
AS
	SELECT 
		[QuerySource].[Id] AS [Id],
		[QuerySource].[Source] AS [Source]
	FROM [dbo].[QuerySource]
go

