 
-- =============================================
-- Author:		Ravit Machluf
-- Create date: 19072014
-- Description:	Updates Similarity Ids - used by SimilarityConverter tool
-- =============================================
CREATE PROCEDURE [dbo].[UpdateSimilarityInResultsTabels]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT OFF;
	
    update      [PathResults]
	set         [Result_Hash] = t2.[Result_Hash], [Similarity_Hash] = t2.[Similarity_Hash]
	from        [PathResults] t1
	inner join  [PathResultsTemp] t2
	on          t1.[ID] = t2.[ID] and t1.[Path_Id] = t2.[Path_Id];
    
    delete 
    from		[Results_Label_Details]
    where [ID] in (select ID from [Results_Labels_Temp]);

    delete 
    from		[Results_Labels]
    where [ID] in (select ID from [Results_Labels_Temp]);
	
END
go

