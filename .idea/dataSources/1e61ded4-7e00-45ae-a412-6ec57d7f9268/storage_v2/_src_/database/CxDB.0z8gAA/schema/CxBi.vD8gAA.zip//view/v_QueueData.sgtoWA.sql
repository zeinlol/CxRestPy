 


CREATE VIEW [CxBi].[v_QueueData]
WITH SCHEMABINDING
AS
  SELECT [ID]
      ,[Stage]
      ,[ProjectID]
      ,[TaskScanID] AS ScanID
      ,[IsIncremental]
      ,[TeamID]
      ,[CreatedOn]
      ,[QueuedOn]
      ,[EngineStartedOn]
      ,[EngineFinishedOn]
      ,[CompletedOn]
      ,[LOC]
      ,[ScanSize]
      ,[QueuePosition]
  FROM [dbo].[ScanRequests]
  INNER JOIN [dbo].[ScanSizes] ON [dbo].[ScanSizes].[FromLOC] <= [dbo].[ScanRequests].LOC 
  AND  [dbo].[ScanSizes].[ToLOC] >= [dbo].[ScanRequests].LOC
go

