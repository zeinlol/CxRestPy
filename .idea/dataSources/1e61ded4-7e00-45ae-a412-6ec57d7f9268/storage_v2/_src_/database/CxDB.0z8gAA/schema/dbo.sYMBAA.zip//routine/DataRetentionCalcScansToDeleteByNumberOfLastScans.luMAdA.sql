 

CREATE PROCEDURE [dbo].[DataRetentionCalcScansToDeleteByNumberOfLastScans]
(
	@NumberOfLastscans INT
)
AS
BEGIN  
	WITH Preserved_Scans AS (
			SELECT
				[ProjectScans].[ScanId],[ProjectScans].[ProjectId],[ProjectScans].[is_Incremental]
			FROM
			(
				SELECT 
					[TaskScans].[Id] AS [ScanId],
					ISNULL([Projects].[ScansToKeep], @NumberOfLastscans) AS [ScansToKeep],
					[TaskScans].[ProjectId],
					[TaskScans].[is_Incremental],
					ROW_NUMBER() OVER (PARTITION BY [TaskScans].[ProjectId] ORDER BY [TaskScans].[VersionDate] DESC) [ScanOrder]
				FROM [TaskScans]
				INNER JOIN [Projects] ON [TaskScans].[ProjectId] = [Projects].[Id]
				LEFT JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
				WHERE [TaskScans].[ScanType] = 1
					AND [Projects].[is_deprecated] = 0
					AND [TaskScans].[is_deprecated] = 0
					AND [ScanRequests].[Id] IS NULL
			) [ProjectScans]
			WHERE [ProjectScans].[ScanOrder] <= [ProjectScans].[ScansToKeep]

			UNION ALL
				
			SELECT [TaskScans].[Id] AS [ScanId],[TaskScans].[ProjectId],[TaskScans].[is_Incremental]
			FROM [TaskScans]
			INNER JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
			WHERE [TaskScans].[is_deprecated] = 0
							)
    SELECT
		[TaskScans].[ProjectId],
		[TaskScans].[Id] as [ScanId],
		[TaskScans].[SourceId],
		[TaskScans].[TaskId],
		[TaskScans].[ScanType],
		[ScansReports].[ReportPath]
    FROM [TaskScans] 
	LEFT JOIN [ScansReports] ON [TaskScans].[Id] = [ScansReports].[ScanID] 
    WHERE [TaskScans].[IsLocked] = 0
		AND [TaskScans].[is_deprecated] = 0
		AND [TaskScans].[Id] NOT IN 
		(
			SELECT [ScanId] FROM Preserved_Scans

			UNION ALL

			--Don't delete last Full Scan also in case all preserved Scans are incremental
			SELECT ISNULL(MAX([Id]),0)
			FROM [TaskScans] e
			WHERE [is_Incremental]=0 
									AND EXISTS (SELECT 1 FROM Preserved_Scans ps WHERE ps.[ProjectId]=e.[ProjectId] AND ps.[is_Incremental]=1)
		)
    ORDER BY [TaskScans].[ProjectId], [TaskScans].[Id], [TaskScans].[VersionDate]
END
go

