    

CREATE PROCEDURE [dbo].[GetCxQueryDescriptionSourceExamples]
     @LCID AS INT,
     @CxQueryDescriptionFilter AS NVARCHAR(MAX)
AS
BEGIN
		SELECT english.[SourceCodeExapleID]
			  ,ISNULL(lang.[CxQueryDescriptionID], english.[CxQueryDescriptionID]) AS [CxQueryDescriptionID]
			  ,ISNULL(lang.[SourceLanguage],english.[SourceLanguage]) AS [SourceLanguage]
			  ,ISNULL(lang.[Title],english.[Title]) AS [Title]
			  ,ISNULL(lang.[SourceCodeExample],english.[SourceCodeExample]) AS [SourceCodeExample]
		  FROM [dbo].[SourceCodeExamples] as english
		  left outer join   (select * from [dbo].[SourceCodeExamples]  
							 where LCID = @LCID 
							 AND (@CxQueryDescriptionFilter IS NULL OR  [CxQueryDescriptionID] IN(SELECT * FROM Split(@CxQueryDescriptionFilter,',')) ) ) as lang
		  on   english.[SourceCodeExapleID] = lang.[SourceCodeExapleID]
		   WHERE english.LCID = 1033 -- English LCID
		    AND (@CxQueryDescriptionFilter IS NULL OR  english.[CxQueryDescriptionID] IN(SELECT * FROM Split(@CxQueryDescriptionFilter,',')) )
END
go

