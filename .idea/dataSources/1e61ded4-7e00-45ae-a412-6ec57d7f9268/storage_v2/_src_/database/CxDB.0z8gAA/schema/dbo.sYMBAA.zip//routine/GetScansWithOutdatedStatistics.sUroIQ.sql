

CREATE PROCEDURE [dbo].[GetScansWithOutdatedStatistics]
AS
BEGIN
	SELECT 
		[TaskScans].[Id],
		[TaskScans].[ProjectId],
		[TaskScans].[Owning_Team]
	FROM [TaskScans] 
	WHERE
		[TaskScans].[StatisticsOutdated] = 1 AND
		[TaskScans].[FinishTime] > DATEADD(YEAR, -1, GETDATE())
	ORDER BY [TaskScans].[Id] DESC
END
go

