CREATE VIEW [CxEntities].[QueryCategory]
AS
	SELECT
		[Categories].[Id] AS [Id],
		[Categories].[CategoryName] AS [Name],
		[Categories].[CategoryType] AS [TypeId]
	FROM [dbo].[Categories]
go

