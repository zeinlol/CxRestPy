

CREATE PROCEDURE [CollectProjectStateData]
AS
BEGIN
	DECLARE @MinDate DATETIME = DATEADD(YEAR, -1, GETDATE());
	DECLARE @DataUpdatedOn datetime2 = DATEADD(MINUTE, DATEDIFF(MINUTE, 0, GETUTCDATE()), 0);

	TRUNCATE TABLE [CxBi].[ProjectState]

	INSERT INTO [CxBi].[ProjectState]
	(
		[ProjectID],
		[ProjectName],
		[LastScanID],
		[LastScanDate],
		[LastScanDurationMinutes],
		[High],
		[Medium],
		[Low],
		[Info],
		[RiskScore],
		[RiskLevel],
		[LOC],
		[TeamId],
		[DataUpdatedOn]
	)
	SELECT  
		[Projects].[Id] AS [ProjectID],
		[Projects].[Name] AS [ProjectName],
		[TaskScans].[Id] AS [LastScanID],
		[TaskScans].[VersionDate] AS [LastScanDate],
		DATEDIFF(MINUTE, [TaskScans].[StartTime],[TaskScans].[FinishTime]) AS [LastScanDurationMinutes],
		[TaskScans].[High] AS [High],
		[TaskScans].[Medium] AS [Medium],
		[TaskScans].[Low] AS [Low],
		[TaskScans].[Information] AS [Info],
		[TaskScans].[RiskLevel] AS [RiskScore],
		(SELECT TOP 1 [RiskLevel] FROM [ScanRiskLevel] WHERE [TaskScans].[RiskLevel] BETWEEN [ScanRiskLevel].[From] AND [ScanRiskLevel].[To]) AS [RiskLevel],
		(SELECT TOP 1 [LOC] FROM [TaskScanEnvironment] WHERE [TaskScanEnvironment].[ScanId] = [TaskScans].[Id]) AS [LOC],
		[TaskScans].[Owning_Team] AS [TeamId],
		@DataUpdatedOn AS [DataUpdatedOn]
	FROM
	(
		SELECT 
			[TaskScans].[ProjectId], 
			MAX([TaskScans].[Id]) AS [LastScanID]
		FROM [TaskScans]
		WHERE	[TaskScans].[is_deprecated] = 0
			AND [TaskScans].[ScanType] = 1 
			AND [TaskScans].[IsPublic] = 1
		GROUP BY [TaskScans].[ProjectId]
	) AS [ProjectLastScan]
	INNER JOIN [TaskScans] ON [TaskScans].[Id] = [ProjectLastScan].[LastScanID]
	INNER JOIN [Projects] ON [Projects].[Id] = [TaskScans].[ProjectId] AND [Projects].[is_deprecated] = 0 AND [Projects].[Is_Public] = 1
	WHERE [TaskScans].[VersionDate] > @MinDate

	UPDATE STATISTICS [CxBi].[ProjectState]
END
go

