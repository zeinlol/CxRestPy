 

CREATE PROCEDURE [dbo].[BranchProject]
	@OriginalProjectId bigint,
	@OriginalProjectTeam nvarchar(50),
	@OriginalScanId bigint,
	@NewProjectId bigint,
	@NewProjectTeam nvarchar(50),
	@ProjectBranchTreeId bigint
AS
BEGIN
   DECLARE @Cinfo VARBINARY(128) = HASHBYTES('SHA1','BranchProject');
   SET CONTEXT_INFO @Cinfo
	-- Mark branched project as deleted to prevent users from seeing it.
	UPDATE Projects 
	SET is_deprecated = 1 
	WHERE ID = @NewProjectId

	-- Declare temporary variables to store a snapshot of the data.
	DECLARE @BranchedProject TABLE (
		[Id] [bigint],
		[Path] [nvarchar](max),
		[Name] [nvarchar](255),
		[OpenedAt] [datetime],
		[OpenedBy] [nvarchar](50),
		[Origin] [int],
		[is_deprecated] [bit],
		[Owner] [nvarchar](120),
		[Owning_Team] [nvarchar](50),
		[Is_Public] [bit],
		[Executable] [nvarchar](max),
		[UNCCredentials] [ntext],
		[Description] [nvarchar](max),
		[ExcludeFilesPatterns] [nvarchar](max),
		[ExcludeFoldersPatterns] [nvarchar](max),
		[IssueTrackingSettings] [nvarchar](max),
		[OwningTeamName] [nvarchar](MAX),
		[TaskId_Legacy] [bigint],
		[PresetId] [bigint],
		[ConfigurationId] [bigint]--,
		--[PresetName] [nvarchar](255)

	)

	DECLARE @BranchedTaskId bigint;

	DECLARE @OriginalTaskScan TABLE (
		[Id] [bigint],
		[ProjectId] [bigint],
		[VersionDate] [datetime],
		[SourceId] [nvarchar](92),
		[ResultId] [bigint],
		[TaskId] [bigint],
		[IsAudit] [bit],
		[is_deprecated] [bit],
		[Owner] [nvarchar](120),
		[Owning_Team] [nvarchar](50),
		[FinishTime] [datetime],
		[StartTime] [datetime],
		[Comment] [ntext],
		[High] [int],
		[Medium] [int],
		[Low] [int],
		[Information] [int],
		[RiskLevel] [int],
		[QuantityLevel] [int],
		[TopQuery1] [nvarchar](255),
		[TopQuery1Count] [int],
		[TopQuery1Severity] [int],
		[TopQuery2] [nvarchar](255),
		[TopQuery2Count] [int],
		[TopQuery2Severity] [int],
		[TopQuery3] [nvarchar](255),
		[TopQuery3Count] [int],
		[TopQuery3Severity] [int],
		[TopQuery4] [nvarchar](255),
		[TopQuery4Count] [int],
		[TopQuery4Severity] [int],
		[TopQuery5] [nvarchar](255),
		[TopQuery5Count] [int],
		[TopQuery5Severity] [int],
		[is_Incremental] [bit],
		[ScanType] [int],
		[ServerID] [bigint],
		[QueuedOn] [datetime],
		[Origin] [nvarchar](150),
		[InitiatorName] [nvarchar](150),
		[ProjectType] [int],
		[QueryStateID] [int] ,
		[EngineStartedOn] [datetime] ,
		[EngineFinishedOn] [datetime] ,
		[ScanRequestCreatedOn] [datetime] ,
		[ScanRequestCompletedOn] [datetime],
		[StatisticsOutdated] [bit],
		[StatisticsCalcDate] [datetime],
		[MethodMapFileExists] [bit]
	)

	DECLARE @OriginalTaskScanEnvironment TABLE (
		[RunId] [nvarchar](255),
		[ScanId] [bigint],
		[ProjectName] [nvarchar](255),
		[PresetName] [nvarchar](255),
		[Path] [nvarchar](max),
		[TeamName] [nvarchar](max),
		[LOC] [bigint],
		[FilesCount] [bigint],
		[ProductVersion] [nvarchar](255),
		[ForceScan] [bit],
		[is_deprecated] [bit],
		[PresetId] [bigint],
		[FailedLOC] [bigint] 
	)

	DECLARE @OriginalPathResults TABLE (
		[ResultId] [bigint],
		[Path_Id] [bigint],
		[QueryVersionCode] [bigint],
		[Similarity_Hash] [bigint],
		[Compilation_Msgs] [nvarchar](max),
		[Debug_Msgs] [nvarchar](max),
		[Date] [datetime] ,
		[ConfidenceLevel][int]
	)

	DECLARE @OriginalNodeResults TABLE (
		[ResultId] [bigint],
		[Path_Id] [bigint],
		[Node_Id] [bigint],
		[Full_Name] [nvarchar](4000),
		[Short_Name] [nvarchar](4000),
		[File_Name] [nvarchar](4000),
		[Line] [int],
		[Col] [int],
		[Length] [int],
		[DOM_Id] [bigint],
		[Method_Line] [int] 
	)

	-- Get labels configuration: whether labels are defined per project or shared for the entire team.
	DECLARE @ResultLabelsArePerTeam nvarchar(10);
	SET @ResultLabelsArePerTeam = (SELECT [Value] FROM CxComponentConfiguration WHERE [Key] = 'RESULT_ATTRIBUTES_PER_SIMILARITY');

	DECLARE @ProjectIdsForLabels TABLE (
		[Id] bigint
	)

	DECLARE @OriginalResultLabels TABLE (
		[ID] [numeric](18, 0),
		[LabelType] [int],
		[ProjectId] [bigint],
		[ResultId] [bigint],
		[PathID] [bigint],
		[SimilarityId] [bigint],
		[NumericData] [int],
		[StringData] [nvarchar](max),
		[UpdateDate] [datetime],
		[UpdatingUser] [nvarchar](120) 
	)

	DECLARE @OriginalResultLabelHistory TABLE (
		[ID] [numeric](18, 0),
		[SeqID] [numeric](18, 0),
		[DateCreated] [datetime],
		[CreatedBy] [nvarchar](120),
		[Data] [nvarchar](max) 
	)

	-- Take a snapshot of the current data into the temp variables.
	INSERT INTO @BranchedProject
		SELECT TOP 1
			[Projects].[Id],
			[Projects].[Path],
			[Projects].[Name],
			[Projects].[OpenedAt],
			[Projects].[OpenedBy],
			[Projects].[Origin],
			[Projects].[is_deprecated],
			[Projects].[Owner],
			[Projects].[Owning_Team],
			[Projects].[Is_Public],
			[Projects].[Executable],
			[Projects].[UNCCredentials],
			[Projects].[Description],
			[Projects].[ExcludeFilesPatterns],
			[Projects].[ExcludeFoldersPatterns],
			[Projects].[IssueTrackingSettings] ,
			[Teams].[TeamName] AS [OwningTeamName],
			[Projects].[TaskId_Legacy],
			[Projects].[PresetId] [bigint],
			[Projects].[ConfigurationId] [bigint]
		FROM [Projects]
		LEFT JOIN [Teams] ON [Projects].[Owning_Team] = [Teams].[TeamId]
		WHERE [Projects].[Id] = @NewProjectId

	SET @BranchedTaskId = (SELECT TOP 1 ISNULL([TaskId_Legacy], [Id]) FROM @BranchedProject);

	INSERT INTO @OriginalTaskScan 
		SELECT TOP 1 
			[Id],
			[ProjectId],
			[VersionDate],
			[SourceId],
			[ResultId],
			[TaskId],
			[IsAudit],
			[is_deprecated],
			[Owner],
			[Owning_Team],
			[FinishTime],
			[StartTime],
			[Comment],
			[High],
			[Medium],
			[Low],
			[Information],
			[RiskLevel],
			[QuantityLevel],
			[TopQuery1],
			[TopQuery1Count],
			[TopQuery1Severity],
			[TopQuery2],
			[TopQuery2Count],
			[TopQuery2Severity],
			[TopQuery3],
			[TopQuery3Count],
			[TopQuery3Severity],
			[TopQuery4],
			[TopQuery4Count],
			[TopQuery4Severity],
			[TopQuery5],
			[TopQuery5Count],
			[TopQuery5Severity],
			[is_Incremental],
			[ScanType],
			[ServerID],
			[QueuedOn],
			[Origin],
			[InitiatorName],
			[ProjectType],
			[QueryStateID],
			[EngineStartedOn],
		    [EngineFinishedOn],
		    [ScanRequestCreatedOn],
		    [ScanRequestCompletedOn],
			[StatisticsOutdated],
			[StatisticsCalcDate],
			[MethodMapFileExists]
		FROM [TaskScans] 
		WHERE [TaskScans].[Id] = @OriginalScanId

	INSERT INTO @OriginalTaskScanEnvironment 
		SELECT TOP 1
			[TaskScanEnvironment].[RunId],
			[TaskScanEnvironment].[ScanId],
			[TaskScanEnvironment].[ProjectName],
			[TaskScanEnvironment].[PresetName],
			[TaskScanEnvironment].[Path],
			[TaskScanEnvironment].[TeamName],
			[TaskScanEnvironment].[LOC],
			[TaskScanEnvironment].[FilesCount],
			[TaskScanEnvironment].[ProductVersion],
			[TaskScanEnvironment].[ForceScan],
			[TaskScanEnvironment].[is_deprecated],
			[TaskScanEnvironment].[PresetId],
			[TaskScanEnvironment].[FailedLOC] 
		FROM [TaskScanEnvironment]
		WHERE [ScanId] = @OriginalScanId
			AND [TaskScanEnvironment].[is_deprecated] = 0

	INSERT INTO @OriginalPathResults 
		SELECT
			[PathResults].[ResultId],
			[PathResults].[Path_Id],
			[PathResults].[QueryVersionCode],
			[PathResults].[Similarity_Hash],
			[PathResults].[Compilation_Msgs],
			[PathResults].[Debug_Msgs],
			[PathResults].[Date],
			[PathResults].[ConfidenceLevel] 
		FROM [PathResults]
		INNER JOIN @OriginalTaskScan [OriginalTaskScan]
			ON [OriginalTaskScan].[ResultId] = [PathResults].[ResultId]

	INSERT INTO @OriginalNodeResults 
		SELECT
			[NodeResults].[ResultId],
			[NodeResults].[Path_Id],
			[NodeResults].[Node_Id],
			[NodeResults].[Full_Name],
			[NodeResults].[Short_Name],
			[NodeResults].[File_Name],
			[NodeResults].[Line],
			[NodeResults].[Col],
			[NodeResults].[Length],
			[NodeResults].[DOM_Id],
			[NodeResults].[Method_Line] 
		FROM [NodeResults]
		INNER JOIN @OriginalTaskScan [OriginalTaskScan]
			ON [OriginalTaskScan].[ResultId] = [NodeResults].[ResultId]
	
	-- If the labels are configured per project, copy labels for the current project.
	IF @ResultLabelsArePerTeam = 'false'
		BEGIN
			INSERT INTO @ProjectIdsForLabels
				VALUES (@OriginalProjectId)
		END
	-- If the labels are configured per team, copy labels for all projects in the team, but only if the new project is in a different team than the original project.
	ELSE IF @OriginalProjectTeam <> @NewProjectTeam
		BEGIN
			INSERT INTO @ProjectIdsForLabels
				SELECT [Projects].[Id]
				FROM [Projects]
				WHERE [Projects].[Owning_Team] = @OriginalProjectTeam
					AND is_deprecated = 0
		END
		
	-- Only bother taking a snapshot of the labels if we need to copy them.
	IF @ResultLabelsArePerTeam = 'false' OR @OriginalProjectTeam <> @NewProjectTeam
		BEGIN
			INSERT INTO @OriginalResultLabels 
				SELECT
					[ResultsLabels].[ID],
					[ResultsLabels].[LabelType],
					[ResultsLabels].[ProjectId],
					[ResultsLabels].[ResultId],
					[ResultsLabels].[PathID],
					[ResultsLabels].[SimilarityId],
					[ResultsLabels].[NumericData],
					[ResultsLabels].[StringData],
					[ResultsLabels].[UpdateDate],
					[ResultsLabels].[UpdatingUser] 
				FROM [ResultsLabels]
				WHERE [ResultsLabels].[ProjectId] IN (SELECT [Id] FROM @ProjectIdsForLabels)
					AND [ResultsLabels].[SimilarityId] IN (SELECT DISTINCT [Similarity_Hash] FROM @OriginalPathResults)

			INSERT INTO @OriginalResultLabelHistory 
				SELECT
					[ResultsLabelsHistory].[ID],
					[ResultsLabelsHistory].[SeqID],
					[ResultsLabelsHistory].[DateCreated],
					[ResultsLabelsHistory].[CreatedBy],
					[ResultsLabelsHistory].[Data] 
				FROM [ResultsLabelsHistory]
				WHERE [ID] IN (SELECT [ID] FROM @OriginalResultLabels)
		END

		BEGIN TRANSACTION 
			-- lock scanRequests table to get the next ID from for TaskScans
			declare @tempId int 
			set  @tempId = (select top 1 @tempId from ScanRequests with (tablockx));

			declare @NewScanRequestIdSeed bigint;
			set @NewScanRequestIdSeed = (SELECT IDENT_CURRENT('[dbo].[ScanRequests]') + IDENT_INCR('[dbo].[ScanRequests]'))
			DBCC CHECKIDENT('[dbo].[ScanRequests]', RESEED, @NewScanRequestIdSeed)
		COMMIT TRANSACTION

	BEGIN TRY
		BEGIN TRANSACTION 

			
			
			DECLARE @BranchedTaskScanIds TABLE(
				[Id] [bigint],
				[ResultId] [bigint]
			)

			SET IDENTITY_INSERT [TaskScans] ON 

			INSERT INTO [TaskScans] 
			(
				[Id],
				[ProjectId],
				[VersionDate],
				[SourceId],
				[TaskId],
				[IsAudit],
				[is_deprecated],
				[Owner],
				[Owning_Team],
				[FinishTime],
				[StartTime],
				[Comment],
				[High],
				[Medium],
				[Low],
				[Information],
				[RiskLevel],
				[QuantityLevel],
				[TopQuery1],
				[TopQuery1Count],
				[TopQuery1Severity],
				[TopQuery2],
				[TopQuery2Count],
				[TopQuery2Severity],
				[TopQuery3],
				[TopQuery3Count],
				[TopQuery3Severity],
				[TopQuery4],
				[TopQuery4Count],
				[TopQuery4Severity],
				[TopQuery5],
				[TopQuery5Count],
				[TopQuery5Severity],
				[is_Incremental],
				[ScanType],
				[ServerID],
				[QueuedOn],
				[Origin],
				[InitiatorName],
				[ProjectType],
				[QueryStateID],
				[EngineStartedOn],
		        [EngineFinishedOn],
		        [ScanRequestCreatedOn],
		        [ScanRequestCompletedOn],
				[StatisticsOutdated],
				[StatisticsCalcDate],
				[MethodMapFileExists]
		   )
			OUTPUT 
				inserted.[Id],
				inserted.[ResultId] 
			INTO @BranchedTaskScanIds
				SELECT 
					@NewScanRequestIdSeed,
					@NewProjectId,
					[VersionDate],
					[SourceId],
					@BranchedTaskId,
					[IsAudit],
					[is_deprecated],
					[Owner],
					@NewProjectTeam,
					[FinishTime],
					[StartTime],
					[Comment],
					[High],
					[Medium],
					[Low],
					[Information],
					[RiskLevel],
					[QuantityLevel],
					[TopQuery1],
					[TopQuery1Count],
					[TopQuery1Severity],
					[TopQuery2],
					[TopQuery2Count],
					[TopQuery2Severity],
					[TopQuery3],
					[TopQuery3Count],
					[TopQuery3Severity],
					[TopQuery4],
					[TopQuery4Count],
					[TopQuery4Severity],
					[TopQuery5],
					[TopQuery5Count],
					[TopQuery5Severity],
					[is_Incremental],
					[ScanType],
					[ServerID],
					[QueuedOn],
					[Origin],
					[InitiatorName],
					[ProjectType],
					[QueryStateID],
					[EngineStartedOn],
		            [EngineFinishedOn],
		            [ScanRequestCreatedOn],
		            [ScanRequestCompletedOn],
					[StatisticsOutdated],
					[StatisticsCalcDate],
					[MethodMapFileExists]
				FROM @OriginalTaskScan

				SET IDENTITY_INSERT [TaskScans] OFF

			INSERT INTO [TaskScanEnvironment]
				SELECT
					[RunId],
					(SELECT TOP 1 [Id] FROM @BranchedTaskScanIds),
					(SELECT TOP 1 [Name] FROM @BranchedProject),
					[PresetName], --(SELECT TOP 1 [PresetName] FROM @BranchedTask),
					[Path],
					(SELECT TOP 1 [OwningTeamName] FROM @BranchedProject),
					[LOC],
					[FilesCount],
					[ProductVersion],
					[ForceScan],
					[is_deprecated],
					[PresetId],--(SELECT TOP 1 [PresetId] FROM @BranchedTask),
					[FailedLOC] 
				FROM @OriginalTaskScanEnvironment

			INSERT INTO [dbo].[PathResults]
				   ([ResultId]
				   ,[Path_Id]
				   ,[QueryVersionCode]
				   ,[Similarity_Hash]
				   ,[Compilation_Msgs]
				   ,[Debug_Msgs]
				   ,[Date])
				SELECT
					(SELECT TOP 1 [ResultId] FROM @BranchedTaskScanIds),
					[Path_Id],
					[QueryVersionCode],
					[Similarity_Hash],
					[Compilation_Msgs],
					[Debug_Msgs],
					[Date] 
				FROM @OriginalPathResults

			INSERT INTO [NodeResults] 
				SELECT
					(SELECT TOP 1 [ResultId] FROM @BranchedTaskScanIds),
					[Path_Id],
					[Node_Id],
					[Full_Name],
					[Short_Name],
					[File_Name],
					[Line],
					[Col],
					[Length],
					[DOM_Id],
					[Method_Line] 
				FROM @OriginalNodeResults
				
			-- Only copy labels if labels are configured per project, or labels are configured per team and the duplicated project is in a different team than the original project.
			-- If the new project is in the same team as the original project and labels are shared for the team, there is no point in duplicating them.
			IF @ResultLabelsArePerTeam = 'false' OR @OriginalProjectTeam <> @NewProjectTeam
				BEGIN
					DECLARE @BranchedResultLabels TABLE(
						[ID] [numeric](18, 0),
						[LabelType] [int],
						[ProjectId] [bigint],
						[ResultId] [bigint],
						[PathID] [bigint],
						[SimilarityId] [bigint],
						[NumericData] [int],
						[StringData] [nvarchar](max),
						[UpdateDate] [datetime],
						[UpdatingUser] [nvarchar](120) 
					)

					INSERT INTO [ResultsLabels]
						OUTPUT
							inserted.[ID],
							inserted.[LabelType],
							inserted.[ProjectId],
							inserted.[ResultId],
							inserted.[PathID],
							inserted.[SimilarityId],
							inserted.[NumericData],
							inserted.[StringData],
							inserted.[UpdateDate],
							inserted.[UpdatingUser] 
						INTO @BranchedResultLabels
						SELECT
							[OriginalResultLabels].[LabelType],
							@NewProjectId,
							CASE WHEN [OriginalResultLabels].[ResultId] = (SELECT TOP 1 [ResultId] FROM @OriginalTaskScan) THEN (SELECT TOP 1 [ResultId] FROM @BranchedTaskScanIds)
								ELSE -1
							END,
							CASE WHEN [OriginalResultLabels].[ResultId] = (SELECT TOP 1 [ResultId] FROM @OriginalTaskScan) THEN [OriginalResultLabels].[PathID]
								ELSE -1
							END,
							[OriginalResultLabels].[SimilarityId],
							[OriginalResultLabels].[NumericData],
							[OriginalResultLabels].[StringData],
							[OriginalResultLabels].[UpdateDate],
							[OriginalResultLabels].[UpdatingUser] 
						FROM @OriginalResultLabels [OriginalResultLabels]

					
					INSERT INTO [ResultsLabelsHistory] 
						SELECT
							[IdMapping].[NewID],
							[OriginalResultLabelHistory].[SeqID],
							[OriginalResultLabelHistory].[DateCreated],
							[OriginalResultLabelHistory].[CreatedBy],
							[OriginalResultLabelHistory].[Data] 
						FROM @OriginalResultLabelHistory [OriginalResultLabelHistory]
						INNER JOIN (
							-- Create a mapping between the old ResultsLabels and the new ResultsLabels that were duplicated, so that we can update the ID for the new ResultsLabelsHistory
							SELECT DISTINCT
								[orl].[ID] as [OldID],
								[nrl].[ID] as [NewID]
							FROM @OriginalResultLabels [orl]
							INNER JOIN @BranchedResultLabels [nrl]
								ON [orl].[LabelType] = [nrl].[LabelType]
								AND [orl].[ProjectId] = @OriginalProjectId AND [nrl].[ProjectId] = @NewProjectId
								AND [orl].[SimilarityId] = [nrl].[SimilarityId]
                                AND [orl].[UpdateDate] = [nrl].[UpdateDate]
						) [IdMapping]
						ON [OriginalResultLabelHistory].[ID] = [IdMapping].[OldID]

				END

			-- Only mark duplicated project as active if the entire duplication succeeded. Otherwise let it stay deleted.
			UPDATE Projects 
			SET is_deprecated = 0 
			WHERE ID = @NewProjectId

		COMMIT TRANSACTION
		UPDATE [ProjectBranchTree]
		SET [Status] = 2
		WHERE [Id] = @ProjectBranchTreeId

		SELECT 1

	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION
			END
		UPDATE [ProjectBranchTree]
		SET [Status] = 3
		WHERE [Id] = @ProjectBranchTreeId
		SELECT 0
	END CATCH
	SET CONTEXT_INFO 0x
END
go

