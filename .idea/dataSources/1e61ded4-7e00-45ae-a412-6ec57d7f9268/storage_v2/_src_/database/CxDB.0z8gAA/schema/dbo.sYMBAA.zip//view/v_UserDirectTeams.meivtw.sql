

CREATE VIEW [dbo].[v_UserDirectTeams]
WITH SCHEMABINDING
AS
	SELECT
		[DirectTeams].[TeamId],
		[DirectTeams].[TeamName],
		[DirectTeams].[TeamPath],
		[DirectTeams].[Is_Deprecated],
		[DirectTeams].[Level],
		[UsersTeams].[UserId] AS [UserId]
	FROM [dbo].[UsersTeams]
	INNER JOIN [dbo].[Teams] AS [DirectTeams]
		ON [DirectTeams].[TeamId] = [UsersTeams].[TeamId]
go

