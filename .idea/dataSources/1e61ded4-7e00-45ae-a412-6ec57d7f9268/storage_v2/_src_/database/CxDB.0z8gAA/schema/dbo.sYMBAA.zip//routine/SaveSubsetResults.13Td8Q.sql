 

CREATE PROCEDURE [dbo].[SaveSubsetResults]
	@ScanId AS BIGINT,
	@ProjectId AS BIGINT,
	@Origin AS NVARCHAR(150),
	@RunId AS NVARCHAR(255),
	@Comment AS NTEXT,
	@PathIds AS NVARCHAR(MAX) -- Comma separated list of path ids
AS

BEGIN
	DECLARE @sourceScanResultId BIGINT;
		
	SELECT @sourceScanResultId = [ResultId] FROM TaskScans WHERE Id = @ScanId

	-- New temp TaskScan Result Id table used for the new created TaskScan output
	DECLARE @newTaskScanIdsTable TABLE(
		[Id] BIGINT,
		[ResultId] BIGINT
	)
	
	-- New Created TaskScan Result Id and Id
	DECLARE @newTaskScanId BIGINT;
	DECLARE @newTaskScanResultId BIGINT;
	
	-- The subset scan will have the start time and finish time of current time
	DECLARE @dateTimeNow DATETIME;
	SET @dateTimeNow = GETDATE()
	
	-- Subset Scan Enum Value
	DECLARE @subsetScanType INT;
	SET @subsetScanType = 2
	
	-- Temp table for list of path id list
	DECLARE @PathIdsTable TABLE(
		[PathId] BIGINT
	)

	BEGIN TRANSACTION 
		-- lock scanRequests table to get the next ID from for TaskScans
		declare @tempId int 
		set  @tempId = (select top 1 id from ScanRequests with (tablockx));

		declare @NewScanRequestIdSeed bigint;
		set @NewScanRequestIdSeed = (SELECT IDENT_CURRENT('[dbo].[ScanRequests]') + IDENT_INCR('[dbo].[ScanRequests]'))
		DBCC CHECKIDENT('[dbo].[ScanRequests]', RESEED, @NewScanRequestIdSeed)
	COMMIT TRANSACTION

	BEGIN TRY
	
	BEGIN TRANSACTION
	
	-- Split path id comma separated list into temp table
	INSERT INTO @PathIdsTable (PathId)
		SELECT CONVERT(BIGINT, splitdata) FROM Split(@PathIds, ',')
	
	SET IDENTITY_INSERT [TaskScans] ON 

	-- Copy TaskScan and new created TaskScan Id into the temp table
	INSERT INTO [TaskScans] (
		[Id], [ProjectId],[VersionDate],[SourceId],[TaskId],[IsAudit],
		[is_deprecated],[Owner],[Owning_Team],[FinishTime],[StartTime],
		[Comment],[High],[Medium],[Low],[Information],[RiskLevel],[QuantityLevel],
		[TopQuery1],[TopQuery1Count],[TopQuery1Severity],[TopQuery2],[TopQuery2Count],[TopQuery2Severity],
		[TopQuery3],[TopQuery3Count],[TopQuery3Severity],[TopQuery4],[TopQuery4Count],
		[TopQuery4Severity],[TopQuery5],[TopQuery5Count],[TopQuery5Severity],
		[is_Incremental],[ScanType],[ServerID],[QueuedOn],[Origin],[InitiatorName],[ProjectType],[QueryStateID],
		[EngineStartedOn],[EngineFinishedOn],[ScanRequestCreatedOn],[ScanRequestCompletedOn],[StatisticsOutdated],[StatisticsCalcDate],[IsPublic])
    OUTPUT INSERTED.[Id],INSERTED.[ResultId] INTO @newTaskScanIdsTable
		SELECT 
			@NewScanRequestIdSeed, [ProjectId],[VersionDate],[SourceId],[TaskId],[IsAudit],
			[is_deprecated],[Owner],[Owning_Team], @dateTimeNow, @dateTimeNow,
			@Comment,[High],[Medium],[Low],[Information],[RiskLevel],[QuantityLevel],
			[TopQuery1],[TopQuery1Count],[TopQuery1Severity],[TopQuery2],[TopQuery2Count],[TopQuery2Severity],
			[TopQuery3],[TopQuery3Count],[TopQuery3Severity],[TopQuery4],[TopQuery4Count],
			[TopQuery4Severity],[TopQuery5],[TopQuery5Count],[TopQuery5Severity],
			[is_Incremental],@subsetScanType,[ServerID],[QueuedOn],@Origin,[InitiatorName],[ProjectType],[QueryStateID] ,
			[EngineStartedOn],[EngineFinishedOn],[ScanRequestCreatedOn],[ScanRequestCompletedOn],[StatisticsOutdated],[StatisticsCalcDate],[IsPublic]
		FROM [TaskScans] 
		WHERE [ProjectId] = @ProjectId AND [Id] = @ScanId

	SET IDENTITY_INSERT [TaskScans] OFF 
	
	SELECT TOP 1 @newTaskScanId = [Id], @newTaskScanResultId = [ResultId] FROM @newTaskScanIdsTable

	-- Copy TaskScanEnvironment
	INSERT INTO [TaskScanEnvironment](
		[RunId],[ScanId],[ProjectName],[PresetName],[Path],
		[TeamName],[LOC],[FilesCount],[ProductVersion],[ForceScan],
		[is_deprecated],[PresetId],[FailedLOC]
	)
		SELECT 
			@RunId,@newTaskScanId,[ProjectName],[PresetName],[Path],
			[TeamName],[LOC],[FilesCount],[ProductVersion],[ForceScan],
			[is_deprecated],[PresetId],[FailedLOC]
		FROM [TaskScanEnvironment]
		WHERE [ScanId] = @ScanId
	
	
	-- Copy Path Results		
	INSERT INTO [PathResults] (
		[ResultId],[Path_Id],[QueryVersionCode],[Similarity_Hash],[Compilation_Msgs],[Debug_Msgs],[Date],[ConfidenceLevel]
	)
	SELECT 
		@newTaskScanResultId,[Path_Id],[QueryVersionCode],[Similarity_Hash],[Compilation_Msgs],[Debug_Msgs],[Date],[ConfidenceLevel]
	FROM [PathResults]
	WHERE [ResultId] = @sourceScanResultId AND [Path_Id] IN (SELECT [PathId] FROM @PathIdsTable)
	
	--Copy Node Results
	INSERT INTO [NodeResults] (
		[ResultId],[Path_Id],[Node_Id],[Full_Name],[Short_Name],[File_Name],[Line],[Col],[Length],[DOM_Id],[Method_Line]
	)
	SELECT 
		@newTaskScanResultId,[Path_Id],[Node_Id],[Full_Name],[Short_Name],[File_Name],[Line],[Col],[Length],[DOM_Id],[Method_Line]
	FROM [NodeResults] 
	WHERE [ResultId] = @sourceScanResultId AND [Path_Id] IN (SELECT [PathId] FROM @PathIdsTable)
	
	-- Return new TaskScan Id value from the stored procedure
	SELECT @newTaskScanId AS newTaskScanId
	
  COMMIT TRANSACTION
  
  END TRY
  BEGIN CATCH
     IF @@TRANCOUNT > 0
          BEGIN
                ROLLBACK TRANSACTION
          END
      
     SELECT -1 AS newTaskScanId -- in case of error return new scan id = -1       
  END CATCH
END
go

