

CREATE PROCEDURE [dbo].[DataRetentionCalcDeprecatedScansToDelete]
AS
BEGIN  
    SELECT
		[TaskScans].[ProjectId],
		[TaskScans].[Id] as [ScanId],
		[TaskScans].[SourceId],
		[TaskScans].[TaskId],
		[TaskScans].[ScanType],
		[ScansReports].[ReportPath]
    FROM [TaskScans] 
	LEFT JOIN [ScansReports] ON [TaskScans].[Id] = [ScansReports].[ScanID] 
    WHERE [TaskScans].[is_deprecated] = 1
    ORDER BY [TaskScans].[ProjectId], [TaskScans].[Id], [TaskScans].[VersionDate]
END
go

