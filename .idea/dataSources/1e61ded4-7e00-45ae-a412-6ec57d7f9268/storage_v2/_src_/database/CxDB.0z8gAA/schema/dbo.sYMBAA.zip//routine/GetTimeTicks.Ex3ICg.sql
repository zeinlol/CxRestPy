  

CREATE FUNCTION GetTimeTicks
(
	@Time datetime = NULL
)
RETURNS bigint
AS
BEGIN
	DECLARE @Result bigint;
	DECLARE @TicksToEpoch bigint;
	DECLARE @TicksInMillisecond bigint;
	DECLARE @TicksInDay bigint;
	SET @TicksToEpoch = 621355968000000000;
	SET @TicksInMillisecond = 10000;
	SET @TicksInDay = 864000000000;
	
	DECLARE @DaysSinceEpoch int;
	DECLARE @MillisecondsSinceMidnight int;
	
	IF @Time IS NULL
	BEGIN
		SET @Time = GETUTCDATE();
	END

	SET @DaysSinceEpoch = DATEDIFF(D, '1970-01-01', @Time);
	SET @MillisecondsSinceMidnight = DATEDIFF(MS, DATEADD(DAY, DATEDIFF(DAY, 0, @Time), 0), @Time)

	SET @Result = @TicksToEpoch + (@DaysSinceEpoch * @TicksInDay) + (@MillisecondsSinceMidnight * @TicksInMillisecond)

	RETURN @Result
END
go

