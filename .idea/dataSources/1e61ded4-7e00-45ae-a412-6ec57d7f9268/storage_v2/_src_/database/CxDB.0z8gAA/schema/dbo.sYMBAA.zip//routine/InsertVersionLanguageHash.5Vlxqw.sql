

CREATE PROCEDURE [dbo].[InsertVersionLanguageHash] -- Alter the SP Always
	@Language int ,
	@LanguageName nvarchar(225),
	@Hash nvarchar(16)
AS
BEGIN
	
	-- Create the table if not exist (not using actual temp table because of faulty suport in VISTA)
	IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'TEMP_VersionLanguageHashState' )
	   create TABLE TEMP_VersionLanguageHashState ( [Language] [int] NOT NULL,
													[LanguageName] [nvarchar](225) NOT NULL,
													[Hash] [nvarchar](16) NOT NULL)

    -- Insert statements for procedure here
	INSERT INTO TEMP_VersionLanguageHashState ([Language],[LanguageName],[Hash]) VALUES (@Language, @LanguageName, @Hash)
END
go

