CREATE VIEW [CxEntities].[QueryLanguage]
AS
	SELECT 
		[QueryLanguageStates].[ID] AS [VersionId],
		[QueryLanguageStates].[Language] AS [LanguageId],
		[QueryLanguageStates].[LanguageName] AS [LanguageName],
		[QueryLanguageStates].[StateHash] AS [VersionHash],
		[QueryLanguageStates].[StateCreationDate] AS [VersionDate]
	FROM [dbo].[QueryLanguageStates]
go

