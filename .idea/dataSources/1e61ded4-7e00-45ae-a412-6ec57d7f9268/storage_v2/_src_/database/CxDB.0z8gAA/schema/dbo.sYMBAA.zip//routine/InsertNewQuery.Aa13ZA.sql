

--------------------- Removed Try-Catch from InsertQuery SP (Catching exception from code): START ----------------------
CREATE PROCEDURE [dbo].[InsertNewQuery] 
	@PackageID AS BIGINT,
	@Name AS NVARCHAR(255),
	@Source AS NVARCHAR(MAX),
	@Cwe AS BIGINT,
	@Severity AS INT,
	@IsExecutable AS BIT,
	@IsEncrypted AS BIT,
	@IsCompiled AS BIT,
	@Comments AS NVARCHAR(500) = null,
	@DraftSource AS NVARCHAR(MAX) = null,
	@CurrentUserName AS NVARCHAR(255) = null,
	@CxDescriptionID AS INT = 0,
	@EngineMetadata AS VARCHAR(2048) = null,
	@NewVersionCode AS BIGINT OUTPUT,
	@QueryId AS BIGINT OUTPUT
	AS

BEGIN
	BEGIN TRANSACTION

	BEGIN TRY

		DECLARE @SourceId AS BIGINT;
		DECLARE @LastQueryVersion AS BIGINT = 1;
		DECLARE @QueryMaxId AS BIGINT;
		DECLARE @IdSeed AS BIGINT;

		IF @QueryId <> -1
		BEGIN
			SET IDENTITY_INSERT [Query] ON;

			INSERT INTO Query ([QueryId],[PackageId],[Name],
							[Source],[Cwe],
							[Severity],[isExecutable], 
							[IsEncrypted], [IsCompiled], 
							[Comments], [DraftSource], 
							[CurrentUserName], [is_deprecated], 
							[IsCheckOut], [UpdateTime],
							[CxDescriptionID], [EngineMetadata]) 
			VALUES (@QueryId,@PackageID, @Name,
					@Source, @Cwe,
					@Severity, @IsExecutable,
					@IsEncrypted, @IsCompiled, 
					@Comments, @DraftSource, 
					@CurrentUserName, 0, 
					0, GETDATE(),
					@CxDescriptionID,
					@EngineMetadata)

		
			SET IDENTITY_INSERT [Query] OFF;
		END
		ELSE

		BEGIN
			--BEGIN avoid identity being invalid
			SELECT @QueryMaxId = MAX(QueryId) from Query
			SELECT @IdSeed = IDENT_SEED('Query')

			--Set identifier to be the seed
			DBCC CHECKIDENT (Query, RESEED, @IdSeed) 
			IF @QueryMaxId > @IdSeed 
			BEGIN
				--If we have values over the seed value we will set the identifier to that value.
				DBCC CHECKIDENT (Query, RESEED) 
			END
			-- END avoid identity being invalid

			INSERT INTO Query ([PackageId],[Name],
							[Source],[Cwe],
							[Severity],[isExecutable], 
							[IsEncrypted], [IsCompiled], 
							[Comments], [DraftSource], 
							[CurrentUserName], [is_deprecated], 
							[IsCheckOut], [UpdateTime],
							[CxDescriptionID], [EngineMetadata]) 
			VALUES (@PackageID, @Name,
					@Source, @Cwe,
					@Severity, @IsExecutable,
					@IsEncrypted, @IsCompiled, 
					@Comments, @DraftSource, 
					@CurrentUserName, 0, 
					0, GETDATE(),
					@CxDescriptionID,
					@EngineMetadata)
					
			SET @QueryID = SCOPE_IDENTITY();
		END

		SELECT @SourceID = Id FROM QuerySource WHERE Source COLLATE Latin1_General_CS_AS = @Source

		IF @SourceId IS NULL

		BEGIN

			INSERT INTO QuerySource ([Source])
			VALUES (@Source)

			SET @SourceId = SCOPE_IDENTITY();

		END

		SELECT TOP 1 @LastQueryVersion = (QueryVersion.[Version] + 1) FROM QueryVersion  WHERE QueryId = @QueryID ORDER BY [Version] DESC;		
		
		SELECT @NewVersionCode = dbo.fnQueryVersionCode(@QueryID, @LastQueryVersion);

		INSERT INTO QueryVersion ([PackageId], [Name], 
								[QuerySourceId], [Cwe],
								[Severity], [isExecutable],
								[isEncrypted], [IsCompiled],
								[Comments], [CurrentUserName],
								[IsActive], [IsCheckOut],
								[UpdateTime], [Version],
								[QueryId], [QueryVersionCode],
								[CxDescriptionID], [EngineMetadata])
		VALUES (@PackageID, @Name,
				@SourceId, @Cwe,
				@Severity, @IsExecutable,
				@IsEncrypted, @IsCompiled,
				@Comments, @CurrentUserName,
				1, 0,
				GETDATE(), @LastQueryVersion,
				@QueryId, @NewVersionCode,
				@CxDescriptionID,
				@EngineMetadata)

	
		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH

		ROLLBACK TRANSACTION
		
		SELECT @NewVersionCode = -1;
		
		DECLARE @ErrorMessage NVARCHAR(4000);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT;  

		SELECT   
			@ErrorMessage = ERROR_MESSAGE(),  
			@ErrorSeverity = ERROR_SEVERITY(),  
			@ErrorState = ERROR_STATE();  

		RAISERROR (@ErrorMessage,
				   @ErrorSeverity,
				   @ErrorState
				   );  

	END CATCH
	              
END

go

