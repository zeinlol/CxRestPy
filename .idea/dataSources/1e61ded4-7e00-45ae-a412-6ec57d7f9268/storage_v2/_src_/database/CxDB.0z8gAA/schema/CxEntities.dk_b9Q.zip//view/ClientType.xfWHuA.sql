CREATE VIEW [CxEntities].[ClientType]
AS
	SELECT 
		[Types].[Id],
		[Types].[Name]
	FROM (VALUES
		(0, 'Unknown'),
		(1, 'Web Portal'),
		(2, 'CLI'),
		(3, 'Eclipse'),
		(4, 'VS'),
		(5, 'IntelliJ'),
		(6, 'Audit'),
		(7, 'SDK'),
		(8, 'Jenkins')
	) AS [Types]([Id], [Name])
go

