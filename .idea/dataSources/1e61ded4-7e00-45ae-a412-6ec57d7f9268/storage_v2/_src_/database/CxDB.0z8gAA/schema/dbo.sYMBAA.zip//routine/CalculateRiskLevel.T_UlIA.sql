 

CREATE FUNCTION [dbo].[CalculateRiskLevel]
(
	-- Add the parameters for the function here
	@LowSeverityCount int = 0,
	@MediumSeverityCount int = 0,
	@HighSeverityCount int = 0
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @highDecrement int;
	DECLARE @mediumDecrement int;
	DECLARE @lowDecrement int;

	
	DECLARE @RiskLevel int;

	IF(@HighSeverityCount > 20)
	BEGIN		
		SELECT @highDecrement = CASE WHEN (@HighSeverityCount - 20) * 1.5 < 100 THEN (@HighSeverityCount - 20) * 1.5 ELSE 100 END;
	END
	ELSE
	BEGIN
		SELECT @highDecrement =  (@HighSeverityCount*3);
	END	
	
	SELECT @mediumDecrement = CASE WHEN @MediumSeverityCount * 1.5 < 30 THEN @MediumSeverityCount * 1.5 ELSE 30 END;
	SELECT @lowDecrement = CASE WHEN @LowSeverityCount * 0.5 < 10 THEN @LowSeverityCount * 0.5 ELSE 10 END;

	-- Summerize the risk level, maxing out at 100
	SELECT @RiskLevel =  CASE WHEN (@lowDecrement + @mediumDecrement + @highDecrement) < 100 THEN @lowDecrement + @mediumDecrement + @highDecrement ELSE 100 END;

	RETURN @RiskLevel;
END
go

