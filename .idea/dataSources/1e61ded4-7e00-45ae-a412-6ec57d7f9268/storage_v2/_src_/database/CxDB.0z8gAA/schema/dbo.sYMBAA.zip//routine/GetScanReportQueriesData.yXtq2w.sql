    

CREATE PROCEDURE [dbo].[GetScanReportQueriesData]
    @ScanID AS BIGINT,
       @LCID AS BIGINT,
       @QueriesFilter AS NVARCHAR(MAX)
AS
BEGIN
       
       DECLARE @ScanResultID as bigint;

       SELECT @ScanResultID = ResultId FROM TaskScans WHERE TaskScans.Id = @ScanID

       SELECT  QueryVersion.QueryId AS QueryId,
                     REPLACE(QueryVersion.Name,'_',' ') As QueryName,
                     QueryVersion.Severity AS QuerySeverity,
                     REPLACE(QueryGroup.Name, '_',' ') AS QueryGroup,
                     Teams.TeamName, 
                     Teams.TeamID,
                     Projects.Name ProjectName, 
                     QueryVersion.[Version], 
                     QueryGroup.PackageType AS [Type],
                     QueryGroup.Language AS QueryLanguageID,
                     QueryGroup.LanguageName AS QueryLanguageName,
                                  CustomDescriptions.CustomDescriptionID,
                     CxQueryDescription.CxDescriptionID,
                     CxQueryDescription.ResultDescription,
                     CxQueryDescription.BestFixLocation,
                     CxQueryDescription.Risk,
                     CxQueryDescription.Cause,
                     CxQueryDescription.GeneralRecommendations,                                                           
               CASE WHEN CxQueryDescription.CxDescriptionID IS NULL  THEN Cwe.DocxFile END AS CweDescription,
               QueryVersion.Cwe As CweID,
                     QueryVersion.QueryVersionCode AS QueryVersionCode,
                                  ScanStatistics.BestFixLocationAmount AS BestFixLocationAmount
       FROM   QueryVersion  
       INNER JOIN (SELECT QueryVersionCode FROM PathResults WHERE PathResults.ResultId = @ScanResultID GROUP BY PathResults.QueryVersionCode) AS ScanQueries ON ScanQueries.QueryVersionCode = QueryVersion.QueryVersionCode
       INNER JOIN QueryGroup ON QueryGroup.PackageId = QueryVersion.PackageId
       LEFT JOIN Projects ON QueryGroup.Project_Id = Projects.Id
       LEFT JOIN Teams ON QueryGroup.Owning_Team = Teams.TeamId
          LEFT JOIN CustomDescriptions ON CustomDescriptionS.QueryID =  QueryVersion.QueryId AND CustomDescriptionS.LanguageID = @LCID
       LEFT JOIN     CxQueryDescription  ON QueryVersion.CxDescriptionID=CxQueryDescription.CxDescriptionID AND CxQueryDescription.LCID = @LCID AND CustomDescriptions.CustomDescriptionID IS NULL
          LEFT JOIN ScanStatistics ON QueryVersion.QueryId = ScanStatistics.QueryId AND ScanStatistics.ScanId = @ScanID
       LEFT JOIN      (SELECT ISNULL(lang.CweId, english.CweId) as CweId,
                                         ISNULL(lang.Description, english.Description) as Description,
                                         ISNULL(lang.DocxFile, english.DocxFile) as DocxFile
                              FROM cwe english
                              LEFT OUTER JOIN   (select * 
                                                               from cwe
                                                              where cwe.LanguageId = @LCID) as lang
                              ON english.CweId = lang.CweId
                              WHERE english.LanguageId = 1033 /* english LCID*/) as Cwe
       ON Cwe.CweId = QueryVersion.Cwe AND CxQueryDescription.CxDescriptionID IS NULL AND CustomDescriptions.CustomDescriptionID IS NULL
       WHERE (@QueriesFilter IS NULL OR QueryVersion.QueryId IN(SELECT * FROM Split(@QueriesFilter,',')) )
END

go

