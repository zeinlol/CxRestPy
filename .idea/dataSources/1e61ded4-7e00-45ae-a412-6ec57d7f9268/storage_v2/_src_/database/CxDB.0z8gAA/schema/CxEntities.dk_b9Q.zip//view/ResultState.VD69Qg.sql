CREATE VIEW [CxEntities].[ResultState]
AS
	SELECT 
		CAST([ResultState].[Id] AS int) AS [Id],
		[ResultState].[Name] AS [Name]
	FROM [dbo].[ResultState]
	WHERE [ResultState].[is_deprecated] = 0 
		AND [LanguageId] = 1033
go

