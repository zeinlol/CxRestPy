CREATE VIEW [dbo].[v_TeamLabels]
WITH SCHEMABINDING
AS
	SELECT 
		[ResultsLabels].[ID],
		[ResultsLabels].[LabelType],
		[ResultsLabels].[ProjectId],
		[Projects].[Owning_Team] AS [TeamId],
		[ResultsLabels].[ResultId],
		[ResultsLabels].[PathID],
		[ResultsLabels].[SimilarityId],
		[ResultsLabels].[NumericData],
		[ResultsLabels].[StringData],
		[ResultsLabels].[UpdateDate],
		[ResultsLabels].[UpdatingUser]
	FROM [dbo].[ResultsLabels]
	INNER JOIN [dbo].[Projects] 
		ON [ResultsLabels].[ProjectId] = [Projects].[Id]
	WHERE [Projects].[is_deprecated] = 0
		AND [ResultsLabels].[SimilarityId] <> 0
go

