 

CREATE PROCEDURE [dbo].[GetResultsByScan] 

	@ScanId AS BIGINT,
	@IncludeFalsePositives BIT = 1,
	@ProjectId AS BIGINT = NULL,
	@TeamId AS NVARCHAR(50) = NULL,
	@QueryId AS BIGINT = NULL,
	@Severity INT = NULL,
	@Language AS NVARCHAR(50) = NULL
AS

BEGIN

	-- If we include false positive no need to filter the paths
	IF @IncludeFalsePositives = 1
	BEGIN
	    SELECT TaskScans.Id nScanId, NodeResults.Path_Id nPath_Id, NodeResults.Node_Id nNode_Id,
		NodeResults.Full_Name nFull_Name, NodeResults.Short_Name nShort_Name, NodeResults.File_Name nFile_Name,
		NodeResults.Line nLine, NodeResults.Col nColumn, NodeResults.Length nLength, NodeResults.DOM_Id nDOM_Id, NodeResults.Method_Line nMethod_Line,
		PathResults.Path_Id pPath_Id, PathResults.QueryVersionCode pQueryVersionCode, PathResults.Similarity_Hash pSimilarity_Hash, PathResults.ConfidenceLevel,
		QueryVersion.Name qName, QueryVersion.QueryId qQueryId, QueryVersion.Cwe qCwe, QueryVersion.Severity qSeverity, QueryVersion.PackageId  qPackageId 
		FROM PathResults
		INNER JOIN QueryVersion On  QueryVersion.QueryVersionCode = PathResults.QueryVersionCode
		AND ((@Severity IS NULL) OR QueryVersion.Severity = @Severity) 
		AND ((@Language IS NULL) OR (QueryVersion.PackageId IN (SELECT QueryGroup.PackageId FROM QueryGroup WHERE QueryGroup.LanguageName = @Language)))
		INNER JOIN TaskScans ON PathResults.ResultId = TaskScans.ResultId AND TaskScans.Id = @ScanId
		INNER JOIN NodeResults ON NodeResults.Path_Id = PathResults.Path_Id 
		AND NodeResults.ResultId = PathResults.ResultId
		WHERE ((@QueryId IS NULL) OR QueryVersion.QueryId = @QueryId)
		ORDER BY PathResults.QueryVersionCode, PathResults.Path_Id, NodeResults.Node_Id	
	END	
	ELSE	
		-- If we don't include false positives filter the paths using the latest labels for them
	BEGIN
		-- In order to filter false positives we require the scan team and project
		IF (@ProjectId IS NOT NULL) AND (@TeamId IS NOT NULL)
		BEGIN
		
			DECLARE @StatePerTeams AS BIT;	
	
			---Set states per project or per team by system configuration
			SELECT @StatePerTeams = (CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END)
			FROM CxComponentConfiguration 
			WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY';

			DECLARE @ScanResultsLabels TABLE
			(
			   SimilarityID BIGINT NOT NULL,
			   LabelType BIGINT NOT NULL,
			   NumericData INT,
			   ProjectId BIGINT,
			   UpdateDate datetime
			);

			IF @StatePerTeams = 0
			BEGIN
				INSERT @ScanResultsLabels (SimilarityID ,LabelType, NumericData, ProjectId, UpdateDate)
				SELECT SimilarityID ,LabelType , NumericData , ProjectId, UpdateDate 
				FROM  ResultsLabels 
				WHERE (LabelType = 3 OR LabelType = 0)
				AND ProjectId = @ProjectId 
			END
			ELSE
			BEGIN
				INSERT @ScanResultsLabels (SimilarityID ,LabelType, NumericData, ProjectId, UpdateDate)
				SELECT SimilarityID ,LabelType , NumericData , ProjectId, UpdateDate 
				FROM  ResultsLabels 
				WHERE (LabelType = 3 OR LabelType = 0)
				AND [ProjectId] IN ( SELECT [Projects].Id From [Projects] where [Projects].Owning_Team = @TeamId)
			END;

		
			-- Filter false positives by last updated label

			WITH scanPathsWithLabels AS
			 (
				SELECT scanPaths.[ResultId] as ResultId, scanPaths.[Path_Id] as Path_Id, scanPaths.QueryVersionCode as QueryVersionCode, scanPaths.Similarity_Hash as Similarity_Hash, scanPaths.ConfidenceLevel,
					   case when labels.[NumericData] = 1 then 1 else 0 end as IsFalsePositive,
					   row_number() over (partition by scanPaths.[Path_Id] order by labels.[UpdateDate] desc) AS RowNumber
				FROM [PathResults] scanPaths
				INNER JOIN TaskScans ON scanPaths.ResultId = TaskScans.ResultId AND TaskScans.Id = @ScanId
				INNER JOIN QueryVersion ON scanPaths.QueryVersionCode = QueryVersion.QueryVersionCode
				LEFT JOIN @ScanResultsLabels labels ON (scanPaths.Similarity_Hash = labels.SimilarityId )
				WHERE  scanPaths.[Similarity_Hash] <> 0 
					    AND ((@QueryId IS NULL) OR QueryVersion.QueryId = @QueryId)
		  )
		  SELECT @ScanId as nScanId, NodeResults.Path_Id nPath_Id, NodeResults.Node_Id nNode_Id,
		  NodeResults.Full_Name nFull_Name, NodeResults.Short_Name nShort_Name, NodeResults.File_Name nFile_Name,
		  NodeResults.Line nLine, NodeResults.Col nColumn, NodeResults.Length nLength, NodeResults.DOM_Id nDOM_Id, NodeResults.Method_Line nMethod_Line,
		  scanPathsWithLabels.Path_Id pPath_Id, scanPathsWithLabels.QueryVersionCode pQueryVersionCode, scanPathsWithLabels.Similarity_Hash pSimilarity_Hash, 
		  scanPathsWithLabels.ConfidenceLevel, QueryVersion.Name qName, QueryVersion.QueryId qQueryId, QueryVersion.Cwe qCwe, QueryVersion.Severity qSeverity, QueryVersion.PackageId  qPackageId 
		  FROM scanPathsWithLabels
		  INNER JOIN QueryVersion On  QueryVersion.QueryVersionCode = scanPathsWithLabels.QueryVersionCode
		  AND ((@Severity IS NULL) OR QueryVersion.Severity = @Severity)
		  AND ((@Language IS NULL) OR (QueryVersion.PackageId IN (SELECT QueryGroup.PackageId FROM QueryGroup WHERE QueryGroup.LanguageName = @Language)))
		  INNER JOIN NodeResults ON NodeResults.Path_Id = scanPathsWithLabels.Path_Id 
		  AND NodeResults.ResultId = scanPathsWithLabels.ResultId
		  WHERE [RowNumber] = 1 AND [IsFalsePositive] = 0  
		  ORDER BY scanPathsWithLabels.QueryVersionCode, scanPathsWithLabels.Path_Id, NodeResults.Node_Id
		  
		  END
	END                                                    
	              
END

go

