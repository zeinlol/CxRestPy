                             

CREATE PROCEDURE AddResultLabel
	-- Add the parameters for the stored procedure here
	@labelType int,
	@projectId bigint,
	@scanId bigint,
	@pathId bigint,
    @data nvarchar(max),
    @creatingUser nvarchar(120)
AS
BEGIN

	-- ResultLabelTypeEnum
	--  IgnorePath = 0     <- numeric
    --  Remark = 1         <- string
    --  Severity = 2       <- numeric
    --  State = 3          <- numeric
    --  Assign = 4         <- string
    --  IssueTracking = 5  <- string

	
	DECLARE @resultId bigint;

	DECLARE @similarityId bigint;	
	DECLARE @errorMessage bigint;

	DECLARE @isNumericData bit;
	DECLARE @numericData int;

	SET @isNumericData = 0;

	-- Get the scan's result Id
	SELECT @resultId = MAX([ResultId]) FROM [TaskScans] WHERE [Id] = @scanId 

	-- Get the path's similarity Id
	SELECT @similarityId = MAX([Similarity_Hash]) FROM [PathResults] WHERE [ResultId] = @resultId AND [Path_Id] = @pathId

	-- If no similarity id was found the input was invalid, throw an exception
	IF @similarityId is null
	BEGIN 
		SET @errorMessage = 'Path with Id ' + @pathId + ' not found for scan with Id' + @scanId;
		RAISERROR (@errorMessage, 11,1);
	END

	-- If this is a label that should be numeric make sure the data is numeric and parse it
	IF (@labelType = 0 or @labelType = 2 or @labelType = 3)
	BEGIN
	    -- If it's not numeric raise an exception
		IF NOT ISNUMERIC(@data) = 1
		BEGIN
			SET @errorMessage = 'Data for label type ' + @labelType + ' is expected to be numeric, please check your input';
			RAISERROR (@errorMessage, 11,1);
		END
		-- If it is numeric parse the value and mark the flag
		ELSE
		BEGIN
			SET @isNumericData = 1;
			SET @numericData =  CONVERT(int, @data);
		END
	END

		Declare @labelID table (ID numeric(18,0));
		Declare @updateTime Datetime;

		SET @updateTime = null;
		SET @updateTime = GetDate();

	SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
	BEGIN TRANSACTION

		-- Check if there's already a label for this similarity Id, if there is update it otherwise insert new record
			IF @isNumericData = 1
			BEGIN
			UPDATE [ResultsLabels]  with (serializable)
			SET [NumericData] = @numericData, [UpdateDate] = @updateTime, [UpdatingUser] = @creatingUser
			OUTPUT Inserted.[ID] into @labelID
			WHERE [LabelType] = @labelType AND [ProjectId] = @projectId AND [ResultId] = @resultId AND [SimilarityId] = @similarityId
			END
			ELSE
			BEGIN
			UPDATE [ResultsLabels]  with (serializable)
			SET [StringData] = @data, [UpdateDate] = @updateTime, [UpdatingUser] = @creatingUser
			OUTPUT Inserted.[ID] into @labelID
			WHERE [LabelType] = @labelType AND [ProjectId] = @projectId AND [ResultId] = @resultId AND [SimilarityId] = @similarityId
		END
		
		-- Check if rows were updated, if not insert a new label row
		IF NOT EXISTS(select * from @labelID)
		BEGIN	
			IF @isNumericData = 1
			BEGIN
				INSERT INTO [ResultsLabels] ([LabelType] ,[ProjectId] ,[ResultId] ,[PathID] ,[SimilarityId] ,[NumericData] ,[StringData] ,[UpdateDate], [UpdatingUser])
					 OUTPUT Inserted.[ID] into @labelID
				                     VALUES(@labelType, @projectId, @resultId, @pathId, @similarityId, @numericData, null, @updateTime,  @creatingUser)
			END
			ELSE
			BEGIN
				INSERT INTO [ResultsLabels] ([LabelType] ,[ProjectId] ,[ResultId] ,[PathID] ,[SimilarityId] ,[NumericData] ,[StringData] ,[UpdateDate], [UpdatingUser])
					 OUTPUT Inserted.[ID] into @labelID
				                     VALUES(@labelType, @projectId, @resultId, @pathId, @similarityId, null, @data, @updateTime,  @creatingUser)
			END
		END

		-- Insert the label into the label history
		-- We use insert by select to lock the table while incrementing the sub-sequance
		INSERT INTO [ResultsLabelsHistory] ([ID], [SeqID], [DateCreated], [CreatedBy], [Data])
		SELECT (SELECT MAX (ID) FROM @labelID) , CASE WHEN MAX([SeqID]) is null THEN 1 ELSE MAX([SeqID])+ 1 END, @updateTime,  @creatingUser, @data
		FROM [ResultsLabelsHistory] WHERE [ID] = (SELECT MAX (ID) FROM @labelID)

	COMMIT TRANSACTION

END
go

