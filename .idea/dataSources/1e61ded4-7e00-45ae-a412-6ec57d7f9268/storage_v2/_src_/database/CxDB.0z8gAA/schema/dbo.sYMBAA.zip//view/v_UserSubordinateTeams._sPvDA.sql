


CREATE VIEW [dbo].[v_UserSubordinateTeams]
WITH SCHEMABINDING
AS
	SELECT
		[SubordinateTeams].[TeamId],
		[SubordinateTeams].[TeamName],
		[SubordinateTeams].[TeamPath],
		[SubordinateTeams].[Is_Deprecated],
		[SubordinateTeams].[Level],
		[UsersTeams].[UserId] AS [UserId]
	FROM [dbo].[UsersTeams]
	INNER JOIN [dbo].[Teams] AS [DirectTeams]
		ON [DirectTeams].[TeamId] = [UsersTeams].[TeamId]
	INNER JOIN [dbo].[Teams] AS [SubordinateTeams]
		ON SUBSTRING([SubordinateTeams].[TeamPath], 1, LEN([DirectTeams].[TeamPath] + [DirectTeams].[TeamId])) = ([DirectTeams].[TeamPath] + [DirectTeams].[TeamId])
go

