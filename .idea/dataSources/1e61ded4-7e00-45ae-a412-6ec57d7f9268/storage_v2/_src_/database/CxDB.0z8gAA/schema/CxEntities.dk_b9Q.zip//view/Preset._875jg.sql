CREATE VIEW [CxEntities].[Preset]
AS
	SELECT 
		[Presets].[Id] AS [Id],
		[Presets].[Name] AS [Name],
		ISNULL(CAST(CASE WHEN [Presets].[Owner] = 'CxUser' THEN 1 ELSE 0 END AS bit), 0) AS [IsSystemPreset]
	FROM [dbo].[Presets]
go

