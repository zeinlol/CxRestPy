

-- =============================================
-- Author:		Dima Abramchaev
-- Create date: 2015-08-26
-- Description:	This stored procedure calculates the number of New/Recurrent/Resolved issues between two given scans.
-- Use the @GroupBySeverity @GroupByState and @IncludeNotExplotable parameters to create cross-sections for the results.
-- Note: Liat Rudner 2016-02-17 I eliminated the use of [v_PathResultsWithLabelData] due to performance problems
-- =============================================
CREATE PROCEDURE [dbo].[GetCompareScansSummary]
	@NewScanId bigint, -- The newer scan Id
	@OldScanId bigint, -- The older scan Id
	@IncludeNotExploitable bit = 0, -- Set to true to include not exploitable results; false otherwise.
	@GroupBySeverity bit = 0, -- Set to true to partition results by severity; false otherwise.
	@GroupByState bit = 0, -- Set to true to partition results by state; false otherwise.
	@GroupByQuery bit = 0 -- Set to true to partition results by query; false otherwise.
AS
BEGIN
	
	DECLARE @NewTeamId nvarchar(50); 
	DECLARE @OldTeamId nvarchar(50); 
	DECLARE @NewProjectId bigint; 
	DECLARE @OldProjectId bigint;	 
	select @NewProjectId = ProjectId, @NewTeamId = Owning_Team from TaskScans where Id = @NewScanId;
	select @OldProjectId = ProjectId, @OldTeamId = Owning_Team from TaskScans where Id = @OldScanId;
	
	DECLARE @LabelPerTeams AS BIT;	
	SELECT @LabelPerTeams = (CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END)
	FROM CxComponentConfiguration 
	WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY';

	DECLARE @ScanResultsLabels TABLE
	(
		SimilarityID BIGINT NOT NULL,
		LabelType BIGINT NOT NULL,
		NumericData INT,
		ProjectId BIGINT,
		UpdateDate datetime,
		PRIMARY KEY CLUSTERED (SimilarityID, LabelType, ProjectId)
	);

	IF @LabelPerTeams = 0
		BEGIN
			INSERT @ScanResultsLabels (SimilarityID ,LabelType, NumericData, ProjectId, UpdateDate)
			SELECT SimilarityID ,LabelType , NumericData , ProjectId, UpdateDate FROM
				(SELECT SimilarityID, LabelType, NumericData, ProjectId, UpdateDate,
					row_number() over (partition by SimilarityID, LabelType order by UpdateDate desc) AS RowNumber
					FROM  ResultsLabels 
					WHERE LabelType in (0,2,3)
					AND ProjectId in (@NewProjectId, @OldProjectId)) AS Labels
			 WHERE Labels.RowNumber = 1				
		END		
	ELSE
		BEGIN
			INSERT @ScanResultsLabels (SimilarityID ,LabelType, NumericData, ProjectId, UpdateDate)
			SELECT SimilarityID ,LabelType , NumericData , ProjectId, UpdateDate FROM
				(SELECT SimilarityID, LabelType, NumericData, ProjectId, UpdateDate,
					row_number() over (partition by SimilarityID, LabelType  order by UpdateDate desc) AS RowNumber
				FROM  ResultsLabels 
				WHERE LabelType in (0,2,3) 
				AND [ProjectId] IN ( SELECT [Projects].Id From [Projects] where [Projects].Owning_Team in (@OldTeamId, @NewTeamId))) AS stateLabels
			WHERE stateLabels.RowNumber = 1
		END;

	DECLARE @PathResultsWithLabelData TABLE
	(
		ScanId bigint NOT NULL,
		SimilarityID BIGINT NOT NULL,
		[QueryId] BIGINT NOT NULL,
		[Severity] INT,
		[State] INT
	);

	INSERT @PathResultsWithLabelData (ScanId, SimilarityID ,[QueryId], [Severity], [State])
	SELECT	TaskScans.Id, 
			PathResults.Similarity_Hash as Similarity_Hash, 
			QueryVersion.QueryId, 
			ISNULL(severitylabels.NumericData, QueryVersion.Severity) as severity, 
			ISNULL(statelabels.[NumericData], 0) AS [State]			
	FROM [PathResults]
	INNER JOIN TaskScans ON [PathResults].ResultId = TaskScans.ResultId AND TaskScans.Id in (@NewScanId, @OldScanId)
	INNER JOIN QueryVersion ON [PathResults].QueryVersionCode = QueryVersion.QueryVersionCode	
	LEFT JOIN @ScanResultsLabels statelabels ON ([PathResults].Similarity_Hash = statelabels.SimilarityId AND statelabels.LabelType in (0,3))
	LEFT JOIN @ScanResultsLabels severitylabels ON ([PathResults].Similarity_Hash = severitylabels.SimilarityId AND severitylabels.LabelType = 2)
	WHERE  [PathResults].[Similarity_Hash] <> 0 
					    

	SET NOCOUNT ON;

	WITH [CurrentResults_CTE] AS
	(
		SELECT 
			[SimilarityId],
			CASE WHEN @GroupByQuery = 1 THEN [QueryId] ELSE NULL END AS [Query],
			CASE WHEN @GroupBySeverity = 1 THEN [Severity] ELSE NULL END AS [Severity],
			CASE WHEN @GroupByState = 1 THEN [State] ELSE NULL END AS [State],
			COUNT(*) AS [Count]
		FROM @PathResultsWithLabelData
		WHERE [ScanId] = @NewScanId
			AND (
					@IncludeNotExploitable = 1 
					OR [State] <> 1 -- 1 = Not Exploitable
				)
		GROUP BY [SimilarityId], 
			CASE WHEN @GroupByQuery = 1 THEN [QueryId] ELSE NULL END,
			CASE WHEN @GroupBySeverity = 1 THEN [Severity] ELSE NULL END,
			CASE WHEN @GroupByState = 1 THEN [State] ELSE NULL END
	), [PreviousResults_CTE] AS
	(
		SELECT 
			[SimilarityId],
			CASE WHEN @GroupByQuery = 1 THEN [QueryId] ELSE NULL END AS [Query],
			CASE WHEN @GroupBySeverity = 1 THEN [Severity] ELSE NULL END AS [Severity],
			CASE WHEN @GroupByState = 1 THEN [State] ELSE NULL END AS [State],
			COUNT(*) AS [Count]
		FROM @PathResultsWithLabelData
		WHERE [ScanId] = @OldScanId
			AND (
					@IncludeNotExploitable = 1 
					OR [State] <> 1 -- 1 = Not Exploitable
				)
		GROUP BY [SimilarityId], 
			CASE WHEN @GroupByQuery = 1 THEN [QueryId] ELSE NULL END,
			CASE WHEN @GroupBySeverity = 1 THEN [Severity] ELSE NULL END,
			CASE WHEN @GroupByState = 1 THEN [State] ELSE NULL END
	)
	SELECT 
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[Query] ELSE [r1].[Query] END AS [Query],
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[Severity] ELSE [r1].[Severity] END AS [Severity],
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[State] ELSE [r1].[State] END AS [State],
		ISNULL(SUM(CASE WHEN [r2].[SimilarityId] IS NULL THEN [r1].[Count] ELSE CASE WHEN [r2].[Count] < ISNULL([r1].[Count], 0) THEN [r1].[Count] - [r2].[Count] ELSE 0 END END), 0) AS [Resolved],
		ISNULL(SUM(CASE WHEN [r1].[SimilarityId] IS NOT NULL AND [r2].[SimilarityId] IS NOT NULL THEN CASE WHEN [r1].[Count] < [r2].[Count] THEN [r1].[Count] ELSE [r2].[Count] END ELSE 0 END), 0) AS [Recurrent],
		ISNULL(SUM(CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[Count] ELSE CASE WHEN [r1].[Count] < ISNULL([r2].[Count], 0) THEN [r2].[Count] - [r1].[Count] ELSE 0 END END), 0) AS [New]
	FROM [PreviousResults_CTE] [r1]
	FULL OUTER JOIN [CurrentResults_CTE] [r2] 
		ON [r1].[SimilarityId] = [r2].[SimilarityId]
		AND (([r1].[Severity] IS NULL AND [r2].[Severity] IS NULL) OR [r1].[Severity] = [r2].[Severity])
		AND (([r1].[State] IS NULL AND [r2].[State] IS NULL) OR [r1].[State] = [r2].[State])
	GROUP BY 
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[Query] ELSE [r1].[Query] END,
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[Severity] ELSE [r1].[Severity] END,
		CASE WHEN [r1].[SimilarityId] IS NULL THEN [r2].[State] ELSE [r1].[State] END
	ORDER BY [Query], [Severity], [State]
END
go

