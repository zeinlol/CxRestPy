CREATE VIEW [CxEntities].[Scan]
AS
SELECT
    [TaskScans].[Id] AS [Id], 
	[TaskScans].[SourceId] AS [SourceId], 
	[TaskScans].[Comment] AS [Comment],
	[TaskScans].[is_Incremental] AS [IsIncremental],
	[TaskScans].[ScanType] AS [ScanType],
	[OwningUser].[ID] AS [OwnerId],
	[TaskScans].[Owning_Team] AS [OwningTeamId],

	[TaskScans].[InitiatorName] AS [InitiatorName],
	[TaskScanEnvironment].[ProjectName] AS [ProjectName],
	[TaskScanEnvironment].[PresetName] AS [PresetName],
	[TaskScanEnvironment].[TeamName] AS [TeamName],
	[TaskScanEnvironment].[Path] AS [Path],
	[TaskScanEnvironment].[FilesCount] AS [FileCount],
	[TaskScanEnvironment].[LOC] AS [LOC],
	[TaskScanEnvironment].[FailedLOC] AS [FailedLOC],
	[TaskScanEnvironment].[ProductVersion] AS [ProductVersion],
	[TaskScanEnvironment].[ForceScan] AS [IsForcedScan],

	[TaskScans].[ScanRequestCreatedOn] AS [ScanRequestedOn], 
	[TaskScans].[QueuedOn] AS [QueuedOn],
	ISNULL([TaskScans].[EngineStartedOn], [TaskScans].[StartTime]) AS [EngineStartedOn],
	[TaskScans].[EngineFinishedOn] AS [EngineFinishedOn],
    ISNULL([TaskScans].[ScanRequestCompletedOn], [TaskScans].[FinishTime]) AS [ScanCompletedOn],
	ISNULL([TaskScans].[ScanRequestCompletedOn], [TaskScans].[FinishTime]) - ISNULL([TaskScans].[EngineStartedOn], [TaskScans].[StartTime]) AS [ScanDuration],

	[TaskScans].[ProjectId] AS [ProjectId], 
	[TaskScans].[ServerID] AS [EngineServerId],
	[TaskScans].[Origin] AS [Origin],
	[TaskScans].[QueryStateID] AS [QueryLanguageVersionId],
	[TaskScanEnvironment].[PresetId] AS [PresetId],
	[TaskScans].[ProjectType] AS [ScannedLanguageIds],
	
	[TaskScans].[High] + [Medium] + [Low] + [Information] AS [TotalVulnerabilities],
	[TaskScans].[High] AS [High],
    [TaskScans].[Medium] AS [Medium],
	[TaskScans].[Low] AS [Low],
	[TaskScans].[Information] AS [Info],
	[TaskScans].[RiskLevel] AS [RiskScore],
	[TaskScans].[QuantityLevel] AS [QuantityLevel],
	[TaskScans].[StatisticsCalcDate] AS [StatisticsUpdateDate],
	CASE WHEN [TaskScans].[StatisticsOutdated] = 0 THEN 1 ELSE 0 END AS [StatisticsUpToDate],
	[TaskScans].[IsPublic] AS [IsPublic],
	[TaskScans].[IsLocked] AS [IsLocked]
FROM [dbo].[TaskScans]
OUTER APPLY (SELECT TOP 1 [ID] FROM [dbo].[Users] WHERE [Users].[FirstName] + ' ' + [Users].[LastName] = [TaskScans].[Owner] AND [Users].[is_deprecated] = 0) AS [OwningUser]
OUTER APPLY (
	SELECT TOP 1 
		[TaskScanEnvironment].[ProjectName],
		[TaskScanEnvironment].[PresetName],
		[TaskScanEnvironment].[TeamName],
		[TaskScanEnvironment].[Path],
		[TaskScanEnvironment].[FilesCount],
		[TaskScanEnvironment].[LOC],
		[TaskScanEnvironment].[FailedLOC],
		[TaskScanEnvironment].[ProductVersion],
		[TaskScanEnvironment].[ForceScan],
		[TaskScanEnvironment].[PresetId]
	FROM [dbo].[TaskScanEnvironment] 
	WHERE [TaskScanEnvironment].[ScanId] = [TaskScans].[Id] AND [TaskScanEnvironment].[is_deprecated] = 0
) AS [TaskScanEnvironment]
WHERE [TaskScans].[is_deprecated] = 0
go

