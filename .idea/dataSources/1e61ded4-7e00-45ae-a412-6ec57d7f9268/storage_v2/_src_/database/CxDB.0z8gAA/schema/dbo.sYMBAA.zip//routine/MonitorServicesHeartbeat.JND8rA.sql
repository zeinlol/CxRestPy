

CREATE PROCEDURE [dbo].[MonitorServicesHeartbeat]
	@HeartbeatTimeoutIntervalSeconds bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	DECLARE @Now DATETIME
	SET @Now = GetDATE()

	BEGIN TRANSACTION
		BEGIN TRY

			UPDATE  CH
			SET 
			CH.IsDown = 1
			FROM CxComponentsHeartbeat CH
			WHERE  DateDiff(ss, CH.TimeStamp, @Now) > @HeartbeatTimeoutIntervalSeconds

			UPDATE J
			SET J.Owner = NULL,
			J.State = 0
			FROM Jobs J
			INNER JOIN CxComponentsHeartbeat CH on (J.Owner = CH.ComponentID)
			WHERE  DateDiff(ss, CH.TimeStamp, @Now) > @HeartbeatTimeoutIntervalSeconds

			UPDATE SR
			SET SR.OwnerID = NULL
			FROM ScanRequests SR
			INNER JOIN CxComponentsHeartbeat CH on (SR.OwnerID = CH.ComponentID)
			WHERE  DateDiff(ss, CH.TimeStamp, @Now) > @HeartbeatTimeoutIntervalSeconds

	COMMIT TRANSACTION
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
		END CATCH
END
go

