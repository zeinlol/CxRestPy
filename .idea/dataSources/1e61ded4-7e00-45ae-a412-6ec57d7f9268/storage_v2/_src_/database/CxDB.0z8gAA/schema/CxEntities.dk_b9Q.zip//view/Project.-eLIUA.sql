CREATE VIEW [CxEntities].[Project]
AS
	SELECT 
	[Projects].[Id] AS [Id],
	[Projects].[Name] AS [Name],
	[Projects].[Is_Public] AS [IsPublic],
	[Projects].[Description] AS [Description],
	[Projects].[OpenedAt] AS [CreatedDate],
	[OwningUser].[ID] AS [OwnerId],
	[Projects].[Owning_Team] AS [OwningTeamId],

	[Projects].[ConfigurationId] AS [EngineConfigurationId],
	[Projects].[IssueTrackingSettings] AS [IssueTrackingSettings],
	
	[Projects].[Path] AS [SourcePath],
	[Projects].[UNCCredentials] AS [SourceProviderCredentials],
	[Projects].[ExcludeFilesPatterns] AS [ExcludedFiles],
	[Projects].[ExcludeFoldersPatterns] AS [ExcludedFolders],
	[ScanCount].[Count] AS [TotalProjectScanCount],
	[QRTZ_CRON_TRIGGERS].[CRON_EXPRESSION] AS [SchedulingExpression],

	[Projects].[Origin] AS [OriginClientTypeId],
	[Projects].[PresetId] AS [PresetId],
	[LastScan].[Id] AS [LastScanId]
	FROM [dbo].[Projects] 
	OUTER APPLY (SELECT TOP 1 [ID] FROM [dbo].[Users] WHERE [Users].[UserName] = [Projects].[Owner] AND [Users].[is_deprecated] = 0) AS [OwningUser]
	OUTER APPLY 
	(
		SELECT TOP 1 [Id] 
		FROM [dbo].[TaskScans] 
		WHERE [TaskScans].[ProjectId] = [Projects].[Id]
		   AND [TaskScans].[ScanType] = 1  --Regular scan
		   AND [TaskScans].[is_Incremental] = 0  --Not incremental
		   AND [TaskScans].[is_deprecated] = 0
		ORDER BY [TaskScans].[VersionDate] DESC
	) AS [LastScan]
	OUTER APPLY 
	(
		SELECT COUNT(*) AS [Count]
		FROM [dbo].[TaskScans] 
		WHERE [TaskScans].[ProjectId] = [Projects].[Id]
		   AND [TaskScans].[ScanType] = 1  --Regular scan
		   AND [TaskScans].[is_Incremental] = 0  --Not incremental
		   AND [TaskScans].[is_deprecated] = 0
	) AS [ScanCount]
	LEFT JOIN [QRTZ_CRON_TRIGGERS] ON [QRTZ_CRON_TRIGGERS].[TRIGGER_NAME] = 'ScanJob' AND [QRTZ_CRON_TRIGGERS].[TRIGGER_GROUP] = CAST([Projects].[Id] AS nvarchar(15))
	WHERE [Projects].[is_deprecated] = 0
go

