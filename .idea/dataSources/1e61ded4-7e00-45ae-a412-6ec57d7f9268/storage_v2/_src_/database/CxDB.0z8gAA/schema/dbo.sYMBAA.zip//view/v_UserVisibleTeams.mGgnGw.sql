 



CREATE VIEW [dbo].[v_UserVisibleTeams]
WITH SCHEMABINDING
AS
	WITH [DirectTeams] ([TeamId], [TeamName], [TeamPath], [Is_Deprecated], [Level], [UserId])
      AS
      (
		SELECT [v_UserDirectTeams].[TeamId],
		[v_UserDirectTeams].[TeamName],
		[v_UserDirectTeams].[TeamPath],
		[v_UserDirectTeams].[Is_Deprecated],
		[v_UserDirectTeams].[Level],
		[v_UserDirectTeams].[UserId] AS [UserId]
		FROM [dbo].[v_UserDirectTeams]	
	  )
		(SELECT [DirectTeams].[TeamId],
				[DirectTeams].[TeamName],
				[DirectTeams].[TeamPath],
				[DirectTeams].[Is_Deprecated],
				[DirectTeams].[Level],
				[DirectTeams].[UserId]
		FROM [DirectTeams])
		UNION
		(SELECT [SubordinateTeams].[TeamId],
				[SubordinateTeams].[TeamName],
				[SubordinateTeams].[TeamPath],
				[SubordinateTeams].[Is_Deprecated],
				[SubordinateTeams].[Level],
				[DirectTeams].[UserId]
		FROM [DirectTeams]
		INNER JOIN [dbo].[Teams] AS [SubordinateTeams]
				ON SUBSTRING([SubordinateTeams].[TeamPath], 1, LEN([DirectTeams].[TeamPath] + [DirectTeams].[TeamId])) = ([DirectTeams].[TeamPath] + [DirectTeams].[TeamId])
		)
go

