

CREATE PROCEDURE [CollectQueueLoadData]
AS
BEGIN
	DECLARE @Now datetime = GETDATE();
	DECLARE @MinDate datetime = DATEADD(YEAR, -1, @Now);
	DELETE [CxBi].[QueueLoad] WHERE (CAST([SampleDate] AS datetime) + CAST([SampleTime] AS datetime)) < @MinDate;

	DECLARE @CurrentHour datetime = DATEADD(HOUR, DATEDIFF(HOUR, 0, @Now), 0);
	DECLARE @PreviousHour datetime = DATEADD(HOUR, -1, @CurrentHour);
	DECLARE @Colors int= 5;
	DECLARE @QueueLoadColorsConst int = ISNULL((SELECT [Value] FROM [dbo].[CxComponentConfiguration] WHERE [Key]='QueueLoadColorsConst'), 0);
	DECLARE @EngineAgentsCount int = ISNULL((SELECT SUM([MAX_SCANS]) FROM [dbo].[EngineServers] WHERE [Active] = 1 AND [IsAlive] = 1), 0);
	DECLARE @QueuedScansDuration int = 
	ISNULL((
		SELECT 
			SUM(CASE WHEN [QueuedOn] BETWEEN @PreviousHour AND @CurrentHour AND ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)) BETWEEN @PreviousHour AND @CurrentHour
				THEN DATEDIFF(MINUTE, [QueuedOn], ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)))
				ELSE CASE WHEN [QueuedOn] <= @PreviousHour AND ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)) BETWEEN @PreviousHour AND @CurrentHour
					THEN DATEDIFF(MINUTE, @PreviousHour, ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)))
					ELSE CASE WHEN [QueuedOn] BETWEEN @PreviousHour AND @CurrentHour AND ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)) > @CurrentHour
						THEN DATEDIFF(MINUTE, [QueuedOn], @CurrentHour)
						ELSE CASE WHEN [QueuedOn] <= @PreviousHour AND ISNULL([EngineStartedOn], ISNULL([StartTime], @CurrentHour)) > @CurrentHour
							THEN 60
						END
					END
				END
			END) AS [TotalQueueTime]
		FROM [TaskScans]
	), 0)
	+
	ISNULL((
		SELECT 
			SUM(CASE WHEN [QueuedOn] BETWEEN @PreviousHour AND @CurrentHour AND ISNULL([EngineStartedOn], @CurrentHour) BETWEEN @PreviousHour AND @CurrentHour
				THEN DATEDIFF(MINUTE, [QueuedOn], ISNULL([EngineStartedOn], @CurrentHour))
				ELSE CASE WHEN [QueuedOn] <= @PreviousHour AND ISNULL([EngineStartedOn], @CurrentHour) BETWEEN @PreviousHour AND @CurrentHour
					THEN DATEDIFF(MINUTE, @PreviousHour, ISNULL([EngineStartedOn], @CurrentHour))
					ELSE CASE WHEN [QueuedOn] BETWEEN @PreviousHour AND @CurrentHour AND ISNULL([EngineStartedOn], @CurrentHour) > @CurrentHour
						THEN DATEDIFF(MINUTE, [QueuedOn], @CurrentHour)
						ELSE CASE WHEN [QueuedOn] <= @PreviousHour AND ISNULL([EngineStartedOn], @CurrentHour) > @CurrentHour
							THEN 60
						END
					END
				END
			END) AS [TotalQueueTime]
		FROM [ScanRequests]
		WHERE [Stage] = 3
	), 0);

	DECLARE @EngineScanCapacity int = @EngineAgentsCount * @QueueLoadColorsConst / (@Colors - 1);
	DECLARE @ActualLoad int = (SELECT CASE WHEN @EngineScanCapacity = 0 THEN @QueuedScansDuration ELSE @QueuedScansDuration / @EngineScanCapacity END);
	
	DECLARE @SampleDate date = DATEADD(DAY, DATEDIFF(DAY, 0, @PreviousHour), 0);
	DECLARE @SampleTime time = DATEADD(HOUR, DATEDIFF(HOUR, DATEADD(DAY, DATEDIFF(DAY, 0, @PreviousHour), 0), @PreviousHour), 0)
	
	IF EXISTS(SELECT TOP 1 [Load] FROM [CxBi].[QueueLoad] WHERE [SampleDate] = @SampleDate AND [SampleTime] = @SampleTime)
	BEGIN
		UPDATE [CxBi].[QueueLoad]
		SET [Load] = CASE WHEN @ActualLoad > @Colors - 1 THEN @Colors - 1 ELSE @ActualLoad END
		WHERE [SampleDate] = @SampleDate AND [SampleTime] = @SampleTime
	END
	ELSE
	BEGIN
		INSERT INTO [CxBi].[QueueLoad]
		(
			[SampleDate],
			[SampleTime],
			[Load]
		)
		VALUES
		(
			@SampleDate,
			@SampleTime,
			CASE WHEN @ActualLoad > @Colors - 1 THEN @Colors - 1 ELSE @ActualLoad END
		)
	END
END
go

