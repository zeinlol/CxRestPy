 

CREATE PROCEDURE [GetScanResultsComments] 
     @ScanID AS BIGINT
AS
BEGIN

DECLARE @ProjectID AS BIGINT;
DECLARE @StatePerTeams AS BIT;

SELECT @ProjectID = TaskScans.ProjectId  FROM TaskScans WHERE TaskScans.Id = @ScanID;

SELECT @StatePerTeams = CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END
FROM CxComponentConfiguration 
WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY'


SELECT     ResultsLabels.SimilarityId ,
           ResultsLabelsHistory.DateCreated AS CreatedOn ,
           ISNULL(Projects.Name,' ') As ProjectName , 
           ISNULL(users.FirstName + ' ' + users.LastName, ResultsLabelsHistory.CreatedBy)  AS Userdata,
           ISNULL(ResultsLabelsHistory.Data , '') AS Comment
FROM ResultsLabels
INNER JOIN ResultsLabelsHistory  ON ResultsLabelsHistory.ID = ResultsLabels.ID 
LEFT JOIN Projects ON Projects.Id = ResultsLabels.ProjectId
LEFT JOIN Users ON Users.UserName = ResultsLabelsHistory.CreatedBy
WHERE  (
	(@StatePerTeams = 1 AND ResultsLabels.ProjectId IN (SELECT TeamProjects.Id FROM Projects AS TeamProjects WHERE TeamProjects.Owning_Team = ( SELECT Projects.Owning_Team FROM Projects WHERE  Projects.Id = @ProjectID)))
	OR 
	(@StatePerTeams = 0 AND  ResultsLabels.ProjectId = @ProjectID)
        )
AND     ResultsLabels.LabelType = 1
ORDER BY ResultsLabelsHistory.DateCreated DESC
END
go

