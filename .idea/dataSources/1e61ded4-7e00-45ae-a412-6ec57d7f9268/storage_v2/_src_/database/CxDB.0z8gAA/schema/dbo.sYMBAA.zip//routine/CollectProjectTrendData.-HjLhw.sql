

CREATE PROCEDURE [CollectProjectTrendData]
AS
BEGIN
	TRUNCATE TABLE [CxBi].[ProjectsTrend]
	
	DECLARE @MinDate datetime = DATEADD(YEAR, -1, GETDATE());
	DELETE [CxBi].[ProjectsTrend] WHERE [DataUpdatedOn] < @MinDate;
	DECLARE @DaysToFill int = DATEDIFF(DAY, @MinDate, GETDATE());
	DECLARE @Dates TABLE([Date] datetime);
	DECLARE @DataUpdatedOn datetime2 = DATEADD(MINUTE, DATEDIFF(MINUTE, 0, GETUTCDATE()), 0);

	INSERT INTO @Dates
		SELECT DATEADD(DAY, DATEDIFF(DAY, 0, GETDATE()) - [Days].[Number], 0) AS [Date]
			FROM
			(
				SELECT [Hundreds].[Digit] * 100 + [Tens].[Digit] * 10 + [Singles].[Digit] AS [Number]
				FROM (VALUES (0), (1), (2), (3), (4), (5), (6), (7), (8), (9)) AS [Singles]([Digit])
				CROSS JOIN (VALUES (0), (1), (2), (3), (4), (5), (6), (7), (8), (9)) AS [Tens]([Digit])
				CROSS JOIN (VALUES (0), (1), (2), (3)) AS [Hundreds]([Digit])
			) AS [Days]
			WHERE [Days].[Number] < @DaysToFill

	INSERT INTO [CxBi].[ProjectsTrend]
		SELECT
			[TaskScans].[ProjectId] AS [ProjectID],
			[Projects].[Name] AS [ProjectName],
			[ScanData].[ScanDate] AS [SampleDate],
			[TaskScans].[High] AS [High],
			[TaskScans].[Medium] AS [Medium],
			[TaskScans].[Low] AS [Low],
			[TaskScans].[Information] AS [Info],
			[TaskScans].[RiskLevel] AS [RiskScore],
			(SELECT TOP 1 [LOC] FROM [TaskScanEnvironment] WHERE [TaskScanEnvironment].[ScanId] = [TaskScans].[Id]) AS [LOC],
			[TaskScans].[Owning_Team] AS [TeamId],
			@DataUpdatedOn AS [DataUpdatedOn]
		FROM
		(
			SELECT
				[LastScansEachDay].[ProjectId] AS [ProjectId],
				[LastScansEachDay].[Id] AS [ScanId],
				[Dates].[Date] AS [ScanDate],
				ROW_NUMBER() OVER (PARTITION BY [LastScansEachDay].[ProjectId], [Dates].[Date] ORDER BY [LastScansEachDay].[ScanDate] DESC) AS [RowNum]
			FROM @Dates [Dates]
				CROSS JOIN 
				(
					SELECT 
						[ProjectId],
						[Id], 
						[ScanDate]
					FROM
					(
						SELECT 
							[ProjectId], 
							[Id], 
							DATEADD(DAY, DATEDIFF(DAY,0, [VersionDate]), 0) [ScanDate],
							ROW_NUMBER() OVER (PARTITION BY [TaskScans].[ProjectId], DATEADD(DAY, DATEDIFF(DAY,0, [VersionDate]), 0) ORDER BY [TaskScans].[VersionDate] DESC) AS [RowNum]
						FROM [TaskScans] 
						WHERE [VersionDate] > @MinDate
							AND [ScanType] = 1 
							AND [is_deprecated] = 0 
							AND [IsPublic] = 1
					) AS [LastScansEachDay]
					WHERE [RowNum] = 1
				) AS [LastScansEachDay]
			WHERE [LastScansEachDay].[ScanDate] <= [Dates].[Date]
		) [ScanData]
		INNER JOIN [TaskScans] ON [TaskScans].[Id] = [ScanData].[ScanId]
		INNER JOIN [Projects] ON [Projects].[Id] = [ScanData].[ProjectId] AND [Projects].[is_deprecated] = 0  AND [Projects].[Is_Public] = 1
		WHERE [ScanData].[RowNum] = 1
		ORDER BY [ProjectId], [ScanData].[ScanDate] DESC
		
	UPDATE STATISTICS [CxBi].[ProjectsTrend]
END
go

