CREATE VIEW [CxEntities].[ScanLanguages]
AS
	SELECT 
		[CxEntities].[Scan].[Id] AS [ScanId],
		ISNULL([ScannedLanguages].[LanguageId], -1) AS [LanguageId], -- Will never be null. Needed to ensure that field is not nullable.
		ISNULL([ScannedLanguages].[VersionId], -1) AS [VersionId] -- Will never be null. Needed to ensure that field is not nullable.
	FROM [CxEntities].[Scan]
	OUTER APPLY [CxEntities].[GetScanLanguages]([CxEntities].[Scan].[ScannedLanguageIds], [CxEntities].[Scan].[QueryLanguageVersionId]) AS [ScannedLanguages]
	WHERE [ScannedLanguages].[LanguageId] IS NOT NULL 
	AND [ScannedLanguages].[VersionId] IS NOT NULL
go

