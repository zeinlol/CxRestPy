 

CREATE VIEW [CxBi].[v_EngineData]
WITH SCHEMABINDING 
AS
SELECT [Id]
	,[ServerName]
	,[MAX_SCANS] AS MaxAllowedScans
	,[ScanMinLoc]
	,[ScanMaxLoc]
	,[ServerURI]
	,[Active]
	,[IsAlive]
	,[StatusTimeStamp]
FROM   [dbo].[EngineServers]
go

