


CREATE PROCEDURE [dbo].[UpdateQueryLanguageVersionHash] -- Alter the SP Always
AS
BEGIN

DECLARE @LastQueryStateID INT;

	-- If we have a state ID we insert the hashs with comaprison to old values
	IF NOT EXISTS (SELECT id FROM CurrentQueryStateID)
		BEGIN

			-- Insert the state ID
			insert into CurrentQueryStateID (ID) values (1)

			-- Insert the language hashes
			insert into QueryLanguageStates (ID, Language, LanguageName, StateHash, StateCreationDate)
			select 1, [Language], [LanguageName], [Hash] ,GETDATE() from TEMP_VersionLanguageHashState

		END
	-- If we don't have a state ID (clean install), we insert the hashs as is
	ELSE
		BEGIN

			-- Get the current ID
			select @LastQueryStateID = max(ID) from CurrentQueryStateID
			
			-- Increment the ID
			Update CurrentQueryStateID SET id = ((@LastQueryStateID + 1))


			-- Get the new language state with hashs
			-- If a language state didn't change, we give it the last date
			-- If it did, we give the current date

			insert into QueryLanguageStates (ID, Language, LanguageName, StateHash, StateCreationDate)
			SELECT  (@LastQueryStateID + 1) as ID,  NewHash.[Language] as [Language], NewHash.[LanguageName] as [LanguageName], NewHash.[Hash] as [StateHash],
					CASE WHEN ISNULL(OldHash.StateHash, '') <> ISNULL(NewHash.[Hash], '') THEN GETDATE()
					     ELSE ISNULL(OldHash.StateCreationDate, GETDATE()) END as [StateCreationDate]
			FROM  TEMP_VersionLanguageHashState as NewHash
			LEFT OUTER JOIN  QueryLanguageStates OldHash 
			 ON  OldHash.Language = NewHash.Language AND
			     OldHash.ID = @LastQueryStateID

		END

		DROP TABLE  TEMP_VersionLanguageHashState	
END
go

