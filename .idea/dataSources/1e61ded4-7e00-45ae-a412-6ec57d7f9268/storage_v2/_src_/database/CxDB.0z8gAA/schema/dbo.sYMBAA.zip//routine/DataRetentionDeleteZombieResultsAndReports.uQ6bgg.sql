 



CREATE PROCEDURE [dbo].[DataRetentionDeleteZombieResultsAndReports]
AS
BEGIN
	DECLARE @ConfiguredBulkSize int = (SELECT TOP 1 [Value] FROM [dbo].[CxComponentConfiguration] WHERE [Key] = 'DataRetentionPhysicalBulkSize');
	IF @ConfiguredBulkSize IS NULL
		SET @ConfiguredBulkSize = 10000;

	DECLARE @BatchCount int;
	
	-- Delete FailedScans zombies in bulks
	SET @BatchCount = @ConfiguredBulkSize;
	WHILE @BatchCount > 0
	BEGIN
		DELETE TOP(@BatchCount) 
		FROM [FailedScans] 
		WHERE 
			[FailedScans].[ProjectID] = -1 
			AND [FailedScans].[TaskScanID] = -1

		SET @BatchCount = @@ROWCOUNT
	END
	
	-- Delete TaskScanEnvironment zombies in bulks
	SET @BatchCount = @ConfiguredBulkSize;
	WHILE @BatchCount > 0
	BEGIN
		DELETE TOP(@BatchCount)
		FROM [TaskScanEnvironment] 
		WHERE [TaskScanEnvironment].[RunId] IN 
		(
			SELECT [TaskScanEnvironment].[RunId]
			FROM [TaskScanEnvironment]
			LEFT JOIN [ScanRequests] ON [TaskScanEnvironment].[RunId] = [ScanRequests].[RunID]
			WHERE 
				[TaskScanEnvironment].[ScanId] = 0
				AND 
				(
					[ScanRequests].[ID] IS NULL -- Scan request long done, TaskScan must exist
					OR
					[ScanRequests].[Stage] IN 
					(
						7,		--Finished - TaskScan must exist
						9,		--Failed
						1001	--None - Invalid ScanRequest
					)
				)
		)

		SET @BatchCount = @@ROWCOUNT
	END
END
go

