 

CREATE PROCEDURE [dbo].[UpdateExistingQuery] 
	@PackageID AS BIGINT,
	@Name AS NVARCHAR(255),
	@Source AS NVARCHAR(MAX),
	@Cwe AS BIGINT,
	@Severity AS INT,
	@IsExecutable AS BIT,
	@IsEncrypted AS BIT,
	@IsCompiled AS BIT,
	@Comments AS NVARCHAR(500) = null,
	@DraftSource AS NVARCHAR(MAX) = null,
	@CurrentUserName AS NVARCHAR(255) = null,
	@QueryId AS BIGINT,
	@CxDescriptionID AS INT = 0,
	@EngineMetadata AS VARCHAR(2048) = null,
	@NewVersionCode AS BIGINT OUTPUT
	AS

BEGIN
	BEGIN TRANSACTION

	BEGIN TRY

		DECLARE @IsSourceChanged bit =
		(
			SELECT MAX(CASE WHEN (dbo.fnHashBytes('MD5',CONVERT(VARBINARY(MAX),Source)) <> dbo.fnHashBytes('MD5', CONVERT(VARBINARY(MAX),@Source))) THEN 1 ELSE 0 END)
			FROM Query 
			WHERE QueryId = @QueryId 
				AND (dbo.fnHashBytes('MD5',CONVERT(VARBINARY(MAX),Source)) <> dbo.fnHashBytes('MD5', CONVERT(VARBINARY(MAX),@Source))
				OR Severity <> @Severity 
				OR Name <> @Name)
		) -- If query hash, name or severity changed query version will be changed.
		
		IF @IsSourceChanged IS NOT NULL
		BEGIN
		
			UPDATE QueryVersion 
			SET IsActive = 0
			WHERE QueryId = @QueryId AND IsActive = 1

			DECLARE @NewSourceID BIGINT = null

			IF @IsSourceChanged = 1
			BEGIN

				SELECT @NewSourceID = Id FROM QuerySource WHERE Source COLLATE Latin1_General_CS_AS = @Source

				IF @NewSourceID IS NULL

				BEGIN

					INSERT INTO QuerySource ([Source])
					VALUES (@Source)

					SET @NewSourceID = SCOPE_IDENTITY();

				END		

			END
			
			DECLARE @NewVersionEntry TABLE
			(
			  [QuerySourceId] BIGINT, 
			  [Version] BIGINT,
			  [QueryVersionCode] BIGINT
			)

			INSERT INTO @NewVersionEntry
			(QuerySourceId, [Version], [QueryVersionCode])
				SELECT TOP 1 [QuerySourceId], ([Version] + 1) AS [Version], dbo.fnQueryVersionCode(@QueryId,[Version] + 1) AS [QueryVersionCode]
				FROM QueryVersion
				WHERE QueryId = @QueryId
				ORDER BY [Version] DESC
				
			INSERT INTO [QueryVersion] ( [Name], [QuerySourceId], 
								[Cwe], [Severity], 
								[isExecutable],	[isEncrypted], 
								[IsCompiled], [Comments], 
								[CurrentUserName], [IsActive], 
								[IsCheckOut], [UpdateTime], 
								[Version], [QueryVersionCode],
								[QueryId], [PackageId],
								[CxDescriptionID],
								[EngineMetadata])
			SELECT TOP 1 @Name, ISNULL(@NewSourceID, [QuerySourceId]), 
				@Cwe, @Severity,
				@IsExecutable, @IsEncrypted,
				@IsCompiled, @Comments,
				@CurrentUserName, 1,
				0, GETDATE(),
				[Version], [QueryVersionCode],
				@QueryId, @PackageID,
				@CxDescriptionID,
				@EngineMetadata
			FROM @NewVersionEntry	

			SELECT @NewVersionCode = [QueryVersionCode]
			FROM @NewVersionEntry

		END
		ELSE
		BEGIN
			
			SELECT @NewVersionCode = [QueryVersionCode]
			FROM QueryVersion
			WHERE QueryId = @QueryId AND IsActive = 1

			UPDATE QueryVersion
			SET Cwe=@Cwe, Severity=@Severity, 
			isExecutable=@IsExecutable, IsEncrypted=@IsEncrypted, IsCompiled=@IsCompiled, 
			Comments=@Comments, CurrentUserName=@CurrentUserName, PackageId = @PackageID,
			CxDescriptionID = @CxDescriptionID, EngineMetadata = @EngineMetadata
			WHERE QueryID = @QueryId AND IsActive = 1
		END
		
		UPDATE Query 
		SET Source=@Source, Cwe=@Cwe, Severity=@Severity, 
		isExecutable=@IsExecutable, IsEncrypted=@IsEncrypted, IsCompiled=@IsCompiled, 
		Comments=@Comments, DraftSource=@DraftSource, CurrentUserName=@CurrentUserName, 
		is_deprecated=0, PackageId = @PackageID, CxDescriptionID = @CxDescriptionID, EngineMetadata = @EngineMetadata, Name = @Name
		WHERE QueryID = @QueryId
		
		COMMIT TRANSACTION	

	END TRY

	BEGIN CATCH

		ROLLBACK TRANSACTION

		SELECT @NewVersionCode = -1;

	END CATCH
	               
END
go

