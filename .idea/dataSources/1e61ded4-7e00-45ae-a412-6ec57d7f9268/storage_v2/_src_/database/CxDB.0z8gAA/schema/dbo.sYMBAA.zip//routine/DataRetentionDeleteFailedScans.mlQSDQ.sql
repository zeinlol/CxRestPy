 



CREATE PROCEDURE [dbo].[DataRetentionDeleteFailedScans]
(
	@StartDate datetime,
	@EndDate datetime
)
AS
BEGIN  	
	DECLARE @ConfiguredBulkSize int = (SELECT TOP 1 [Value] FROM [dbo].[CxComponentConfiguration] WHERE [Key] = 'DataRetentionPhysicalBulkSize');
	IF @ConfiguredBulkSize IS NULL
		SET @ConfiguredBulkSize = 10000;

	DECLARE @BatchCount int;

	IF @StartDate IS NULL AND @EndDate IS NULL
	BEGIN
		SET @BatchCount = @ConfiguredBulkSize;
		WHILE @BatchCount > 0
		BEGIN
			DELETE TOP(@BatchCount)
			FROM [FailedScans]

			SET @BatchCount = @@ROWCOUNT
		END
	END
	ELSE 
	BEGIN
		SET @BatchCount = @ConfiguredBulkSize;
		WHILE @BatchCount > 0
		BEGIN
			DELETE TOP(@BatchCount)
			FROM [FailedScans]
			WHERE 
				DATEADD(DAY, DATEDIFF(DAY, 0, [FailedScans].[CreatedOn]), 0) >= @StartDate 
				AND DATEADD(DAY, DATEDIFF(DAY, 0, [FailedScans].[CreatedOn]), 0) <= @EndDate

			SET @BatchCount = @@ROWCOUNT
		END
	END		
END
go

