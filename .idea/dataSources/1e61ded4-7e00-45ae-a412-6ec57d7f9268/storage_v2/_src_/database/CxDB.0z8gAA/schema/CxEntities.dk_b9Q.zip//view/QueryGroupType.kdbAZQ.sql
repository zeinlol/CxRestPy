CREATE VIEW [CxEntities].[QueryGroupType]
AS
	SELECT 
		[Enum].[Id] AS [Id],
		[Enum].[Name] AS [Name]
	FROM (
		VALUES
		(1, 'Cx'),
		(2, 'Corp'),
		(3, 'Project'),
		(4, 'Team')
	) AS [Enum]([Id], [Name])
go

