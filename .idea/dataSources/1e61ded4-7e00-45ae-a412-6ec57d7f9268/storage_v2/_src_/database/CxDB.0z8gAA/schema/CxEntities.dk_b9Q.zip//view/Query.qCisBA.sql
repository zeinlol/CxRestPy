CREATE VIEW [CxEntities].[Query]
AS
	SELECT 
		[QueryVersion].[QueryVersionCode] AS [Id],
		[QueryVersion].[Name] AS [Name],
		[QueryVersion].[Version] AS [Version],
		[QueryVersion].[Severity] AS [Severity],
		[QueryVersion].[Comments] AS [Comments],
		[QueryVersion].[CxDescriptionID] AS [CxDescriptionId],
		[QueryVersion].[Cwe] AS [CweId],
		[QueryVersion].[QuerySourceId] AS [QuerySourceId],
		[QueryVersion].[PackageId] AS [QueryGroupId]
	FROM [dbo].[QueryVersion]
go

