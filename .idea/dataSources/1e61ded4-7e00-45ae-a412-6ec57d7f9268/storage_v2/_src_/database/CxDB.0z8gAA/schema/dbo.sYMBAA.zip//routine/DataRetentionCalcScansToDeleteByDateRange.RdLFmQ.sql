 

CREATE PROCEDURE [dbo].[DataRetentionCalcScansToDeleteByDateRange]
(
	@StartDate datetime,
	@EndDate datetime
)
AS
BEGIN
		WITH Preserved_Scans AS (
				SELECT
					[ProjectScans].[ScanId],[ProjectScans].[ProjectId],[ProjectScans].[is_Incremental]
				FROM
				(
					SELECT
						[TaskScans].[Id] AS [ScanId],
						ISNULL([Projects].[ScansToKeep], 0) AS [ScansToKeep],
						[TaskScans].[ProjectId],
						[TaskScans].[is_Incremental],
						ROW_NUMBER() OVER (PARTITION BY [TaskScans].[ProjectId] ORDER BY [TaskScans].[VersionDate] DESC) [ScanOrder]
					FROM [TaskScans]
					INNER JOIN [Projects] ON [TaskScans].[ProjectId] = [Projects].[Id]
					LEFT JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
					WHERE [TaskScans].[ScanType] = 1
						AND [Projects].[is_deprecated] = 0
						AND [TaskScans].[is_deprecated] = 0
						AND [ScanRequests].[Id] IS NULL
				) [ProjectScans]
				WHERE [ProjectScans].[ScanOrder] <= [ProjectScans].[ScansToKeep]

				UNION ALL

				SELECT [TaskScans].[Id] AS [ScanId],[TaskScans].[ProjectId],[TaskScans].[is_Incremental]
				FROM [TaskScans]
				INNER JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
				WHERE [TaskScans].[is_deprecated] = 0
							  )
		SELECT
			[TaskScans].[ProjectId],
			[TaskScans].[Id] AS [ScanId],
			[TaskScans].[SourceId],
			[TaskScans].[TaskId],
			[TaskScans].[ScanType],
			[ScansReports].[ReportPath]
		FROM [TaskScans]
		LEFT JOIN [ScansReports] ON [TaskScans].[Id] = [ScansReports].[ScanID]
		WHERE
			[TaskScans].[IsLocked] = 0
			AND DATEADD(DAY, DATEDIFF(DAY, 0, [TaskScans].[VersionDate]), 0) >= DATEADD(DAY, DATEDIFF(DAY, 0, @StartDate), 0)
			AND DATEADD(DAY, DATEDIFF(DAY, 0, [TaskScans].[VersionDate]), 0) <= DATEADD(DAY, DATEDIFF(DAY, 0, @EndDate), 0)
			AND [TaskScans].[Id] NOT IN
			(
				SELECT [ScanId] FROM Preserved_Scans

				UNION ALL
				
				--Don't delete <b>last</b> Full Scan when one of the conditions below is met
				--   * there is Incremental Scan defined by ScansToKeep (see Preserved_Scans CTE above),
				--   * if VersionDate of Incremental Scan is later than @EndDate
				--in the both cases Incremental Scan(s) depending on the Full Scan
				SELECT ISNULL(MAX([Id]),0)
				FROM [TaskScans] e
				WHERE [is_Incremental]=0 and 
										(EXISTS (SELECT 1 FROM Preserved_Scans ps WHERE ps.[ProjectId]=e.[ProjectId] AND ps.[is_Incremental]=1)
										     OR
										 EXISTS (SELECT 1 FROM [TaskScans] ts WHERE ts.[ProjectId]=e.[ProjectId] AND ts.[is_Incremental]=1
											 			AND (DATEADD(DAY, DATEDIFF(DAY, 0, ts.[VersionDate]), 0) > DATEADD(DAY, DATEDIFF(DAY, 0, @EndDate), 0)))
										)
				GROUP BY [ProjectId]
			)
		ORDER BY
			[TaskScans].[ProjectId],
			[TaskScans].[Id],
			[TaskScans].[VersionDate]
	END
go

