CREATE VIEW [CxEntities].[QueryCweDescription]
AS
	SELECT 
		[Cwe].[CweId] AS [Id],
		[Cwe].[LanguageId] AS [LCID],
		[Cwe].[Description] AS [HtmlDescription]
	FROM [dbo].[Cwe]
go

