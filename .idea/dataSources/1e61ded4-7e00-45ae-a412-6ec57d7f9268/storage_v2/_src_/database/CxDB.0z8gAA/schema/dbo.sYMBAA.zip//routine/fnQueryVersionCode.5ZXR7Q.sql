
	CREATE FUNCTION  [dbo].[fnQueryVersionCode] 
	(
	  @QueryID BIGINT,
	  @QueryVersion BIGINT
	)
	RETURNS BIGINT
	AS
	BEGIN
	  DECLARE @Hashcode AS BIGINT;
	  DECLARE @Offset AS BIGINT = 10000;

	 IF @QueryVersion = 0 
		 BEGIN
			SET @Hashcode = @QueryID;
		 END
	 ELSE 
		 BEGIN
	 
			 SET @QueryVersion = @QueryVersion + @Offset;
			 SET @Hashcode  = ((@QueryID + @QueryVersion ) * (@QueryID + @QueryVersion + 1)) / 2 + @QueryVersion;
	 
	END

		 RETURN @Hashcode;
	END
  go

