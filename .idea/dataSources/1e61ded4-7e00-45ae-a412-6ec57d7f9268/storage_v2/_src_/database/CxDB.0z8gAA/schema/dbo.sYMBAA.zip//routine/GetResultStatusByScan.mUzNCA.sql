 


CREATE PROCEDURE [dbo].[GetResultStatusByScan]
  @currenScanID AS BIGINT,
  @projectID AS BIGINT,
  @isPublic AS BIT,
  @owner AS NVARCHAR(50)
AS
BEGIN

 DECLARE @lastScanId bigint;

 SELECT @lastScanId = Max(Id) 
 FROM taskscans 
 WHERE  id < @currenScanID
   AND  projectid = @projectID                             
   AND  scantype = 1          
   AND  is_deprecated = 0
   AND  (IsPublic = 1 OR (@isPublic = 0 AND Owner = @owner))

 SELECT DATA.ScanId, DATA.[pathid], DATA.[Status]
 FROM   (
           SELECT DISTINCT CASE WHEN currScan.[ScanId] IS NULL THEN prevScan.[QueryVersionCode] ELSE currScan.[QueryVersionCode] END AS QueryVersionCode, 
               CASE WHEN currScan.[ScanId] IS NULL THEN prevScan.[ScanId] ELSE currScan.[ScanId] END AS ScanId, 
               CASE WHEN currScan.[ScanId] IS NULL THEN prevScan.[Path_Id] ELSE currScan.[Path_Id] END AS PathId, 
               CASE WHEN currScan.[ScanId] IS NULL THEN prevScan.[Similarity_Hash] ELSE currScan.[Similarity_Hash] END AS SimilarityID, 
               CASE WHEN prevScan.[ScanId] IS NULL THEN 2 /* New path - not exists on prev scan*/
                    WHEN currScan.[ScanId] IS NULL THEN 0 /* Fixed path - not exists on current scan*/
                                                   ELSE 1 END  /* Reoccurred path - exists on both scans*/ AS [Status]
          FROM  (SELECT [TaskScans].[Id] as ScanId,[QueryVersionCode],[Path_Id],[Similarity_Hash]
                  FROM [PathResults] 
                  INNER JOIN [TaskScans] ON [TaskScans].[Id] = @currenScanID AND [PathResults].[ResultId] = [TaskScans].[ResultId]) AS currScan
          FULL OUTER JOIN (SELECT [TaskScans].[Id] as ScanId,[QueryVersionCode],[Path_Id],[Similarity_Hash] 
                            FROM [PathResults] 
                            INNER JOIN [TaskScans] ON [TaskScans].[Id] = @lastScanId AND [PathResults].[ResultId] = [TaskScans].[ResultId]
                            WHERE [Similarity_Hash] <> 0 ) prevScan 
           ON prevScan.[Similarity_Hash] = currScan.[Similarity_Hash] 
	           ) AS DATA 
END
go

