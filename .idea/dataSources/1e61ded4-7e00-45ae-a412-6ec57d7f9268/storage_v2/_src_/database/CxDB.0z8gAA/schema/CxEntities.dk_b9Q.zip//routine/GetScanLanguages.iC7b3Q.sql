CREATE FUNCTION [CxEntities].[GetScanLanguages]
(
	@ScanLanguages int,
	@QueryStateId int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT 
		[QueryLanguageStates].[Language] AS [LanguageId],
		[QueryLanguageStates].[ID] AS [VersionId]
	FROM [dbo].[QueryLanguageStates]
	WHERE @ScanLanguages & [QueryLanguageStates].[Language] = [QueryLanguageStates].[Language]
	AND @QueryStateId = [QueryLanguageStates].[ID]
)
go

