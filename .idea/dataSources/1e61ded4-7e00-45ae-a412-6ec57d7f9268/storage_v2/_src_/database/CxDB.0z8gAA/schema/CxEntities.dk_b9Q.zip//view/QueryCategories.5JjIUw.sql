CREATE VIEW [CxEntities].[QueryCategories]
AS
	SELECT 
		[QueryVersion].[QueryVersionCode] AS [QueryId],
		[CategoryForQuery].[CategoryId] AS [CategoryId]
	FROM [dbo].[CategoryForQuery]
	INNER JOIN [dbo].[QueryVersion] ON [CategoryForQuery].[QueryId] = [QueryVersion].[QueryId]
go

