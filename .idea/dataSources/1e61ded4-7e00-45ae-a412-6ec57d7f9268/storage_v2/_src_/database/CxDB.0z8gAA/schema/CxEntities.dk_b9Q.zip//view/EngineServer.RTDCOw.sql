CREATE VIEW [CxEntities].[EngineServer]
AS
	SELECT 
		[EngineServers].[Id] AS [Id],
		[EngineServers].[ServerName] AS [Name],
		[EngineServers].[ServerURI] AS [Url],
		[EngineServers].[Active] AS [IsEnabled],
		[EngineServers].[IsAlive] AS [IsAlive],
		[EngineServers].[MAX_SCANS] AS [MaxConcurrentScans],
		[EngineServers].[ScanMinLoc] AS [ScanMinLOC],
		[EngineServers].[ScanMaxLoc] AS [ScanMaxLOC]
	FROM [dbo].[EngineServers]
go

