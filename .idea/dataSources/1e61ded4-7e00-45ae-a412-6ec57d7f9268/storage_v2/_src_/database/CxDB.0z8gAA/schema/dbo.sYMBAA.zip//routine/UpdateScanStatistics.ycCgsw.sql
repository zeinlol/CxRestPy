

CREATE PROCEDURE [dbo].[UpdateScanStatistics]
	@ScanId bigint,
	@ProjectId bigint,
	@OwningTeamId nvarchar(50)
AS
BEGIN
	-- Declare all
    DECLARE @High int; 
    DECLARE @Medium int; 
    DECLARE @Low int; 
    DECLARE @Information int; 
    DECLARE @RiskLevel int; 
    DECLARE @QuantityLevel int;

	DECLARE @TopQuery1 nvarchar(255);
	DECLARE @TopQuery1Count int;
	DECLARE @TopQuery1Severity int;
	DECLARE @TopQuery2 nvarchar(255);
	DECLARE @TopQuery2Count int;
	DECLARE @TopQuery2Severity int;
	DECLARE @TopQuery3 nvarchar(255);
	DECLARE @TopQuery3Count int;
	DECLARE @TopQuery3Severity int;
	DECLARE @TopQuery4 nvarchar(255);
	DECLARE @TopQuery4Count int;
	DECLARE @TopQuery4Severity int;
    DECLARE @TopQuery5 nvarchar(255);
	DECLARE @TopQuery5Count int;
	DECLARE @TopQuery5Severity int;

    DECLARE @StatePerTeams AS BIT;	

	DECLARE @ScanResultsLabels TABLE
	(
	   SimilarityID BIGINT NOT NULL,
	   LabelType BIGINT NOT NULL,
	   StringData NVARCHAR(MAX),
	   NumericData INT   
	   UNIQUE CLUSTERED (LabelType,SimilarityID) 
	);

	DECLARE @QuerySummery TABLE
	(
	   QuerId bigint NOT NULL,
	   QueryName nvarchar(255) NOT NULL,
	   QuerySeverity int NOT NULL,
	   ResultSeverity int NOT NULL,
	   ResultCount int NOT NULL
	);

	DECLARE @SeverityCountSummery TABLE
	(
	   Severity int NOT NULL,
	   ResultCount int NOT NULL	
	);

	DECLARE @TopQueries TABLE
	(
	   QueryName nvarchar(255) NOT NULL,
	   QuerySeverity int NOT NULL,
	   QueryResultCount int NOT NULL,
	   QueryRanking int NOT NULL	
	);
	
	DECLARE @StatisticsCalcDate datetime;

	-- Initialize default values
	SET @High  = 0; 
    SET @Medium  = 0; 
    SET @Low  = 0; 
    SET @Information  = 0; 
    SET @RiskLevel  = 0; 
    SET @QuantityLevel  = 0;
	SET @TopQuery1Count  = 0;
	SET @TopQuery1Severity  = 0;
	SET @TopQuery2Count  = 0;
	SET @TopQuery2Severity  = 0;
	SET @TopQuery3Count  = 0;
	SET @TopQuery3Severity  = 0;
	SET @TopQuery4Count  = 0;
	SET @TopQuery4Severity  = 0;
	SET @TopQuery5Count  = 0;
	SET @TopQuery5Severity  = 0;

	---Set states per project or team
	SELECT @StatePerTeams = (CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END)
	FROM CxComponentConfiguration 
	WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY';

	-------------- Retrive relevant labels ---------
	WITH scanLabels AS
	(
		SELECT  ResultsLabels.SimilarityID 
			   ,ResultsLabels.LabelType 
			   ,ResultsLabels.NumericData
			   ,ResultsLabels.StringData
			   ,row_number() over (partition by ResultsLabels.SimilarityID ,ResultsLabels.LabelType  order by ResultsLabels.[UpdateDate] desc) AS RowNumber
		FROM ResultsLabels
		WHERE  ResultsLabels.LabelType IN (0,2,3) -- Get only severity & state labels
		  AND ResultsLabels.[SimilarityId]  <> 0
		  AND  ((@StatePerTeams = 1 AND ResultsLabels.ProjectId IN (SELECT [Id] FROM Projects WHERE Owning_Team = @OwningTeamId))
				OR 
			   (@StatePerTeams = 0 AND  ResultsLabels.ProjectId = @ProjectID))
	)
	INSERT @ScanResultsLabels (SimilarityID ,LabelType , StringData, NumericData)
	SELECT SimilarityID ,LabelType , StringData, NumericData 
	FROM  scanLabels 
	WHERE RowNumber = 1;

	-------------- Retrive results grouped by query  ---------
	INSERT @QuerySummery (QuerId, QueryName,QuerySeverity, ResultSeverity,ResultCount)	
	SELECT pathQuery.[QueryId], MAX(pathQuery.[Name]) QueryName, MAX(pathQuery.[Severity]) QuerySeverity, 
		   ISNULL(severityLabels.NumericData,pathQuery.Severity) as ResultSeverity,
		   SUM(CASE WHEN exploitabilityLabels.[NumericData] = 1 then 0 else 1 end) as ResultCount
	FROM [PathResults] scanPaths
    INNER JOIN TaskScans ON TaskScans.Id = @ScanId AND scanPaths.ResultId = TaskScans.ResultId
	INNER JOIN [QueryVersion] pathQuery ON pathQuery.[QueryVersionCode] = scanPaths.[QueryVersionCode]
  	LEFT OUTER JOIN @ScanResultsLabels AS exploitabilityLabels ON (exploitabilityLabels.LabelType = 0 or exploitabilityLabels.LabelType = 3) AND 
																	scanPaths.[Similarity_Hash]	 = exploitabilityLabels.SimilarityID
	LEFT OUTER JOIN @ScanResultsLabels AS severityLabels ON severityLabels.LabelType = 2 AND 
																	scanPaths.[Similarity_Hash]	 = severityLabels.SimilarityID
	WHERE scanPaths.[Similarity_Hash] <> 0
    GROUP BY pathQuery.[QueryId], ISNULL(severityLabels.NumericData,pathQuery.Severity);
	
	SET @StatisticsCalcDate = GETDATE();

	----------------------- Calculate Severity summery ----------------------------------------

	INSERT INTO @SeverityCountSummery (Severity, ResultCount)
	SELECT ResultSeverity as Severity, SUM(ResultCount) AS ResultCount
	FROM @QuerySummery
	GROUP BY ResultSeverity

	-- Fill results
	SELECT @Information  = ResultCount 
	FROM @SeverityCountSummery
	WHERE Severity = 0;

	SELECT @Low  = ResultCount 
	FROM @SeverityCountSummery
	WHERE Severity = 1;

	SELECT @Medium  = ResultCount 
	FROM @SeverityCountSummery
	WHERE Severity = 2;

	SELECT @High  = ResultCount 
	FROM @SeverityCountSummery
	WHERE Severity = 3;

	SELECT @RiskLevel = dbo.CalculateRiskLevel(@Low,@Medium,@High);

	SELECT @QuantityLevel = dbo.CalculateQuantityLevel(@Low,@Medium,@High);

	-----------------------    Calculate Top Queries  ---------------------------

	-- Calculate query results summery and retrive the top 5 queries 
	INSERT INTO @TopQueries (QueryName,  QuerySeverity,  QueryResultCount, QueryRanking)
	SELECT TOP 5 MAX(QueryName), MAX(QuerySeverity), SUM(ResultCount) as ResultCount,
				 ROW_NUMBER() OVER (ORDER BY SUM(ResultCount) desc) AS QueryRanking
	FROM @QuerySummery
	WHERE QuerySeverity > 1 -- We filter by only high and medium queries
	GROUP BY QuerId
	HAVING SUM(ResultCount) > 0
	ORDER BY ResultCount DESC, MAX(QuerySeverity) ASC;

	-- Query ranking is saved in a reverse order because of a legacy bug that saved them like that, the order is currently fixed in the UI
	-- Get top 1 query
	SELECT @TopQuery1 = REPLACE(QueryName,'_',' '), @TopQuery1Severity = QuerySeverity, @TopQuery1Count = QueryResultCount 
	FROM @TopQueries
	WHERE QueryRanking = 5;

	-- Get top 2 query
	SELECT @TopQuery2 = REPLACE(QueryName,'_',' '), @TopQuery2Severity = QuerySeverity, @TopQuery2Count = QueryResultCount 
	FROM @TopQueries
	WHERE QueryRanking = 4;

	-- Get top 3 query
	SELECT @TopQuery3 = REPLACE(QueryName,'_',' '), @TopQuery3Severity = QuerySeverity, @TopQuery3Count = QueryResultCount 
	FROM @TopQueries
	WHERE QueryRanking = 3;

	-- Get top 4 query
	SELECT @TopQuery4 = REPLACE(QueryName,'_',' '), @TopQuery4Severity = QuerySeverity, @TopQuery4Count = QueryResultCount 
	FROM @TopQueries
	WHERE QueryRanking = 2;

	-- Get top 5 query
	SELECT @TopQuery5 = REPLACE(QueryName,'_',' '), @TopQuery5Severity = QuerySeverity, @TopQuery5Count = QueryResultCount 
	FROM @TopQueries
	WHERE QueryRanking = 1;


	BEGIN TRY
		-- Update the results
		UPDATE [TaskScans] SET 
			[High] = @High, 
			[Medium] = @Medium, 
			[Low] = @Low, 
			[Information] = @Information, 
			[RiskLevel] = @RiskLevel, 
			[QuantityLevel] = @QuantityLevel,
			[TopQuery1] = @TopQuery1,
			[TopQuery1Count] = @TopQuery1Count,
			[TopQuery1Severity] = @TopQuery1Severity,
			[TopQuery2] = @TopQuery2,
			[TopQuery2Count] = @TopQuery2Count,
			[TopQuery2Severity] = @TopQuery2Severity,
			[TopQuery3] = @TopQuery3,
			[TopQuery3Count] = @TopQuery3Count,
			[TopQuery3Severity] = @TopQuery3Severity,
			[TopQuery4] = @TopQuery4,
			[TopQuery4Count] = @TopQuery4Count,
			[TopQuery4Severity] = @TopQuery4Severity,
			[TopQuery5] = @TopQuery5,
			[TopQuery5Count] = @TopQuery5Count,
			[TopQuery5Severity] = @TopQuery5Severity,
			[StatisticsOutdated] = 0,
			[StatisticsCalcDate] = @StatisticsCalcDate
		WHERE Id = @ScanId;
	
		-- Return the updated data
		SELECT
			@High as [High], 
			@Medium as [Medium], 
			@Low as [Low], 
			@Information as [Information], 
			@RiskLevel as [RiskLevel], 
			@QuantityLevel as [QuantityLevel],
			@TopQuery1 as [TopQuery1],
			@TopQuery1Count as [TopQuery1Count],
			@TopQuery1Severity as [TopQuery1Severity],
			@TopQuery2 as [TopQuery2],
			@TopQuery2Count as [TopQuery2Count],
			@TopQuery2Severity as [TopQuery2Severity],
			@TopQuery3 as [TopQuery3],
			@TopQuery3Count as [TopQuery3Count],
			@TopQuery3Severity as [TopQuery3Severity],
			@TopQuery4 as [TopQuery4],
			@TopQuery4Count as [TopQuery4Count],
			@TopQuery4Severity as [TopQuery4Severity],
			@TopQuery5 as [TopQuery5],
			@TopQuery5Count as [TopQuery5Count],
			@TopQuery5Severity as [TopQuery5Severity],
			@StatisticsCalcDate as [StatisticsCalcDate];
		
	END TRY
	BEGIN CATCH
		-- Ensure that the next iteration will calculate the statistics
		UPDATE [TaskScans]
		SET [StatisticsOutdated] = 1
		WHERE Id = @ScanId;
		
		-- Return empty data
		SELECT 
			0 as [High], 
			0 as [Medium], 
			0 as [Low], 
			0 as [Information], 
			0 as [RiskLevel], 
			0 as [QuantityLevel],
			NULL as [TopQuery1],
			0 as [TopQuery1Count],
			0 as [TopQuery1Severity],
			NULL as [TopQuery2],
			0 as [TopQuery2Count],
			0 as [TopQuery2Severity],
			NULL as [TopQuery3],
			0 as [TopQuery3Count],
			0 as [TopQuery3Severity],
			NULL as [TopQuery4],
			0 as [TopQuery4Count],
			0 as [TopQuery4Severity],
			NULL as [TopQuery5],
			0 as [TopQuery5Count],
			0 as [TopQuery5Severity],
			NULL as [StatisticsCalcDate];
	END CATCH
END
go

