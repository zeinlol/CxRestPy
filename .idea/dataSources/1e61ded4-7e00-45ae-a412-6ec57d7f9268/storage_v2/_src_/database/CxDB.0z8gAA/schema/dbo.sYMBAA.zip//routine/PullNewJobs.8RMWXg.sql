
CREATE PROCEDURE [dbo].[PullNewJobs](@MaxJobs INT , @MaxRep  INT ,@Owner UNIQUEIDENTIFIER)
AS
BEGIN

	SET NOCOUNT OFF;
BEGIN TRANSACTION
BEGIN TRY
UPDATE
   Jobs
SET
    Jobs.Owner = @Owner,
   [Updated] = GETDATE()
WHERE  Jobs.ID IN 
              (
                 SELECT TOP (@MaxJobs) Id FROM (
                                                 SELECT TOP(@MaxJobs) Id FROM  Jobs AS NotReport WITH (UPDLOCK, HOLDLOCK) WHERE NotReport.Type NOT IN(-1,4)  AND NotReport.Owner IS NULL AND NotReport.State = 0
                                                  UNION 
                                                  SELECT TOP (@MaxRep) Id FROM Jobs AS Report WITH (UPDLOCK, HOLDLOCK) WHERE Report.Type = 4 AND Report.Owner IS NULL AND Report.State = 0  
                                                ) 
                                                AS Jobs2Update 
                                               ORDER BY Jobs2Update.ID
              )  
       COMMIT TRANSACTION
END TRY
BEGIN CATCH
       ROLLBACK TRANSACTION
END CATCH

END
go

