


CREATE PROCEDURE [dbo].[spUgradeQueries] 
	AS

BEGIN
	BEGIN TRANSACTION

	BEGIN TRY
--------- Transferring Query Temp Data ------------

		SET IDENTITY_INSERT [QueryGroup] ON 

		--Add new query groups
		INSERT INTO QueryGroup
			([Name] --1
			,[FileName] --2 
			,[isReadOnly] --3
			,[Severity] --4
			,[isEncrypted] --5
			,[Description] --6
			,[Language] --7
			,[LanguageName] --8
			,[PackageType] --9
			,[PackageTypeName] --10
			,[Project_Id] --11
			,[is_deprecated] --12
			,[Owning_Team] --13
			,[PackageId]) --14
		SELECT QueryGroupTemp.[Name] --1
			,QueryGroupTemp.[FileName] --2
			,QueryGroupTemp.[isReadOnly] --3
			,QueryGroupTemp.[Severity] --4
			,QueryGroupTemp.[isEncrypted] --5
			,QueryGroupTemp.[Description] --6
			,QueryGroupTemp.[Language] --7
			,QueryGroupTemp.[LanguageName] --8
			,QueryGroupTemp.[PackageType] --9
			,QueryGroupTemp.[PackageTypeName] --10
			,QueryGroupTemp.[Project_Id] --11
			,QueryGroupTemp.[is_deprecated] --12
			,QueryGroupTemp.[Owning_Team] --13
			,QueryGroupTemp.[PackageId] --14
			FROM QueryGroupTemp
			LEFT JOIN QueryGroup ON QueryGroupTemp.PackageId = QueryGroup.PackageId
			WHERE QueryGroup.PackageId IS NULL

		SET IDENTITY_INSERT [QueryGroup] OFF

		--Update existing query groups
		UPDATE QueryGroup
		SET [FileName] = QueryGroup.[FileName]
			,[isReadOnly] = QueryGroup.[isReadOnly]
			,[Severity] = QueryGroup.[Severity]
			,[isEncrypted] = QueryGroup.[isEncrypted]
			,[Description] = QueryGroup.[Description]
			,[Language] = QueryGroup.[Language]
			,[LanguageName] = QueryGroup.[LanguageName]
			,[PackageType] = QueryGroup.[PackageType]
			,[PackageTypeName] = QueryGroup.[PackageTypeName]
			,[Project_Id] = QueryGroup.[Project_Id]
			,[is_deprecated] = QueryGroup.[is_deprecated]
			,[Owning_Team] = QueryGroup.[Owning_Team]
		FROM QueryGroup
		INNER JOIN QueryGroupTemp ON QueryGroupTemp.PackageId = QueryGroup.PackageId AND (QueryGroup.PackageType = 0 OR (QueryGroup.PackageType = 1 AND QueryGroup.Name = 'CxDefaultQueryGroup'))

		--Update existing queries
		UPDATE Query 
		SET [PackageId] = QueryTemp.PackageId
			  ,[Source] = QueryTemp.Source
			  ,[DraftSource] = QueryTemp.DraftSource
			  ,[Cwe] = QueryTemp.Cwe
			  ,[Comments] = QueryTemp.Comments
			  ,[Severity] = QueryTemp.Severity
			  ,[isExecutable] = QueryTemp.isExecutable
			  ,[isEncrypted] = QueryTemp.isEncrypted
			  ,[is_deprecated] = QueryTemp.is_deprecated
			  ,[IsCheckOut] = QueryTemp.IsCheckOut
			  ,[UpdateTime] = QueryTemp.UpdateTime
			  ,[CurrentUserName] = QueryTemp.CurrentUserName
			  ,[IsCompiled] = QueryTemp.IsCompiled
			  ,[CxDescriptionID] = QueryTemp.CxDescriptionID
			  ,[Name] = QueryTemp.Name
			  ,[EngineMetadata] = QueryTemp.EngineMetadata
		FROM Query
		INNER JOIN QueryTemp ON Query.QueryId = QueryTemp.QueryId

		SET IDENTITY_INSERT [Query] ON 

		--Add new entries to query
		INSERT INTO Query 
			  ([QueryId] --1
			  ,[PackageId] --2
			  ,[Name] --3
			  ,[Source] --4
			  ,[DraftSource] --5
			  ,[Cwe] --6
			  ,[Comments] --7
			  ,[Severity] --8
			  ,[isExecutable] --9
			  ,[isEncrypted] --10
			  ,[is_deprecated] --11
			  ,[IsCheckOut] --12
			  ,[UpdateTime] --13
			  ,[CurrentUserName] --14
			  ,[IsCompiled] --15
			  ,[CxDescriptionID] --16
			  ,[EngineMetadata]) -- 17
		SELECT QueryTemp.[QueryId] --1
			  ,QueryTemp.[PackageId] --2
			  ,QueryTemp.[Name] --3
			  ,QueryTemp.[Source] --4
			  ,QueryTemp.[DraftSource] --5
			  ,QueryTemp.[Cwe] --6
			  ,QueryTemp.[Comments] --7
			  ,QueryTemp.[Severity] --8
			  ,QueryTemp.[isExecutable] --9
			  ,QueryTemp.[isEncrypted] --10
			  ,QueryTemp.[is_deprecated] --11
			  ,QueryTemp.[IsCheckOut] --12
			  ,QueryTemp.[UpdateTime] --13
			  ,QueryTemp.[CurrentUserName] --14
			  ,QueryTemp.[IsCompiled] --15
			  ,QueryTemp.[CxDescriptionID] --16
			  ,QueryTemp.[EngineMetadata] -- 17
		FROM QueryTemp 
		LEFT JOIN Query ON Query.QueryId = QueryTemp.QueryId
		WHERE Query.QueryId IS NULL

		SET IDENTITY_INSERT [Query] OFF 

		--Add new sources
		INSERT INTO
		QuerySource
		([Source])
		SELECT DISTINCT QueryTemp.Source COLLATE Latin1_General_CS_AS
		FROM QueryTemp
		LEFT JOIN QuerySource ON QueryTemp.Source COLLATE Latin1_General_CS_AS = QuerySource.Source COLLATE Latin1_General_CS_AS
		WHERE QuerySource.Source IS NULL

		-- Update non majorly changed queries

		UPDATE QueryVersion
		SET 
			[PackageId] = QueryTemp.PackageId
			,[Cwe] = QueryTemp.Cwe
			,[Comments] = QueryTemp.Comments
			,[isExecutable] = QueryTemp.isExecutable
			,[isEncrypted] = QueryTemp.isEncrypted
			,[IsCheckOut] = QueryTemp.IsCheckOut
			,[UpdateTime] = QueryTemp.UpdateTime
			,[CurrentUserName] = QueryTemp.CurrentUserName
			,[IsCompiled] = QueryTemp.IsCompiled
			,[CxDescriptionID] = QueryTemp.CxDescriptionID
			,[IsActive] = ~QueryTemp.is_deprecated
			,[EngineMetadata] = QueryTemp.EngineMetadata
		FROM QueryTemp
		INNER JOIN QuerySource ON QuerySource.Source COLLATE Latin1_General_CS_AS = QueryTemp.Source COLLATE Latin1_General_CS_AS
		INNER JOIN (SELECT MAX([Version]) AS [Version], MAX(QueryVersionCode) AS [QueryVersionCode], QueryID
					FROM QueryVersion
					GROUP BY QueryID) AS MaxVersion ON MaxVersion.QueryID = QueryTemp.QueryId
		INNER JOIN QueryVersion ON MaxVersion.QueryVersionCode = QueryVersion.QueryVersionCode
		WHERE QueryVersion.QuerySourceId = QuerySource.Id AND QueryVersion.Name = QueryTemp.Name AND QueryVersion.Severity = QueryTemp.Severity 

		--Deactivate existing queries with new versions
		UPDATE QueryVersion
			SET IsActive = 0
		WHERE IsActive = 1 AND QueryId IN
			(SELECT QueryTemp.QueryId			 
			FROM QueryTemp
			INNER JOIN QuerySource ON QuerySource.Source COLLATE Latin1_General_CS_AS = QueryTemp.Source COLLATE Latin1_General_CS_AS
			INNER JOIN QueryVersion ON QueryVersion.QueryId = QueryTemp.QueryId
			WHERE QueryVersion.IsActive = 1 AND (QueryVersion.QuerySourceId <> QuerySource.Id OR QueryVersion.Name <> QueryTemp.Name OR QueryVersion.Severity <> QueryTemp.Severity))

		--Add new query versions
		INSERT INTO
		QueryVersion
			([QueryVersionCode] --1
			  ,[QueryId] --2
			  ,[Version] --3
			  ,[PackageId] --4
			  ,[Name] --5
			  ,[QuerySourceId] --6
			  ,[Cwe] --7
			  ,[Comments] --8
			  ,[Severity] --9
			  ,[isExecutable] --10
			  ,[isEncrypted] --11
			  ,[IsCheckOut] --12
			  ,[UpdateTime] --13
			  ,[CurrentUserName] --14
			  ,[IsCompiled] --15
			  ,[CxDescriptionID] --16
			  ,[IsActive] --17
			  ,[EngineMetadata]) -- 18

		SELECT CASE WHEN LatestVersion.[Version] IS NULL THEN dbo.fnQueryVersionCode(QueryTemp.[QueryId], 1) ELSE dbo.fnQueryVersionCode(QueryTemp.[QueryId], LatestVersion.[Version] + 1) END--1
			  ,QueryTemp.[QueryId] --2
			  ,CASE WHEN LatestVersion.[Version] IS NULL THEN 1 ELSE LatestVersion.[Version] + 1 END --3
			  ,QueryTemp.[PackageId] --4
			  ,QueryTemp.[Name] --5
			  ,QuerySource.Id --6
			  ,QueryTemp.[Cwe] --7
			  ,QueryTemp.[Comments] --8
			  ,QueryTemp.[Severity] --9
			  ,QueryTemp.[isExecutable] --10
			  ,QueryTemp.[isEncrypted] --11
			  ,QueryTemp.[IsCheckOut] --12
			  ,QueryTemp.[UpdateTime] --13
			  ,QueryTemp.[CurrentUserName] --14
			  ,QueryTemp.[IsCompiled] --15
			  ,QueryTemp.[CxDescriptionID] --16
			  ,~QueryTemp.[is_deprecated] --17
			  ,QueryTemp.[EngineMetadata] -- 18
		FROM QueryTemp
		INNER JOIN QuerySource ON QuerySource.Source COLLATE Latin1_General_CS_AS = QueryTemp.Source COLLATE Latin1_General_CS_AS
		LEFT JOIN (SELECT MAX([Version]) AS [Version], QueryId, MAX([QueryVersionCode]) QueryVersionCode
					FROM QueryVersion
					GROUP BY QueryId) AS LatestVersion ON LatestVersion.QueryId = QueryTemp.QueryId
		LEFT JOIN QueryVersion ON QueryVersion.QueryVersionCode = LatestVersion.QueryVersionCode
		WHERE QueryVersion.QueryId IS NULL OR (QueryVersion.QuerySourceId <> QuerySource.Id OR QueryVersion.Name <> QueryTemp.Name OR QueryVersion.Severity <> QueryTemp.Severity)

		--DELETE Removed queries
		DELETE FROM Query
		WHERE QueryId IN 
			(SELECT Query.QueryId FROM Query
			LEFT JOIN QueryTemp ON Query.QueryId = QueryTemp.QueryId 
			WHERE Query.QueryId < 100000 AND QueryTemp.QueryId IS NULL)

		--Set inactive for removed query versions
		UPDATE QueryVersion
		SET IsActive = 0
		WHERE QueryId IN 
			(SELECT QueryVersion.QueryId FROM QueryVersion
			LEFT JOIN QueryTemp ON QueryVersion.QueryId = QueryTemp.QueryId 
			WHERE QueryVersion.QueryId < 100000 AND QueryTemp.QueryId IS NULL AND QueryVersion.IsActive = 1)

		--Delete queries for removed groups
		DELETE FROM Query 
		WHERE PackageId IN 
			(SELECT QueryGroup.PackageId FROM QueryGroup
			LEFT JOIN QueryGroupTemp ON QueryGroup.PackageId = QueryGroupTemp.PackageId
			WHERE QueryGroupTemp.PackageId IS NULL AND (QueryGroup.PackageType = 0 OR (QueryGroup.PackageType = 1 AND QueryGroup.Name = 'CxDefaultQueryGroup')))

		UPDATE QueryVersion
		SET IsActive = 0
		WHERE IsActive = 1 AND PackageId IN 
			(SELECT QueryGroup.PackageId FROM QueryGroup
			LEFT JOIN QueryGroupTemp ON QueryGroup.PackageId = QueryGroupTemp.PackageId
			WHERE QueryGroupTemp.PackageId IS NULL AND (QueryGroup.PackageType = 0 OR (QueryGroup.PackageType = 1 AND QueryGroup.Name = 'CxDefaultQueryGroup')))

		UPDATE QueryGroup
		SET is_deprecated = 1
		WHERE is_deprecated = 0 AND PackageId IN
			(SELECT QueryGroup.PackageId FROM QueryGroup
			LEFT JOIN QueryGroupTemp ON QueryGroup.PackageId = QueryGroupTemp.PackageId
			WHERE QueryGroupTemp.PackageId IS NULL AND (QueryGroup.PackageType = 0 OR (QueryGroup.PackageType = 1 AND QueryGroup.Name = 'CxDefaultQueryGroup')))

		TRUNCATE TABLE QueryGroupTemp

		TRUNCATE TABLE QueryTemp

		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH

		ROLLBACK TRANSACTION;
		
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = ERROR_MESSAGE(),
			   @ErrorSeverity = ERROR_SEVERITY(),
			   @ErrorState = ERROR_STATE();
		
		RAISERROR (@ErrorMessage, 
				   @ErrorSeverity,
				   @ErrorState);

	END CATCH

END

go

