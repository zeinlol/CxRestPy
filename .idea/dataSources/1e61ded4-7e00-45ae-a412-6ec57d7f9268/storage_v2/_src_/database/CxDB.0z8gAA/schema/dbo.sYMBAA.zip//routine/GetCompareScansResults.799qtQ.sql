

-- =============================================
-- Author:		Dima Abramchaev
-- Create date: 2015-10-01
-- Description:	This stored procedure returns the result comparison between 2 scans. This includes the PathResult data, the source and destination info, and the Result status (New/Recurrent/Resolved)
-- Use the @IncludeNotExplotable parameters to only include results not marked as NotExploitable.
-- =============================================
CREATE PROCEDURE [dbo].[GetCompareScansResults]
	@NewScanId bigint, -- The newer scan Id
	@OldScanId bigint, -- The older scan Id
	@IncludeNotExploitable bit = 0 -- Set to true to include not exploitable results; false otherwise.
AS
BEGIN
	SET NOCOUNT ON;

	WITH [CurrentResults_CTE] AS
	(
		SELECT
			[Id],
			[ResultId],
			[ScanId],
			[ProjectId],
			[OwningTeam],
			[QueryId],
			[QueryVersionId],
			[QueryName],
			[SimilarityId],
			[Date],
			[Severity],
			[State],
			[AssignedToUserId],
			[AssignedToUserName],
			[Comment]
		FROM [dbo].[v_PathResultsWithLabelData]
		WHERE [ScanId] = @NewScanId
			AND (
					@IncludeNotExploitable = 1 
					OR [State] <> 1 -- 1 = Not Exploitable
				)
	), [PreviousResults_CTE] AS
	(
		SELECT
			[Id],
			[ResultId],
			[ScanId],
			[ProjectId],
			[OwningTeam],
			[QueryId],
			[QueryVersionId],
			[QueryName],
			[SimilarityId],
			[Date],
			[Severity],
			[State],
			[AssignedToUserId],
			[AssignedToUserName],
			[Comment]
		FROM [dbo].[v_PathResultsWithLabelData]
		WHERE [ScanId] = @OldScanId
			AND (
					@IncludeNotExploitable = 1 
					OR [State] <> 1 -- 1 = Not Exploitable
				)
	), [FixedResults_CTE] AS
	(
		SELECT
			[r2].[Id] AS [PathId],
			NULL AS [OldPathId],
			[r2].[ResultId] AS [ResultId],
			@OldScanId AS [ScanId],
			@NewScanId AS [OldScanId],
			[r2].[ProjectId] AS [ProjectId],
			[r2].[OwningTeam] AS [OwningTeam],
			[r2].[QueryId] AS [QueryId],
			[r2].[QueryVersionId] AS [QueryVersionId],
			[r2].[QueryName] AS [QueryName],
			[r2].[SimilarityId] AS [SimilarityId],
			[r2].[Date] AS [Date],
			[r2].[Severity] AS [Severity],
			[r2].[State] AS [State],
			[r2].[AssignedToUserId] AS [AssignedToUserId],
			[r2].[AssignedToUserName] AS [AssignedToUserName],
			[r2].[Comment] AS [Comment],
			0 AS [Status] -- Fixed
		FROM [PreviousResults_CTE] [r2]
		OUTER APPLY 
			(
				SELECT TOP 1 
					[SimilarityId],
					[Id],
					[ScanId]
				FROM [CurrentResults_CTE]
				WHERE [r2].[SimilarityId] = [CurrentResults_CTE].[SimilarityId]
			) AS [r1]
		WHERE [r1].[SimilarityId] IS NULL
	), [NewAndRecurringResults_CTE] AS
	(
		SELECT
			[r1].[Id] AS [PathId],
			CASE WHEN [r2].[SimilarityId] IS NOT NULL THEN [r2].[Id] ELSE NULL END AS [OldPathId],
			[r1].[ResultId] AS [ResultId],
			@NewScanId AS [ScanId],
			@OldScanId AS [OldScanId],
			[r1].[ProjectId] AS [ProjectId],
			[r1].[OwningTeam] AS [OwningTeam],
			[r1].[QueryId] AS [QueryId],
			[r1].[QueryVersionId] AS [QueryVersionId],
			[r1].[QueryName] AS [QueryName],
			[r1].[SimilarityId] AS [SimilarityId],
			[r1].[Date] AS [Date],
			[r1].[Severity] AS [Severity],
			[r1].[State] AS [State],
			[r1].[AssignedToUserId] AS [AssignedToUserId],
			[r1].[AssignedToUserName] AS [AssignedToUserName],
			[r1].[Comment] AS [Comment],
			CASE 
				WHEN [r2].[SimilarityId] IS NOT NULL 
				THEN 1 -- Recurring
				ELSE 2 -- New
			END AS [Status] 
		FROM [CurrentResults_CTE] [r1]
		OUTER APPLY 
			(
				SELECT TOP 1 
					[SimilarityId],
					[Id],
					[ScanId]
				FROM [PreviousResults_CTE]
				WHERE [r1].[SimilarityId] = [PreviousResults_CTE].[SimilarityId]
			) AS [r2]
	), [AllResults_CTE] AS
	(
		SELECT 
			[PathId],
			[OldPathId],
			[ResultId],
			[ScanId],
			[OldScanId],
			[ProjectId],
			[OwningTeam],
			[QueryId],
			[QueryVersionId],
			[QueryName],
			[SimilarityId],
			[Date],
			[Severity],
			[State],
			[AssignedToUserId],
			[AssignedToUserName],
			[Comment],
			[Status]
		FROM [FixedResults_CTE]

		UNION

		SELECT
			[PathId],
			[OldPathId],
			[ResultId],
			[ScanId],
			[OldScanId],
			[ProjectId],
			[OwningTeam],
			[QueryId],
			[QueryVersionId],
			[QueryName],
			[SimilarityId],
			[Date],
			[Severity],
			[State],
			[AssignedToUserId],
			[AssignedToUserName],
			[Comment],
			[Status]
		FROM [NewAndRecurringResults_CTE]
	)
	SELECT 
		[AllResults_CTE].[PathId],
		[AllResults_CTE].[OldPathId],
		[AllResults_CTE].[ResultId],
		[AllResults_CTE].[ScanId],
		[AllResults_CTE].[OldScanId],
		[AllResults_CTE].[ProjectId],
		[AllResults_CTE].[OwningTeam],
		[AllResults_CTE].[QueryId],
		[AllResults_CTE].[QueryVersionId],
		[AllResults_CTE].[QueryName],
		[AllResults_CTE].[SimilarityId],
		[AllResults_CTE].[Date],
		[AllResults_CTE].[Severity],
		[AllResults_CTE].[State],
		[AllResults_CTE].[AssignedToUserId],
		[AllResults_CTE].[AssignedToUserName],
		[AllResults_CTE].[Comment],
		[AllResults_CTE].[Status],
		[SourceNode].[FileName] AS [SourceFileName],
		[SourceNode].[Line] AS [SourceLine],
		[SourceNode].[Short_Name] AS [SourceObjectName],
		[DestinationNode].[FileName] AS [DestinationFileName],
		[DestinationNode].[Line] AS [DestinationLine],
		[DestinationNode].[Short_Name] AS [DestinationObjectName]
	FROM [AllResults_CTE]
	OUTER APPLY
	(
		SELECT TOP 1
			[NodeResults].[File_Name] AS [FileName],
			[NodeResults].[Line] AS [Line], 
			[NodeResults].[Short_Name]
		FROM [NodeResults]
		WHERE [NodeResults].[ResultId] = [AllResults_CTE].[ResultId] 
			AND [NodeResults].[Path_Id] = [AllResults_CTE].[PathId]
		ORDER BY [Node_Id]
	) AS [SourceNode]
	OUTER APPLY
	(
		SELECT TOP 1
			[NodeResults].[File_Name] AS [FileName],
			[NodeResults].[Line] AS [Line], 
			[NodeResults].[Short_Name]
		FROM [NodeResults]
		WHERE [NodeResults].[ResultId] = [AllResults_CTE].[ResultId] 
			AND [NodeResults].[Path_Id] = [AllResults_CTE].[PathId]
		ORDER BY [Node_Id] DESC
	) AS [DestinationNode]
	ORDER BY [QueryVersionId], [ScanId], [PathId]
END
go

