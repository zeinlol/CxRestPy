CREATE VIEW [CxEntities].[QueryCxDescription]
AS
	SELECT 
		[CxQueryDescription].[CxDescriptionId] AS [Id],
		[CxQueryDescription].[LCID] AS [LCID],
		[CxQueryDescription].[ResultDescription] AS [ResultDescription],
		[CxQueryDescription].[BestFixLocation] AS [BestFixLocation],
		[CxQueryDescription].[Risk] AS [Risk],
		[CxQueryDescription].[Cause] AS [Cause],
		[CxQueryDescription].[GeneralRecommendations] AS [GeneralRecommendations]
	FROM [dbo].[CxQueryDescription]
go

