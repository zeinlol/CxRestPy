

CREATE PROCEDURE [dbo].[GetDataAnalysisResults]
	@UserID AS BIGINT,
	@DateRangeStart AS DATETIME,
	@DateRangeEnd AS DATETIME ,
	@PivotViewType AS INT = 0,   
    @IncludeNotExploitable AS INT = 1
AS
BEGIN

/*
  PivotViewTypes:
  --------------
  AllProjectScans/Default = 0,
  LastMonthProjectScans = 1,
  ProjectsLastScan = 2,
  LastWeekOWASPTop10 = 3

*/

DECLARE @StatePerTeams AS BIT;	

DECLARE @IsAdmin AS BIT;	
DECLARE @UserName AS NVARCHAR(120);	

DECLARE @ResultsLabels TABLE
(
   SimilarityID BIGINT NOT NULL,
   LabelType BIGINT NOT NULL,
   ProjectID BIGINT NOT NULL,
   TeamID NVARCHAR(50) NOT NULL,
   Data NVARCHAR(MAX) ,
   UNIQUE CLUSTERED (SimilarityID,LabelType,ProjectID,TeamID) 
);


SELECT @UserName = UserName, @IsAdmin = CASE [Role]  WHEN 16 THEN 1 WHEN 17 THEN 1 ELSE 0 END FROM Users where Id = @UserID

---Set states per project or team
SELECT @StatePerTeams = (CASE CxComponentConfiguration.Value  WHEN 'true' THEN 1 ELSE 0 END)
FROM CxComponentConfiguration 
WHERE CxComponentConfiguration.[Key]  = 'RESULT_ATTRIBUTES_PER_SIMILARITY'


---Retrieve result labels

-- If we are in state per team mode, group the labels by team
IF @StatePerTeams = 1
BEGIN

	WITH TeamLabels AS
	(
		SELECT  ResultsLabels.SimilarityID, ResultsLabels.LabelType, -1 AS ProjectID, VTeams.TeamID AS TeamID, ResultsLabels.NumericData AS Data,
				 row_number() over (partition by VTeams.[TeamID], ResultsLabels.[SimilarityID], ResultsLabels.[LabelType] order by ResultsLabels.[UpdateDate] desc) AS RowNumber
		FROM ResultsLabels																			
		INNER JOIN Projects AS TeamProjects ON ResultsLabels.ProjectId = TeamProjects.Id
		INNER JOIN v_UserVisibleTeams VTeams ON VTeams.TeamID = TeamProjects.Owning_Team AND VTeams.UserID = @UserID
		WHERE ResultsLabels.LabelType IN (2,3)
	)
	INSERT @ResultsLabels 
	SELECT SimilarityID, LabelType, ProjectID, TeamID, Data
	FROM TeamLabels
	WHERE RowNumber = 1
	END

-- If we are in state per project mode, group the labels by team & project
ELSE
BEGIN

	WITH ProjectLabels AS
	(
		SELECT  ResultsLabels.SimilarityID, ResultsLabels.LabelType, ResultsLabels.ProjectID, VTeams.TeamID AS TeamID, ResultsLabels.NumericData AS Data,
				 row_number() over (partition by ResultsLabels.ProjectID,  VTeams.TeamID, ResultsLabels.[SimilarityID], ResultsLabels.[LabelType] order by ResultsLabels.[UpdateDate] desc) AS RowNumber
		FROM ResultsLabels																			
		INNER JOIN Projects AS TeamProjects ON ResultsLabels.ProjectId = TeamProjects.Id
		INNER JOIN v_UserVisibleTeams VTeams ON VTeams.TeamID = TeamProjects.Owning_Team AND VTeams.UserID = @UserID
		WHERE ResultsLabels.LabelType IN (2,3)
	)
	INSERT @ResultsLabels 
	SELECT SimilarityID, LabelType, ProjectID, TeamID, Data
	FROM ProjectLabels
	WHERE RowNumber = 1

END
--------------------------------------

 -- Get the summarized analysis data
    SELECT MAX(VTeams.TeamName) AS BUName, MAX(Projects.Name) AS ProjectName, MAX(ISNULL(QueryVersion.Name, 'No Results' )) AS QueryName,
		   ISNULL(ResultLabelsSeverity.Data, ISNULL(QueryVersion.Severity, -1 )) As Severity,
		   MAX(TaskScans.StartTime) as ScanDate, SUBSTRING(CONVERT(CHAR(8),MAX(TaskScans.StartTime),114),1,8) as ScanTime,
		   CASE WHEN ISNULL(ResultLabelsSeverity.Data, ISNULL(QueryVersion.Severity, -1 )) = -1 
				THEN 0 
				ELSE SUM(CASE WHEN (@IncludeNotExploitable = 0 AND ResultLabelsState.Data = 1)  -- If filter not exploitable sum only the exploitable
										THEN 0 ELSE 1 END) END AS Quantity		
    FROM Projects  
		 INNER JOIN v_UserVisibleTeams VTeams ON Projects.Owning_Team = VTeams.TeamId AND VTeams.UserID = @UserID -- Bring all projects from user's visible teams
		 INNER JOIN TaskScans ON TaskScans.ProjectId = Projects.Id  -- Bring all scans for projects
         LEFT OUTER JOIN PathResults On PathResults.ResultId = TaskScans.ResultId AND PathResults.Similarity_Hash <> 0  -- Bring all paths for scans
		 LEFT OUTER JOIN QueryVersion ON QueryVersion.QueryVersionCode = PathResults.QueryVersionCode -- Bring all queries for paths
		 LEFT OUTER JOIN @ResultsLabels AS ResultLabelsSeverity ON ResultLabelsSeverity.SimilarityID  =  PathResults.Similarity_Hash  AND ResultLabelsSeverity.LabelType = 2  -- Bring the severity labels for the paths
														AND ResultLabelsSeverity.TeamID = Projects.Owning_Team
														AND  (ResultLabelsSeverity.ProjectID = -1 or  Projects.Id = ResultLabelsSeverity.ProjectID) -- Join by project if we are in project mode (projectID will be -1 if in team mode)     
	     LEFT OUTER JOIN @ResultsLabels AS ResultLabelsState ON ResultLabelsState.SimilarityID  =  PathResults.Similarity_Hash  AND ResultLabelsState.LabelType = 3   -- Bring the state labels for the paths
														AND ResultLabelsState.TeamID = Projects.Owning_Team
														AND  (ResultLabelsState.ProjectID = -1 or  Projects.Id = ResultLabelsState.ProjectID)  -- Join by project if we are in project mode (projectID will be -1 if in team mode)         
    WHERE Projects.is_deprecated = 0 	
	 AND Projects.Is_Public = 1 
	 AND TaskScans.IsPublic = 1
	 AND TaskScans.is_deprecated = 0
	 AND TaskScans.ScanType = 1 -- scan type = Regular
	 AND (@PivotViewType != 2 or TaskScans.id = (SELECT MAX(TaskScans.id)  /* Filter by only last public scan - PivotViewType = 2 - ProjectsLastScan  */
	 					     FROM TaskScans 
						     WHERE TaskScans.ProjectId = Projects.Id 
						     AND TaskScans.ScanType =  1 -- scan type = Regular
						     AND TaskScans.is_deprecated = 0
						     AND TaskScans.IsPublic = 1)) 
	 AND TaskScans.StartTime between @DateRangeStart and @DateRangeEnd  -- Filter by date range
	 AND (PathResults.Compilation_Msgs IS NULL  or	 PathResults.Compilation_Msgs = '') -- Remove paths with engine compilation messages
	 AND (@PivotViewType != 3 or QueryVersion.QueryId IN (SELECT  QueryId  /* Filter by OWASP top 10 - PivotViewType = 3 - LastWeekOWASPTop10  */
							      FROM  Preset_Details  
							      WHERE PresetId = 4 -- OWASP TOP 10 Preset
							      AND is_deprecated = 0))
    GROUP BY  Projects.Owning_team , Projects.Id , TaskScans.Id , PathResults.QueryVersionCode, ISNULL(ResultLabelsSeverity.Data, ISNULL(QueryVersion.Severity, -1 )) -- Group by project+scan+query+calculated severity      
	 

END

go

