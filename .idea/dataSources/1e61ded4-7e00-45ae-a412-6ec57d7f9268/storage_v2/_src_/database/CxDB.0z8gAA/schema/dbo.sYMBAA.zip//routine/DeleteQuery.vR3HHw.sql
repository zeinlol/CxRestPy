

CREATE PROCEDURE [dbo].[DeleteQuery] 
	@QueryID AS BIGINT
	AS

BEGIN
	BEGIN TRANSACTION

	BEGIN TRY

		Update QueryVersion 
		SET IsActive = 0
		WHERE QueryId = @QueryID AND IsActive = 1

		DELETE FROM Query
		WHERE QueryId = @QueryID
	
		COMMIT TRANSACTION

	END TRY

	BEGIN CATCH

		ROLLBACK TRANSACTION

	END CATCH
	              
END

go

