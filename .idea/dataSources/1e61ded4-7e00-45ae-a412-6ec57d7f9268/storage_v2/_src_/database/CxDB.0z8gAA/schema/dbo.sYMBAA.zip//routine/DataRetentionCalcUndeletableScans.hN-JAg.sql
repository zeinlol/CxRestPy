

CREATE PROCEDURE [dbo].[DataRetentionCalcUndeletableScans]
(
    @NumOfScansToKeep int
)
AS
BEGIN
    WITH [LastScansCTE] AS
    (
        SELECT
            [ProjectScans].[ScanId]
        FROM
        (
            SELECT 
                [TaskScans].[Id] AS [ScanId],
                ISNULL([Projects].[ScansToKeep], @NumOfScansToKeep) AS [ScansToKeep],
                ROW_NUMBER() OVER (PARTITION BY [TaskScans].[ProjectId] ORDER BY [TaskScans].[VersionDate] DESC) [ScanOrder]
            FROM [TaskScans]
            INNER JOIN [Projects] ON [TaskScans].[ProjectId] = [Projects].[Id]
            LEFT JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
            WHERE [TaskScans].[ScanType] = 1
                AND [Projects].[is_deprecated] = 0
                AND [TaskScans].[is_deprecated] = 0
                AND [TaskScans].[IsPublic] = 1
                AND [ScanRequests].[Id] IS NULL
        ) [ProjectScans]
        WHERE [ProjectScans].[ScanOrder] <= [ProjectScans].[ScansToKeep]
    ), [RunningScansCTE] AS
    (             
        SELECT [TaskScans].[Id] AS [ScanId]
        FROM [TaskScans]
        INNER JOIN [ScanRequests] ON [ScanRequests].[TaskScanID] = [TaskScans].[Id]
        WHERE [TaskScans].[is_deprecated] = 0
    )
    SELECT DISTINCT
        [ScansToKeep].[ScanId]
    FROM [TaskScans]
    INNER JOIN ( 
        SELECT [ScanId] FROM [LastScansCTE]
        UNION
        SELECT [ScanId] FROM [RunningScansCTE] 
    ) [ScansToKeep] ON [TaskScans].[Id] = [ScansToKeep].[ScanId]
    WHERE
        [TaskScans].[IsLocked] = 0
        AND [TaskScans].[is_deprecated] = 0
        AND 
        (
            [TaskScans].[IsPublic] = 1
            OR
            [TaskScans].[Id] < (SELECT MIN([ScanId]) FROM [LastScansCTE])
        )
END

go

