CREATE VIEW [CxEntities].[User]
AS
	SELECT 
		[Users].[Id] AS [Id],
		[Users].[UserName] AS [UserName],
		[Users].[FirstName] AS [FirstName],
		[Users].[LastName] AS [LastName],
		[Users].[Email] AS [Email],
		[Users].[ExpirationDate] AS [ExpirationDate],
		[UserTeam].[TeamId] AS [TeamId]
	FROM [dbo].[Users]
	OUTER APPLY 
	(
		SELECT TOP 1 [UsersTeams].[TeamId] 
		FROM [dbo].[UsersTeams] 
		INNER JOIN [dbo].[Teams] ON [UsersTeams].[TeamId] = [Teams].[TeamId]
		WHERE [Teams].[Is_Deprecated] = 0 AND [UsersTeams].[UserId] = [Users].[ID]
		ORDER BY [Teams].[Level]
	) AS [UserTeam]
	WHERE [Users].[IsActive] = 1
go

