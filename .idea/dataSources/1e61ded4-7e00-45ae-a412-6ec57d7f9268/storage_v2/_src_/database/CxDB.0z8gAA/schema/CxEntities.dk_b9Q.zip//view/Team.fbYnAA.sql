CREATE VIEW [CxEntities].[Team]
AS
	SELECT 
		[Teams].[TeamId] AS [Id],
		[Teams].[TeamName] AS [Name],
		[Teams].[TeamPath] AS [Path],
		[CxEntities].[GetFullTeamName]([TeamPath], [TeamName]) AS [FullName]
	FROM [dbo].[Teams]
go

