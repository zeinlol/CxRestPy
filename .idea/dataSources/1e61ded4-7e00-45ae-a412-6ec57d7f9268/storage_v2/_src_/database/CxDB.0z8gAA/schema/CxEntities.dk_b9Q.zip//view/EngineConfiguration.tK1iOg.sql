CREATE VIEW [CxEntities].[EngineConfiguration]
AS
	SELECT 
		[Configurations].[Id] AS [Id],
		[Configurations].[Name] AS [Name]
	FROM [dbo].[Configurations]
go

