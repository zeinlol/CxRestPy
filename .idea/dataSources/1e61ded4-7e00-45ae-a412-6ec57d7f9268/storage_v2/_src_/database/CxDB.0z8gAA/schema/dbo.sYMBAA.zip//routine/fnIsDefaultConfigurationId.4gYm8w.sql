  
       

CREATE FUNCTION dbo.fnIsDefaultConfigurationId (
@NewConfigurationID bigint
)
RETURNS bigint
AS
BEGIN
  DECLARE @Result bit
  IF EXISTS( SELECT * FROM [CxDB].[Config].[CxEngineConfiguration] WHERE Name = 'Default Configuration' and [Config].[CxEngineConfiguration].[Id] = @NewConfigurationID)
	 SET @Result = 1
  ELSE 
	SET @Result = 0

	RETURN @Result
END
go

