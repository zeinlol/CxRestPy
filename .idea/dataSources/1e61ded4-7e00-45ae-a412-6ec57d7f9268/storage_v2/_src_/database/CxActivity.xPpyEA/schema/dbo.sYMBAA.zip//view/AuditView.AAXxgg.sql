CREATE VIEW dbo.AuditView AS 
	SELECT
		action.name AS 'Action', 
		entity.name AS 'EntityType', 
		trail.EntityId, 
		trail.StartTime, 
		trail.EndTime, 
		origin.name AS 'Origin', 
		trail.UserId,
		Success = 
			CASE
				WHEN trail.Success=0 THEN 'False'
				ELSE 'True'
			END,
		trail.Remarks

	FROM AuditTrail trail, 
		ActionType action,
		EntityType entity,
		Origin origin

	WHERE action.id = trail.Action
	and entity.id = trail.EntityType
	and origin.id = trail.Origin;
go

